// =====================================================================
//  REPARTO DE PAGOS POR CONTINGENCIA  →  src/data/esquemas-pago.ts
//
//  Lee la tabla `esquema_pago_contingencia` de JurisConecta y la deja en
//  el cajón de memoria para que la calculadora la use.
//
//  POR QUÉ EN LA BASE Y NO EN EL CÓDIGO: así la DGE puede cambiar los
//  porcentajes ella misma, sin que nadie compile ni publique. La tabla
//  tiene un candado que no deja guardar si los renglones de una
//  contingencia no suman 100, y sólo la escriben DGE, Super_Admin y DTR.
//
//  OJO: esto es SOLO el valor por omisión —con qué reparto arranca una
//  garantía nueva—. El reparto pactado de cada garantía se sigue
//  guardando en `garantia.esquema_pagos` y es el que manda. No hay dos
//  copias del mismo dato: la tabla es la plantilla, la garantía es el
//  trato ya cerrado.
// =====================================================================
import { supabase } from "../lib/supabase";
import { setEsquemasCache, type EsquemasEnCache } from "../lib/esquemas-pago-cache";

const TABLA = "esquema_pago_contingencia";

/** Lee la tabla completa y llena el cajón.
 *
 *  Si falla (sin internet, tabla que todavía no existe), NO truena ni
 *  deja el cajón a medias: lo deja en null y el cálculo sigue con el
 *  respaldo escrito en `precio-garantia.ts`. */
export async function cargarEsquemasPago(): Promise<boolean> {
  const { data, error } = await supabase
    .from(TABLA)
    .select("contingencia,orden,concepto,pct")
    .order("contingencia", { ascending: true })
    .order("orden", { ascending: true });

  if (error) {
    console.warn("esquemas de pago · no se pudo leer:", error.message);
    setEsquemasCache(null);
    return false;
  }

  const filas = (data ?? []) as unknown as Record<string, unknown>[];
  if (!filas.length) {
    setEsquemasCache(null);
    return false;
  }

  const armado: EsquemasEnCache = {};
  for (const f of filas) {
    const c = String(f.contingencia ?? "");
    if (!c) continue;
    if (!armado[c]) armado[c] = [];
    armado[c].push({
      concepto: String(f.concepto ?? ""),
      pct: Number(f.pct) || 0,
    });
  }

  setEsquemasCache(armado);
  return true;
}
