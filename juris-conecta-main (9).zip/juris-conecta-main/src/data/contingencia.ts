// Contingencia jurídica del cliente: cuando el cliente demanda a la empresa
// o la empresa demanda al cliente. Aplica a cualquier código (SVT, RV, R1,
// R2, R2C, R3) e incluso en apartado.
import { supabase } from "../lib/supabase";

export type Contingencia = {
  tieneDemanda: boolean;
  quienDemanda: string;   // 'cliente_a_empresa' | 'empresa_a_cliente'
  tipo: string;           // 'profeco' | 'condusef' | 'civil' | 'mercantil'
  abogado: string;
  etapa: string;
  nota: string;
  avance: string;                 // avance / estado procesal
  apoderadoEmpresa: string;       // apoderado(s) de DIIPA
  clienteTieneApoderado: boolean; // ¿el cliente tiene apoderado?
  apoderadoCliente: string;       // nombre y datos del apoderado del cliente
  expediente: string;             // número de expediente / radicado
  jurisdiccion: string;           // jurisdicción
  ciudad: string;                 // ciudad de la demanda
  quienRecibio: string;           // quién recibió la demanda
};

export const CONTINGENCIA_VACIA: Contingencia = {
  tieneDemanda: false, quienDemanda: "", tipo: "", abogado: "", etapa: "", nota: "",
  avance: "", apoderadoEmpresa: "", clienteTieneApoderado: false, apoderadoCliente: "",
  expediente: "", jurisdiccion: "", ciudad: "", quienRecibio: "",
};

export const QUIEN_DEMANDA: { key: string; label: string }[] = [
  { key: "cliente_a_empresa", label: "El cliente demanda a la empresa" },
  { key: "empresa_a_cliente", label: "La empresa demanda al cliente" },
];

export const TIPOS_DEMANDA: { key: string; label: string }[] = [
  { key: "profeco", label: "Queja en PROFECO" },
  { key: "condusef", label: "Queja en CONDUSEF" },
  { key: "civil", label: "Demanda Civil" },
  { key: "mercantil", label: "Demanda Mercantil" },
];

export function etiqueta(arr: { key: string; label: string }[], k: string): string {
  return arr.find((x) => x.key === k)?.label || "—";
}

export async function fetchContingencia(clienteId: string): Promise<Contingencia | null> {
  const { data, error } = await supabase
    .from("contingencia_cliente")
    .select("*")
    .eq("cliente_id", clienteId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    tieneDemanda: !!data.tiene_demanda,
    quienDemanda: data.quien_demanda || "",
    tipo: data.tipo || "",
    abogado: data.abogado || "",
    etapa: data.etapa || "",
    nota: data.nota || "",
    avance: data.avance || "",
    apoderadoEmpresa: data.apoderado_empresa || "",
    clienteTieneApoderado: !!data.cliente_tiene_apoderado,
    apoderadoCliente: data.apoderado_cliente || "",
    expediente: data.expediente || "",
    jurisdiccion: data.jurisdiccion || "",
    ciudad: data.ciudad || "",
    quienRecibio: data.quien_recibio || "",
  };
}

export async function guardarContingencia(clienteId: string, c: Contingencia): Promise<boolean> {
  const { error } = await supabase.from("contingencia_cliente").upsert(
    {
      cliente_id: clienteId,
      tiene_demanda: c.tieneDemanda,
      quien_demanda: c.tieneDemanda ? (c.quienDemanda || null) : null,
      tipo: c.tieneDemanda ? (c.tipo || null) : null,
      abogado: c.tieneDemanda ? (c.abogado || null) : null,
      etapa: c.tieneDemanda ? (c.etapa || null) : null,
      nota: c.tieneDemanda ? (c.nota || null) : null,
      avance: c.tieneDemanda ? (c.avance || null) : null,
      apoderado_empresa: c.tieneDemanda ? (c.apoderadoEmpresa || null) : null,
      cliente_tiene_apoderado: c.tieneDemanda ? c.clienteTieneApoderado : false,
      apoderado_cliente: c.tieneDemanda && c.clienteTieneApoderado ? (c.apoderadoCliente || null) : null,
      expediente: c.tieneDemanda ? (c.expediente || null) : null,
      jurisdiccion: c.tieneDemanda ? (c.jurisdiccion || null) : null,
      ciudad: c.tieneDemanda ? (c.ciudad || null) : null,
      quien_recibio: c.tieneDemanda ? (c.quienRecibio || null) : null,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "cliente_id" },
  );
  return !error;
}
