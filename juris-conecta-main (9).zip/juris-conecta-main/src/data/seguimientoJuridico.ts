// ===================================================================
// Seguimiento jurídico cada 15 días  →  src/data/seguimientoJuridico.ts
// Bitácora de avances: estado procesal + avance + evidencia + próxima actuación.
// El borrado manda a la papelera (recuperable).
// ===================================================================
import { supabase } from "../lib/supabase";

export const DIAS_CICLO = 15;

export type SeguimientoJuridico = {
  id: string;
  clienteId: string;
  fecha: string;          // YYYY-MM-DD
  estadoProcesal: string;
  avance: string;
  evidencia: { url: string; nombre: string } | null;
  proximaActuacion: string;
  fechaProxima: string;   // YYYY-MM-DD o ""
  autor: string | null;
  createdAt: string;
};

function mapRow(r: any): SeguimientoJuridico {
  return {
    id: r.id,
    clienteId: r.cliente_id,
    fecha: r.fecha,
    estadoProcesal: r.estado_procesal || "",
    avance: r.avance || "",
    evidencia: r.evidencia || null,
    proximaActuacion: r.proxima_actuacion || "",
    fechaProxima: r.fecha_proxima || "",
    autor: r.autor,
    createdAt: r.created_at,
  };
}

// Lista activa (no en papelera).
export async function fetchSeguimientoJuridico(clienteId: string): Promise<SeguimientoJuridico[]> {
  const { data, error } = await supabase
    .from("seguimiento_juridico")
    .select("*")
    .eq("cliente_id", clienteId)
    .eq("en_papelera", false)
    .order("fecha", { ascending: false })
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data.map(mapRow);
}

// Lo que está en la papelera (para restaurar).
export async function fetchPapeleraJuridico(clienteId: string): Promise<SeguimientoJuridico[]> {
  const { data, error } = await supabase
    .from("seguimiento_juridico")
    .select("*")
    .eq("cliente_id", clienteId)
    .eq("en_papelera", true)
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data.map(mapRow);
}

export async function agregarSeguimientoJuridico(a: {
  clienteId: string;
  fecha: string;
  estadoProcesal: string;
  avance: string;
  evidencia?: { url: string; nombre: string } | null;
  proximaActuacion?: string;
  fechaProxima?: string;
  autor?: string | null;
}): Promise<SeguimientoJuridico | null> {
  const { data, error } = await supabase
    .from("seguimiento_juridico")
    .insert({
      cliente_id: a.clienteId,
      fecha: a.fecha,
      estado_procesal: a.estadoProcesal || null,
      avance: a.avance || null,
      evidencia: a.evidencia || null,
      proxima_actuacion: a.proximaActuacion || null,
      fecha_proxima: a.fechaProxima || null,
      autor: a.autor || null,
    })
    .select("*")
    .single();
  if (error || !data) return null;
  return mapRow(data);
}

// Mandar a la papelera (recuperable).
export async function mandarPapeleraJuridico(id: string): Promise<boolean> {
  const { error } = await supabase.from("seguimiento_juridico").update({ en_papelera: true }).eq("id", id);
  return !error;
}

// Restaurar desde la papelera.
export async function restaurarJuridico(id: string): Promise<boolean> {
  const { error } = await supabase.from("seguimiento_juridico").update({ en_papelera: false }).eq("id", id);
  return !error;
}

// Borrado definitivo (desde la papelera).
export async function borrarSeguimientoJuridico(id: string): Promise<boolean> {
  const { error } = await supabase.from("seguimiento_juridico").delete().eq("id", id);
  return !error;
}

// A partir de la última fecha registrada, calcula el siguiente (cada 15 días) y el atraso.
export function proximoCiclo(ultimaFecha: string | null): { proximaFecha: string | null; diasAtraso: number } {
  if (!ultimaFecha) return { proximaFecha: null, diasAtraso: 0 };
  const d = new Date(ultimaFecha + "T00:00:00");
  d.setDate(d.getDate() + DIAS_CICLO);
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  const diasAtraso = Math.floor((hoy.getTime() - d.getTime()) / 86400000);
  return { proximaFecha: d.toISOString().slice(0, 10), diasAtraso };
}
