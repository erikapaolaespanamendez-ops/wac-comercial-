// ===================================================================
// Cierre de caso  →  src/data/cierreCaso.ts
// Marca un caso como TERMINADO y guarda el detalle del cierre.
//   tipo "devolucion" -> total + ¿con compensación? (+ total2 a futuro)
//   tipo "entrega"    -> foto de evidencia (Drive). NO suma a KPIs.
// ===================================================================
import { supabase } from "../lib/supabase";
import { invalidarClientes } from "./clientes";

export type EvidenciaCierre = { url: string; nombre: string };

export type CierreCaso = {
  cliente_id: string;
  tipo: "devolucion" | "entrega";
  total: number | null;
  con_compensacion: boolean | null;
  compensacion: number | null;
  total2: number | null;
  val_apartado: number | null;
  val_firma: number | null;
  val_formalizaciones: number | null;
  val_otros: number | null;
  forma_pago: string | null;
  manera_pago: string | null;
  abonos: Array<{ fecha: string; monto: number; manera: string; evidencia: { url: string; nombre: string } | null }> | null;
  evidencia: EvidenciaCierre | null;
  evidencias?: EvidenciaCierre[] | null;   // 👈 NUEVO: galería (varias fotos). 'evidencia' queda como la 1ª, por compatibilidad.
  nota: string | null;
  terminado_por: string | null;
  created_at?: string;
};

// Guarda el cierre y marca el cliente como terminado.
export async function terminarCaso(p: {
  clienteId: string | number;
  tipo: "devolucion" | "entrega";
  total?: number | null;
  conCompensacion?: boolean | null;
  compensacion?: number | null;
  total2?: number | null;
  valApartado?: number | null;
  valFirma?: number | null;
  valFormalizaciones?: number | null;
  valOtros?: number | null;
  formaPago?: string | null;
  maneraPago?: string | null;
  abonos?: Array<{ fecha: string; monto: number; manera: string; evidencia: { url: string; nombre: string } | null }> | null;
  evidencia?: EvidenciaCierre | null;
  nota?: string | null;
  por?: string | null;
}): Promise<{ ok: boolean; error?: string }> {
  const id = String(p.clienteId);
  const { error: e1 } = await supabase.from("cierre_caso").upsert(
    {
      cliente_id: id,
      tipo: p.tipo,
      total: p.total ?? null,
      con_compensacion: p.conCompensacion ?? null,
      compensacion: p.compensacion ?? null,
      total2: p.total2 ?? null,
      val_apartado: p.valApartado ?? null,
      val_firma: p.valFirma ?? null,
      val_formalizaciones: p.valFormalizaciones ?? null,
      val_otros: p.valOtros ?? null,
      forma_pago: p.formaPago ?? null,
      manera_pago: p.maneraPago ?? null,
      abonos: p.abonos ?? null,
      evidencia: p.evidencia ?? null,
      nota: (p.nota || "").trim() || null,
      terminado_por: p.por ?? null,
    },
    { onConflict: "cliente_id" }
  );
  if (e1) return { ok: false, error: e1.message };

  const { error: e2 } = await supabase
    .from("clientes")
    .update({ terminado: true, terminado_tipo: p.tipo })
    .eq("id", id);
  invalidarClientes();
  if (e2) return { ok: false, error: e2.message };

  return { ok: true };
}

// Reabre el caso: lo quita de "Terminados" y borra el detalle del cierre.
export async function reabrirCaso(clienteId: string | number): Promise<{ ok: boolean; error?: string }> {
  const id = String(clienteId);
  const { error } = await supabase
    .from("clientes")
    .update({ terminado: false, terminado_tipo: null })
    .eq("id", id);
  invalidarClientes();
  if (error) return { ok: false, error: error.message };
  await supabase.from("cierre_caso").delete().eq("cliente_id", id);
  return { ok: true };
}

// Trae los cierres tipo DEVOLUCIÓN (para sumarlos en las KPIs).
export async function fetchCierresDevolucion(): Promise<CierreCaso[]> {
  const { data, error } = await supabase
    .from("cierre_caso")
    .select("*")
    .eq("tipo", "devolucion")
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data as CierreCaso[];
}
export async function fetchCierre(clienteId: string | number): Promise<CierreCaso | null> {
  const { data, error } = await supabase
    .from("cierre_caso")
    .select("*")
    .eq("cliente_id", String(clienteId))
    .maybeSingle();
  if (error || !data) return null;
  return data as CierreCaso;
}

// ===================================================================
// GALERÍA DE EVIDENCIAS (varias fotos de entrega)
// ===================================================================

// Junta la galería: la lista nueva (evidencias) + la foto vieja (evidencia)
// si no está repetida. Así no se pierde la foto de los casos ya cerrados.
export function galeriaEvidencias(c: CierreCaso | null): EvidenciaCierre[] {
  if (!c) return [];
  const lista = Array.isArray(c.evidencias) ? c.evidencias.filter((e) => e && e.url) : [];
  if (c.evidencia?.url && !lista.some((e) => e.url === c.evidencia!.url)) {
    return [c.evidencia, ...lista];
  }
  return lista;
}

// Agrega una o varias fotos de evidencia a un caso ya cerrado.
export async function agregarEvidencias(
  clienteId: string | number,
  nuevas: EvidenciaCierre[]
): Promise<{ ok: boolean; galeria?: EvidenciaCierre[]; error?: string }> {
  const id = String(clienteId);
  const actual = await fetchCierre(id);
  const galeria = galeriaEvidencias(actual);
  const limpias = (nuevas || []).filter((e) => e && e.url);
  const nueva = [...galeria, ...limpias];
  const { error } = await supabase
    .from("cierre_caso")
    .update({ evidencias: nueva, evidencia: nueva[0] ?? null })
    .eq("cliente_id", id);
  if (error) return { ok: false, error: error.message };
  return { ok: true, galeria: nueva };
}

// Quita una foto de la galería (la saca de la vista; el archivo permanece en Drive).
export async function quitarEvidencia(
  clienteId: string | number,
  url: string
): Promise<{ ok: boolean; galeria?: EvidenciaCierre[]; error?: string }> {
  const id = String(clienteId);
  const actual = await fetchCierre(id);
  const galeria = galeriaEvidencias(actual).filter((e) => e.url !== url);
  const { error } = await supabase
    .from("cierre_caso")
    .update({ evidencias: galeria, evidencia: galeria[0] ?? null })
    .eq("cliente_id", id);
  if (error) return { ok: false, error: error.message };
  return { ok: true, galeria };
}
