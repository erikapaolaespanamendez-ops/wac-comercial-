// =====================================================================
//  MÓDULO COMERCIAL · Niveles y visibilidad
//  →  src/data/niveles.ts
//
//  Dos reglas distintas, que no hay que confundir:
//
//  1. NIVEL DE MÓDULO — qué puedes HACER en una pantalla.
//     sin_acceso → ver → capturar → validar. Cada uno incluye al anterior.
//     · capturar = editar, pero lo que tocas queda pendiente de validación
//     · validar  = editar y que tu edición CIERRE el dato
//
//  2. VISIBILIDAD DE CAMPO — qué puedes VER de un dato sensible.
//     Es aparte del nivel: alguien puede tener nivel "ver" en Carteras
//     y aun así no ver el mínimo de la administradora.
//
//  Las dos viven en la BASE DE DATOS, no en el código, para que la DGE
//  las mueva desde Configuración sin esperar a que se publique nada.
// =====================================================================
import { supabase } from "../lib/supabase";

// ── Los cuatro niveles, del más bajo al más alto ─────────────────────
export const NIVELES = ["sin_acceso", "ver", "capturar", "validar"] as const;
export type Nivel = (typeof NIVELES)[number];

export const NIVEL_NOMBRE: Record<Nivel, string> = {
  sin_acceso: "Sin acceso",
  ver: "Ver",
  capturar: "Capturar",
  validar: "Validar",
};

export const NIVEL_EXPLICACION: Record<Nivel, string> = {
  sin_acceso: "No ve la pantalla",
  ver: "Solo lectura",
  capturar: "Llena y edita, queda pendiente de validación",
  validar: "Llena, edita y su edición cierra el dato",
};

// Las pantallas del módulo comercial que tienen nivel propio.
export type ModuloComercial = "carteras" | "administradoras" | "catalogo_garantias";

export const MODULO_COMERCIAL_NOMBRE: Record<ModuloComercial, string> = {
  carteras: "Carteras",
  administradoras: "Catálogo de administradoras",
  catalogo_garantias: "Catálogo de garantías",
};

// ── Lo que guarda la base para un rol y una pantalla ─────────────────
export type NivelModulo = {
  rol: string;
  modulo: ModuloComercial;
  nivel: Nivel;
  puedeDesbloquear: boolean;
  puedePedirApertura: boolean;
};

// La tabla ahora guarda TODO en un solo formato: rol · tipo · llave · nivel.
// Las pantallas del módulo comercial son las de tipo "pantalla", y los dos
// permisos que antes eran casillas (desbloquear / pedir apertura) ahora son
// acciones normales, con la llave "desbloquear_<pantalla>" y
// "pedir_apertura_<pantalla>" y nivel "permitida" o "sin_acceso".
export async function listarNiveles(): Promise<NivelModulo[]> {
  // ⚠️ PostgREST corta en 1000 renglones y la tabla trae más de 3,500,
  // así que hay que leerla por páginas o se pierden roles completos.
  const TAM = 1000;
  const filas: Record<string, unknown>[] = [];

  for (let desde = 0; ; desde += TAM) {
    const { data, error } = await supabase
      .from("nivel_modulo")
      .select("rol,tipo,llave,nivel")
      .order("rol", { ascending: true })
      .order("llave", { ascending: true })
      .range(desde, desde + TAM - 1);

    if (error) {
      console.warn("niveles · no se pudo leer:", error.message);
      return [];
    }
    const lote = (data ?? []) as unknown as Record<string, unknown>[];
    filas.push(...lote);
    if (lote.length < TAM) break;
  }

  // Primero junto las acciones, para saber quién puede desbloquear y pedir apertura.
  const permitida = new Set<string>();
  for (const f of filas) {
    if (f.tipo === "accion" && f.nivel === "permitida") {
      permitida.add(String(f.rol) + "|" + String(f.llave));
    }
  }

  return filas
    .filter((f) => f.tipo === "pantalla")
    .map((f) => {
      const rol = String(f.rol);
      const modulo = f.llave as ModuloComercial;
      return {
        rol,
        modulo,
        nivel: (f.nivel as Nivel) || "sin_acceso",
        puedeDesbloquear: permitida.has(rol + "|desbloquear_" + modulo),
        puedePedirApertura: permitida.has(rol + "|pedir_apertura_" + modulo),
      };
    });
}

export async function guardarNivel(n: NivelModulo, quien: string): Promise<boolean> {
  const cuando = new Date().toISOString();

  // Un solo viaje a la base: la pantalla y sus dos acciones, en el mismo formato.
  const filas = [
    { rol: n.rol, tipo: "pantalla", llave: n.modulo, nivel: n.nivel, actualizado_por: quien, actualizado_en: cuando },
    {
      rol: n.rol,
      tipo: "accion",
      llave: "desbloquear_" + n.modulo,
      nivel: n.puedeDesbloquear ? "permitida" : "sin_acceso",
      actualizado_por: quien,
      actualizado_en: cuando,
    },
    {
      rol: n.rol,
      tipo: "accion",
      llave: "pedir_apertura_" + n.modulo,
      nivel: n.puedePedirApertura ? "permitida" : "sin_acceso",
      actualizado_por: quien,
      actualizado_en: cuando,
    },
  ];

  const { error } = await supabase.from("nivel_modulo").upsert(filas, { onConflict: "rol,llave" });
  if (error) console.warn("niveles · no se pudo guardar:", error.message);
  return !error;
}

// ── Comparar niveles ─────────────────────────────────────────────────
// Como cada nivel incluye al anterior, basta con comparar posiciones.
function rango(n: Nivel): number {
  return NIVELES.indexOf(n);
}

export function alcanza(nivel: Nivel | undefined, minimo: Nivel): boolean {
  if (!nivel) return false;
  return rango(nivel) >= rango(minimo);
}

export function nivelDe(lista: NivelModulo[], rol: string | null, modulo: ModuloComercial): Nivel {
  if (!rol) return "sin_acceso";
  const fila = lista.find((n) => n.rol === rol && n.modulo === modulo);
  return fila ? fila.nivel : "sin_acceso";
}

export function puedeVerPantalla(lista: NivelModulo[], rol: string | null, m: ModuloComercial): boolean {
  return alcanza(nivelDe(lista, rol, m), "ver");
}
export function puedeCapturar(lista: NivelModulo[], rol: string | null, m: ModuloComercial): boolean {
  return alcanza(nivelDe(lista, rol, m), "capturar");
}
export function puedeValidar(lista: NivelModulo[], rol: string | null, m: ModuloComercial): boolean {
  return alcanza(nivelDe(lista, rol, m), "validar");
}

// ── Visibilidad de campos sensibles ──────────────────────────────────
export type CampoVisibilidad = {
  campo: string;
  etiqueta: string;
  rolesVen: string[];
  rolesEditan: string[];
  enmascarar: "codigo" | "ultimos4" | "oculto" | null;
  nota: string | null;
};

export async function listarVisibilidad(): Promise<CampoVisibilidad[]> {
  const { data, error } = await supabase
    .from("campo_visibilidad")
    .select("campo,etiqueta,roles_ven,roles_editan,enmascarar,nota");

  if (error) {
    console.warn("visibilidad · no se pudo leer:", error.message);
    return [];
  }
  const filas = (data ?? []) as unknown as Record<string, unknown>[];
  return filas.map((f) => ({
    campo: String(f.campo),
    etiqueta: String(f.etiqueta || ""),
    rolesVen: (f.roles_ven as string[]) ?? [],
    rolesEditan: (f.roles_editan as string[]) ?? [],
    enmascarar: (f.enmascarar as CampoVisibilidad["enmascarar"]) ?? null,
    nota: (f.nota as string) ?? null,
  }));
}

export function puedeVerCampo(lista: CampoVisibilidad[], rol: string | null, campo: string): boolean {
  const c = lista.find((x) => x.campo === campo);
  if (!c) return true;          // campo no restringido
  return !!rol && c.rolesVen.includes(rol);
}

export function puedeEditarCampo(lista: CampoVisibilidad[], rol: string | null, campo: string): boolean {
  const c = lista.find((x) => x.campo === campo);
  if (!c) return true;
  return !!rol && c.rolesEditan.includes(rol);
}

// ── Enmascarar ───────────────────────────────────────────────────────
// Quien no tiene permiso NO ve un hueco: ve una versión recortada, para
// que pueda seguir trabajando sin conocer el dato completo.
//   · codigo    → enseña el código en vez del nombre  (ADM-005)
//   · ultimos4  → enseña los últimos 4 dígitos        (••••3413)
//   · oculto    → no se enseña nada                   (—)
export function mostrarCampo(
  lista: CampoVisibilidad[],
  rol: string | null,
  campo: string,
  valor: string | null | undefined,
  alterno?: string | null,
): string {
  if (puedeVerCampo(lista, rol, campo)) return valor ?? "—";

  const c = lista.find((x) => x.campo === campo);
  const modo = c?.enmascarar ?? "oculto";

  if (modo === "codigo") return alterno || "—";
  if (modo === "ultimos4") {
    const limpio = (valor ?? "").replace(/\D/g, "");
    return limpio.length >= 4 ? "••••" + limpio.slice(-4) : "••••";
  }
  return "—";
}
