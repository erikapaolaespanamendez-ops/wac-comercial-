// =====================================================================
//  MÓDULO COMERCIAL · Datos de garantías
//  →  src/data/garantias.ts
//
//  Este archivo es el ÚNICO que habla con la tabla `garantia`. Ninguna
//  pantalla le pega directo a la base: todas pasan por aquí. Así, si un
//  día cambia un campo, se corrige en un solo lugar.
//
//  CAMBIO DEL 07-09-2026 — por qué se tocó:
//  La lista salía VACÍA aunque en la base sí hubiera garantías. La causa:
//  este archivo pedía cuatro columnas que no existen en la tabla
//  (costo_total, precio_piso, precio_autorizado y cartera). Cuando una
//  sola columna del `select` no existe, Supabase rechaza la consulta
//  COMPLETA, el error caía en el `catch` de abajo y se regresaba una
//  lista vacía. Nadie veía el error, solo el catálogo en blanco.
//  Ahora se piden los nombres verdaderos: precio_compra y precio_venta,
//  y el nombre de la cartera se trae con un enlace (join) por cartera_id.
// =====================================================================
import { supabase } from "../lib/supabase";
import { faltaParaMandar } from "../lib/jf-predictamen";
import { leerGaleria, type FotoGarantia } from "./fotos-garantia";

// ── Las etapas por las que pasa una garantía, en orden ───────────────
// El orden de este arreglo ES el orden de la línea de vida que se dibuja
// en la lista. Si se agrega una etapa, se agrega aquí y sale sola.
//
// OJO: estas claves NO son un invento de la aplicación. La base tiene un
// candado (un CHECK) que solo acepta exactamente estas palabras. Antes
// aquí decía "registrada" y "pre_dictamen", que la base rechaza; por eso
// se cambiaron a "en_cartera" y "en_predictamen".
export const ETAPAS = [
  { clave: "en_cartera",     nombre: "En cartera" },
  { clave: "en_predictamen", nombre: "Pre-dictamen" },
  { clave: "aprobada",       nombre: "Aprobada" },
  { clave: "publicada",      nombre: "Publicada" },
  { clave: "apartada",       nombre: "Apartada" },
  { clave: "vendida",        nombre: "Vendida" },
] as const;

export type EtapaClave = (typeof ETAPAS)[number]["clave"] | "cerrada";

// ── Cómo se ve una garantía dentro de la aplicación ──────────────────
export type Garantia = {
  id: string;
  folio: string;
  // El número de crédito del BANCO. No confundir con la referencia de la
  // administradora (el "HP…" de SECORSE), que va en su propio campo.
  numCredito: string | null;
  referenciaAdministradora: string | null;
  direccion: string;
  municipio: string | null;
  sucursal: string | null;
  tipoInmueble: string | null;
  m2Terreno: number | null;
  m2Construccion: number | null;
  recamaras: number | null;
  banos: number | null;
  estacionamientos: number | null;
  deudor: string | null;
  acreedor: string | null;
  // Nombre de la cartera (viene enlazado por cartera_id).
  cartera: string | null;
  // Código de la administradora dueña de esa cartera. El CÓDIGO se puede
  // enseñar a cualquiera; el NOMBRE solo a DGE y RAC — esa decisión la
  // toma la pantalla, no este archivo.
  administradoraCodigo: string | null;
  administradoraNombre: string | null;
  fotoFachada: string | null;
  mapsLink: string | null;
  // Coordenadas y datos que exige el envío a pre-dictamen.
  lat: number | null;
  lng: number | null;
  estadoMx: string | null;
  etapaProcesal: string | null;
  // Dinero. costoTotal = lo que costó adquirirla (precio_compra).
  // precioAutorizado = el precio de venta que autoriza la DGE.
  costoTotal: number | null;
  precioAutorizado: number | null;
  /** propuesto | aprobado — para que el catálogo enseñe el avance. */
  precioEstado: string | null;
  valorGarantia: number | null;
  avaluoComercial: number | null;
  etapa: EtapaClave;
  dictamenResultado: string | null;
  jfCasoId: string | null;
  clienteId: string | null;
  bloqueada: boolean;
};

// Los nombres de las columnas en la base van en snake_case (con guión
// bajo) y en la aplicación en camelCase. Esta función traduce de uno a
// otro para que las pantallas no tengan que saber cómo se llama en SQL.
function aGarantia(
  f: Record<string, unknown>,
  nombresAdmin: Map<string, string>,
): Garantia {
  // `cartera` llega como un objeto enlazado: { nombre, administradora_codigo }.
  // Si la garantía no tiene cartera, llega en nulo y no se truena nada.
  const car = (f.cartera ?? null) as { nombre?: string; administradora_codigo?: string } | null;
  const codigoAdmin = car?.administradora_codigo ?? null;

  return {
    id: String(f.id),
    folio: String(f.folio || ""),
    numCredito: (f.num_credito as string) ?? null,
    referenciaAdministradora: (f.referencia_administradora as string) ?? null,
    direccion: String(f.direccion || ""),
    municipio: (f.municipio as string) ?? null,
    sucursal: (f.sucursal as string) ?? null,
    tipoInmueble: (f.tipo_inmueble as string) ?? null,
    m2Terreno: (f.m2_terreno as number) ?? null,
    m2Construccion: (f.m2_construccion as number) ?? null,
    recamaras: (f.recamaras as number) ?? null,
    banos: (f.banos as number) ?? null,
    estacionamientos: (f.estacionamientos as number) ?? null,
    deudor: (f.deudor as string) ?? null,
    acreedor: (f.acreedor as string) ?? null,
    cartera: car?.nombre ?? null,
    administradoraCodigo: codigoAdmin,
    administradoraNombre: codigoAdmin ? (nombresAdmin.get(codigoAdmin) ?? null) : null,
    fotoFachada: (f.foto_fachada as string) ?? null,
    mapsLink: (f.maps_link as string) ?? null,
    lat: (f.lat as number) ?? null,
    lng: (f.lng as number) ?? null,
    estadoMx: (f.estado_mx as string) ?? null,
    etapaProcesal: (f.etapa_procesal as string) ?? null,
    costoTotal: (f.precio_compra as number) ?? null,
    precioEstado: (f.precio_estado as string) ?? null,
    valorGarantia: (f.valor_garantia as number) ?? null,
    precioAutorizado: (f.precio_venta as number) ?? null,
    avaluoComercial: (f.avaluo_comercial as number) ?? null,
    etapa: (f.etapa as EtapaClave) || "en_cartera",
    dictamenResultado: (f.dictamen_resultado as string) ?? null,
    jfCasoId: (f.jf_caso_id as string) ?? null,
    clienteId: (f.cliente_id as string) ?? null,
    bloqueada: Boolean(f.bloqueada),
  };
}

// Las columnas que se piden. TODAS existen en la tabla; si se agrega una
// que no existe, la consulta entera falla y la lista se ve vacía.
// El pedacito `cartera:cartera_id ( … )` es el enlace: trae el nombre de
// la cartera y el código de su administradora en el mismo viaje.
const COLUMNAS =
  "id,folio,num_credito,referencia_administradora,direccion,municipio,sucursal," +
  "tipo_inmueble,m2_terreno,m2_construccion,recamaras,banos,estacionamientos,deudor,acreedor,foto_fachada,maps_link," +
  "lat,lng,estado_mx,etapa_procesal," +
  "precio_compra,precio_venta,avaluo_comercial,etapa,dictamen_resultado," +
  "precio_estado,valor_garantia," +
  "jf_caso_id,cliente_id,bloqueada," +
  "cartera:cartera_id(nombre,administradora_codigo,es_proyecto)";

// ── Los nombres de las administradoras ───────────────────────────────
// Es una tabla chica (veinte renglones), así que se trae de un jalón y se
// arma un diccionario código → nombre. Se hace aparte y no enlazado para
// que, si esa tabla llegara a fallar, la lista de garantías igual salga:
// se vería el código y no el nombre, pero no se cae la pantalla.
async function nombresDeAdministradoras(): Promise<Map<string, string>> {
  const mapa = new Map<string, string>();
  const { data, error } = await supabase.from("administradora").select("codigo,nombre");
  if (error) {
    console.warn("administradora · no se pudo leer:", error.message);
    return mapa;
  }
  for (const f of (data ?? []) as unknown as Record<string, unknown>[]) {
    mapa.set(String(f.codigo), String(f.nombre));
  }
  return mapa;
}

// ── Traer todas las garantías activas ────────────────────────────────
// No trae las archivadas.
export async function listarGarantias(): Promise<Garantia[]> {
  const nombresAdmin = await nombresDeAdministradoras();

  const { data, error } = await supabase
    .from("garantia")
    .select(COLUMNAS)
    .eq("archivada", false)
    .order("folio", { ascending: false });

  if (error) {
    // Se avisa en consola con el texto exacto de Supabase. Si algún día
    // vuelve a salir la lista vacía, aquí dice por qué.
    console.warn("garantias · no se pudo leer:", error.message);
    return [];
  }
  // Supabase no conoce la forma de la tabla `garantia` (no hay tipos
  // generados), así que TypeScript no sabe si `data` trae renglones o un
  // error. Se pasa por `unknown` para decirle "yo sé lo que viene", que es
  // lo mismo que hacen los demás archivos de datos del proyecto.
  const filas = (data ?? []) as unknown as Record<string, unknown>[];

  // Las unidades de un DESARROLLO PROPIO (los locales de Plaza Leville)
  // no van en esta vitrina: no tienen crédito, ni deudor, ni juicio, y su
  // precio no sale de la calculadora de contingencia. Tienen su propia
  // pantalla, Catálogo de Proyectos. Se filtran aquí, en el único lugar
  // que lee la tabla, para que las tres vistas —Lista, Catálogo y Mapa—
  // queden parejas sin tocarlas una por una.
  const soloCesiones = filas.filter((f) => {
    const car = (f.cartera ?? null) as { es_proyecto?: boolean } | null;
    return !car?.es_proyecto;
  });

  return soloCesiones.map((f) => aGarantia(f, nombresAdmin));
}

// ── Los cuatro números de arriba de la pantalla ──────────────────────
// Se calculan aquí, con la lista que ya se trajo, para no hacer más
// viajes a la base.
export type ResumenCatalogo = {
  total: number;
  publicadas: number;
  apartadas: number;
  valorVitrina: number;
};

export function resumenCatalogo(lista: Garantia[]): ResumenCatalogo {
  let publicadas = 0;
  let apartadas = 0;
  let valorVitrina = 0;

  for (const g of lista) {
    if (g.etapa === "publicada") {
      publicadas++;
      valorVitrina += g.precioAutorizado || 0;
    }
    if (g.etapa === "apartada") apartadas++;
  }
  return { total: lista.length, publicadas, apartadas, valorVitrina };
}

// ── Qué precio se enseña, según la etapa ─────────────────────────────
// El mismo lugar de la pantalla dice CUATRO cosas distintas:
//   · sin precio de venta todavía     → "Sin autorizar", en gris
//   · con precio calculado, sin firmas → "Próximo precio", en ámbar
//   · con las tres firmas completas    → "Precio autorizado", en verde
//   · ya apartada o vendida            → "Precio de contrato", el congelado
// Así nadie confunde un número con otro.
//
//  CAMBIO DEL 08-09-2026 — por qué se tocó:
//  Antes esta función solo preguntaba si HABÍA monto, y con eso pintaba
//  "Precio autorizado" en verde. Resultado: un precio apenas calculado
//  por la calculadora se veía en la vitrina igual que uno ya firmado por
//  Contabilidad, Comercial y la Dirección, y comercial no tenía cómo
//  distinguirlos. Ahora también se mira la columna `precio_estado`
//  (propuesto / aprobado), que es la que dice si el precio ya pasó las
//  tres firmas.
//
//  OJO con las garantías viejas: si traen monto pero `precio_estado` en
//  nulo (se capturaron antes de que existiera la validación), se tratan
//  como PROPUESTO, no como aprobado. Es la salida prudente: es peor
//  enseñar como firmado algo que nadie firmó que pedir una firma de más.
export type EstadoPrecioMostrado = "contrato" | "aprobado" | "propuesto" | "ninguno";

export type PrecioMostrado = {
  etiqueta: string;
  monto: number | null;
  /** true solo cuando el precio ya está firmado o congelado en contrato. */
  autorizado: boolean;
  /** En cuál de los cuatro casos cayó. La pantalla pinta el color con esto. */
  estado: EstadoPrecioMostrado;
  nota: string | null;
};

export function precioMostrado(g: Garantia): PrecioMostrado {
  if (g.etapa === "apartada" || g.etapa === "vendida") {
    return {
      etiqueta: "Precio de contrato",
      monto: g.precioAutorizado,
      autorizado: true,
      estado: "contrato",
      nota: g.etapa === "vendida" ? "Vendida" : "Apartado pagado",
    };
  }
  if (g.precioAutorizado != null) {
    // Ya hay número. Falta ver si ese número ya lo firmaron.
    if (g.precioEstado === "aprobado") {
      return {
        etiqueta: "Precio autorizado",
        monto: g.precioAutorizado,
        autorizado: true,
        estado: "aprobado",
        nota: null,
      };
    }
    return {
      etiqueta: "Próximo precio",
      monto: g.precioAutorizado,
      autorizado: false,
      estado: "propuesto",
      nota: "En validación",
    };
  }
  return {
    etiqueta: "Precio de venta",
    monto: null,
    autorizado: false,
    estado: "ninguno",
    nota: "Sin autorizar",
  };
}

// ── Margen ───────────────────────────────────────────────────────────
// Cuánto le queda a la empresa sobre el precio de venta. Regresa null
// si falta alguno de los dos datos, para no enseñar un número inventado.
//
//  CAMBIO DEL 08-09-2026: además se exige que el precio esté APROBADO.
//  Un margen sacado de un precio que todavía se puede mover no es un
//  margen, es un borrador; y en cuanto el precio cambia, cambia solo,
//  porque sale de la misma tabla versionada que deja rastro.
//
// OJO: esto es información interna. La pantalla decide si lo muestra
// según el rol de quien entró.
export function margenPct(g: Garantia): number | null {
  const precio = g.precioAutorizado;
  if (!precio || !g.costoTotal) return null;
  if (g.precioEstado !== "aprobado") return null;
  return Math.round(((precio - g.costoTotal) / precio) * 100);
}

// ── ¿Ya se puede mandar a pre-dictaminar? ────────────────────────────
// Regla de la DGE: sin metros de construcción, sin foto de fachada y sin
// coordenadas, NO se manda.
//
// OJO — esta lista NO se escribe aquí a mano. Se usa la de
// src/lib/jf-predictamen.ts, que es la que de verdad frena el envío. Si
// se escribieran las reglas en dos lados, un día la pantalla diría "sí se
// puede" y el envío contestaría "falta algo". Una sola verdad.
/** Qué le falta a la garantía para poder PUBLICARSE en el catálogo.
 *
 *  Son los mismos datos que pedía el viejo "Completar datos", que ya no
 *  existe: todos se capturan en Editar garantía. Esta lista sirve para
 *  el indicador de la ficha, no para bloquear nada. */
export function faltaParaPublicar(g: Garantia): string[] {
  const falta: string[] = [];
  if (!g.fotoFachada) falta.push("foto");
  if (g.lat == null || g.lng == null) falta.push("link de mapas");
  if (!g.m2Construccion) falta.push("metros de construcción");
  return falta;
}

export function faltantesParaPredictamen(g: Garantia): string[] {
  return faltaParaMandar({
    id: g.id, folio: g.folio, numCredito: g.numCredito,
    administradoraCodigo: g.administradoraCodigo, direccion: g.direccion,
    deudor: g.deudor, estadoMx: g.estadoMx, etapaProcesal: g.etapaProcesal,
    m2Terreno: g.m2Terreno, m2Construccion: g.m2Construccion,
    avaluoComercial: g.avaluoComercial, fotoFachada: g.fotoFachada,
    lat: g.lat, lng: g.lng,
  });
}

export function sePuedeMandarAPredictamen(g: Garantia): boolean {
  return g.etapa === "en_cartera" && !g.bloqueada && faltantesParaPredictamen(g).length === 0;
}

// ── Nombre bonito de la etapa ────────────────────────────────────────
export function etapaNombre(clave: string): string {
  return ETAPAS.find((e) => e.clave === clave)?.nombre ?? clave;
}


// ── La ficha completa de UNA garantía ────────────────────────────────
// La lista de arriba trae lo justo para pintar renglones y tarjetas.
// Cuando se abre una garantía por dentro hacen falta más datos: colonia,
// código postal, adeudo, galería de fotos, etapa procesal. Eso se pide
// aparte y solo de esa garantía, para no cargar de más en la lista.
export type GarantiaFicha = Garantia & {
  // ---- lo del precio (momento 3) ----
  precioPiso: number | null;
  contingencia: string | null;
  adeudos: unknown;
  descuento: number | null;
  precioCalculado: number | null;
  precioMotivo: string | null;
  precioEstado: string | null;
  rutaPrecio: string | null;
  precioPorPiso: number | null;
  precioPorAvaluo: number | null;
  apartado: number | null;
  esquemaPagos: unknown;
  precioPor: string | null;
  precioEn: string | null;
  colonia: string | null;
  codigoPostal: string | null;
  valorGarantia: number | null;
  adeudoInicial: number | null;
  creditoInfonavit: string | null;
  saldoInfonavit: number | null;
  galeriaFotos: FotoGarantia[];
  jfPredictamenId: string | null;
  creadoPor: string | null;
  creadoEn: string | null;
};

const COLUMNAS_FICHA =
  COLUMNAS + ",colonia,codigo_postal,valor_garantia,adeudo_inicial," +
  "credito_infonavit,saldo_infonavit,galeria_fotos,jf_predictamen_id,creado_por,creado_en," +
  "precio_piso,contingencia,adeudos,descuento,precio_calculado,precio_motivo," +
  "precio_estado,precio_por,precio_en," +
  "ruta_precio,precio_por_piso,precio_por_avaluo,apartado,esquema_pagos";

export async function traerGarantia(id: string): Promise<GarantiaFicha | null> {
  const nombresAdmin = await nombresDeAdministradoras();

  const { data, error } = await supabase
    .from("garantia")
    .select(COLUMNAS_FICHA)
    .eq("id", id)
    .single();

  if (error || !data) {
    console.warn("garantia · no se pudo leer la ficha:", error?.message);
    return null;
  }
  const f = data as unknown as Record<string, unknown>;

  // La galería viene como lista en JSON. Cada foto lleva su liga y su
  // ETIQUETA (fachada, lateral, entre calles…). Las que se subieron
  // antes son texto suelto y se leen como "sin clasificar": de eso se
  // encarga leerGaleria, en src/data/fotos-garantia.ts.
  const galeria: FotoGarantia[] = leerGaleria(f.galeria_fotos);

  return {
    ...aGarantia(f, nombresAdmin),
    precioPiso: (f.precio_piso as number) ?? null,
    contingencia: (f.contingencia as string) ?? null,
    adeudos: (f.adeudos as unknown) ?? null,
    descuento: (f.descuento as number) ?? null,
    precioCalculado: (f.precio_calculado as number) ?? null,
    precioMotivo: (f.precio_motivo as string) ?? null,
    precioEstado: (f.precio_estado as string) ?? null,
    rutaPrecio: (f.ruta_precio as string) ?? null,
    precioPorPiso: (f.precio_por_piso as number) ?? null,
    precioPorAvaluo: (f.precio_por_avaluo as number) ?? null,
    apartado: (f.apartado as number) ?? null,
    esquemaPagos: (f.esquema_pagos as unknown) ?? null,
    precioPor: (f.precio_por as string) ?? null,
    precioEn: (f.precio_en as string) ?? null,
    colonia: (f.colonia as string) ?? null,
    codigoPostal: (f.codigo_postal as string) ?? null,
    valorGarantia: (f.valor_garantia as number) ?? null,
    adeudoInicial: (f.adeudo_inicial as number) ?? null,
    creditoInfonavit: (f.credito_infonavit as string) ?? null,
    saldoInfonavit: (f.saldo_infonavit as number) ?? null,
    galeriaFotos: galeria,
    jfPredictamenId: (f.jf_predictamen_id as string) ?? null,
    creadoPor: (f.creado_por as string) ?? null,
    creadoEn: (f.creado_en as string) ?? null,
  };
}

// ── Formato de dinero ────────────────────────────────────────────────
export function money(n: number | null | undefined): string {
  if (n == null) return "—";
  return "$" + Math.round(n).toLocaleString("es-MX");
}

// Versión corta para los números de arriba: $24.8M en vez de $24,800,000.
export function moneyCorto(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + Math.round(n / 1_000) + "K";
  return "$" + Math.round(n);
}

// =====================================================================
//  EL ORIGEN DE LA GARANTÍA
//
//  De qué administradora llegó, de qué cartera es y de qué mes de corte.
//  Vive en `garantia_origen`, que ya existe: aquí NO se crea nada nuevo,
//  solo se lee cruzando con `administradora` y `cartera`.
//
//  Una garantía puede tener VARIOS orígenes, porque el mismo fondo le
//  vende a varias administradoras. Cuando eso pasa, se comparan los
//  precios piso que pide cada una.
// =====================================================================
export type OrigenGarantia = {
  id: string;
  administradoraCodigo: string | null;
  administradoraNombre: string | null;
  carteraCodigo: string | null;
  carteraNombre: string | null;
  actor: string | null;
  corteMes: string | null;
  corteArchivo: string | null;
  precioPiso: number | null;
  yaNoAparece: boolean;
  yaNoApareceDesde: string | null;
};

export async function traerOrigenes(garantiaId: string): Promise<OrigenGarantia[]> {
  const { data, error } = await supabase
    .from("garantia_origen")
    .select(
      "id,administradora_codigo,corte_mes,corte_archivo,precio_piso,ya_no_aparece,ya_no_aparece_desde," +
        "administradora:administradora_codigo(nombre)," +
        "cartera:cartera_id(codigo,nombre,actor)",
    )
    .eq("garantia_id", garantiaId)
    .order("corte_mes", { ascending: false, nullsFirst: false });

  if (error || !data) return [];

  type Fila = {
    id: string;
    administradora_codigo: string | null;
    corte_mes: string | null;
    corte_archivo: string | null;
    precio_piso: number | null;
    ya_no_aparece: boolean;
    ya_no_aparece_desde: string | null;
    administradora: { nombre: string } | null;
    cartera: { codigo: string | null; nombre: string; actor: string | null } | null;
  };

  return (data as unknown as Fila[]).map((o) => ({
    id: o.id,
    administradoraCodigo: o.administradora_codigo,
    administradoraNombre: o.administradora?.nombre ?? null,
    carteraCodigo: o.cartera?.codigo ?? null,
    carteraNombre: o.cartera?.nombre ?? null,
    actor: o.cartera?.actor ?? null,
    corteMes: o.corte_mes,
    corteArchivo: o.corte_archivo,
    precioPiso: o.precio_piso,
    yaNoAparece: Boolean(o.ya_no_aparece),
    yaNoApareceDesde: o.ya_no_aparece_desde,
  }));
}

/** El mes de corte, escrito como se lee: "agosto 2026". */
export function mesCorte(iso: string | null): string {
  if (!iso) return "sin corte";
  return new Date(iso + "T12:00:00").toLocaleDateString("es-MX", { month: "long", year: "numeric" });
}
