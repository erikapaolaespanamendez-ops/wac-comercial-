import { supabase } from "../lib/supabase";

// Registro de "hasta dónde leyó" cada persona en cada canal del chat.
export type Lectura = { canalId: string; usuario: string; leidoHasta: string };

const norm = (s: string) => (s || "").trim().toLowerCase();

// Trae TODAS las lecturas (de todos): sirve para saber el "leído" de los demás.
export async function fetchLecturas(): Promise<Lectura[]> {
  const { data, error } = await supabase.from("lecturas_chat").select("canal_id, usuario, leido_hasta");
  if (error || !data) return [];
  return (data as any[]).map((r) => ({ canalId: String(r.canal_id), usuario: r.usuario, leidoHasta: r.leido_hasta }));
}

// Marca un canal como leído hasta cierto momento (default: ahora) para una persona.
export async function marcarLeidoServidor(canalId: string, usuarioNombre: string, hasta?: string): Promise<void> {
  const usuario = norm(usuarioNombre);
  if (!usuario || !canalId) return;
  try {
    await supabase.from("lecturas_chat").upsert(
      { canal_id: canalId, usuario, leido_hasta: hasta || new Date().toISOString() },
      { onConflict: "canal_id,usuario" }
    );
  } catch { /* silencioso: no debe romper el chat */ }
}

// Marca un canal como NO leído para una persona (pone su "leído hasta" muy atrás,
// así sus mensajes vuelven a contar como no leídos). Sirve para "marcar como no leído".
export async function marcarNoLeidoServidor(canalId: string, usuarioNombre: string): Promise<void> {
  const usuario = norm(usuarioNombre);
  if (!usuario || !canalId) return;
  try {
    await supabase.from("lecturas_chat").upsert(
      { canal_id: canalId, usuario, leido_hasta: new Date(0).toISOString() },
      { onConflict: "canal_id,usuario" }
    );
  } catch { /* silencioso */ }
}

// Cuenta los no leídos por canal para una persona:
// mensajes posteriores a su "leído hasta" y que NO son suyos.
export async function fetchConteosNoLeidos(yoNombre: string): Promise<Record<string, number>> {
  const yo = norm(yoNombre);
  const [{ data: msgs }, { data: lec }] = await Promise.all([
    // Pedimos SIEMPRE los más recientes (orden por fecha desc). Sin esto, Supabase
    // corta en 1,000 filas sin orden fijo y los mensajes nuevos a veces quedaban
    // fuera del conteo → la bolita de "no leído" parpadeaba y desaparecía.
    supabase
      .from("chat_mensajes")
      .select("canal_id, created_at, autor_nombre")
      .order("created_at", { ascending: false })
      .limit(1000),
    supabase.from("lecturas_chat").select("canal_id, leido_hasta").eq("usuario", yo),
  ]);
  const leido = new Map<string, number>();
  for (const r of (lec || []) as any[]) leido.set(String(r.canal_id), new Date(r.leido_hasta).getTime());
  const out: Record<string, number> = {};
  for (const m of (msgs || []) as any[]) {
    if (norm(m.autor_nombre) === yo) continue;
    const lh = leido.get(String(m.canal_id));
    if (lh == null || new Date(m.created_at).getTime() > lh) {
      out[String(m.canal_id)] = (out[String(m.canal_id)] || 0) + 1;
    }
  }
  return out;
}
