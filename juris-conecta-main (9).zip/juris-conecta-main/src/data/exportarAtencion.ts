// ===================================================================
// H6 — Exportar Atención  →  src/data/exportarAtencion.ts
// Excel (.xlsx) de los KPIs y de la lista de clientes, + impresión a PDF
// (usa la opción "Guardar como PDF" del navegador). No guarda nada en
// el servidor: todo se arma en el momento.
// ===================================================================
// xlsx se carga BAJO DEMANDA dentro de la función (import dinámico).
import { type ClienteSeguimiento, type EstadoSeguimiento } from "./seguimiento";

const COD_ORDEN = ["RV", "R1", "R1V", "R2", "R2C", "R3", "RD", "RDC", "SVT"];

export type Conteo = { total: number; alDia: number; porVencer: number; vencidos: number };

export function contar(arr: ClienteSeguimiento[]): Conteo {
  return {
    total: arr.length,
    alDia: arr.filter((x) => x.estado === "aldia").length,
    porVencer: arr.filter((x) => x.estado === "porvencer").length,
    vencidos: arr.filter((x) => x.estado === "vencido").length,
  };
}
export function cumpl(c: Conteo): number {
  return c.total ? Math.round(((c.total - c.vencidos) / c.total) * 100) : 0;
}
function diasDesde(iso: string | null): number | null {
  if (!iso) return null;
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
}
function agrupar(its: ClienteSeguimiento[], clave: (x: ClienteSeguimiento) => string): { nombre: string; c: Conteo }[] {
  const m = new Map<string, ClienteSeguimiento[]>();
  for (const x of its) {
    const k = clave(x) || "(Sin asignar)";
    if (!m.has(k)) m.set(k, []);
    m.get(k)!.push(x);
  }
  return Array.from(m.entries()).map(([nombre, arr]) => ({ nombre, c: contar(arr) }));
}

export type AgregadoAtencion = {
  resumen: Conteo;
  porArea: { nombre: string; c: Conteo }[];
  porSucursal: { nombre: string; c: Conteo }[];
  porCodigo: { nombre: string; c: Conteo }[];
  porColaborador: { nombre: string; c: Conteo }[];
  atendidos7: number;
};

export function agregarAtencion(items: ClienteSeguimiento[]): AgregadoAtencion {
  const its = items.filter((x) => x.diasLimite != null);
  return {
    resumen: contar(its),
    porArea: agrupar(its, (x) => x.cliente.area).sort((a, b) => b.c.total - a.c.total),
    porSucursal: agrupar(its, (x) => x.cliente.sucursal).sort((a, b) => b.c.total - a.c.total),
    porCodigo: agrupar(its, (x) => x.cliente.codigo).sort((a, b) => COD_ORDEN.indexOf(a.nombre) - COD_ORDEN.indexOf(b.nombre)),
    porColaborador: agrupar(its, (x) => x.cliente.asesorAsignado).sort((a, b) => b.c.total - a.c.total),
    atendidos7: its.filter((x) => { const dd = diasDesde(x.ultimoContacto); return dd != null && dd <= 7; }).length,
  };
}

const ESTADO_LABEL: Record<EstadoSeguimiento, string> = {
  vencido: "Vencido", porvencer: "Por vencer", aldia: "Al día", sinplazo: "Sin plazo",
};
function fechaCorta(iso: string | null): string {
  if (!iso) return "";
  try { return new Date(iso).toLocaleDateString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric" }); }
  catch { return ""; }
}
function hoyTxt(): string {
  return new Date().toLocaleDateString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric" }).replace(/\//g, "-");
}

// ---- Excel: KPIs (varias hojas) ----
export async function exportarKpisExcel(items: ClienteSeguimiento[]): Promise<void> {
  const XLSX = await import("xlsx"); // se baja solo al exportar
  const a = agregarAtencion(items);
  const wb = XLSX.utils.book_new();

  const resumen = [
    { Indicador: "En seguimiento", Valor: a.resumen.total },
    { Indicador: "Al día", Valor: a.resumen.alDia },
    { Indicador: "Por vencer", Valor: a.resumen.porVencer },
    { Indicador: "Vencidos", Valor: a.resumen.vencidos },
    { Indicador: "Cumplimiento (sin vencer)", Valor: `${cumpl(a.resumen)}%` },
    { Indicador: "Atendidos últimos 7 días", Valor: a.atendidos7 },
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(resumen), "Resumen");

  const tabla = (filas: { nombre: string; c: Conteo }[], etiqueta: string, conCumpl: boolean) =>
    filas.map((f) => ({
      [etiqueta]: f.nombre,
      "Total": f.c.total, "Al día": f.c.alDia, "Por vencer": f.c.porVencer, "Vencidos": f.c.vencidos,
      ...(conCumpl ? { "Cumplimiento": `${cumpl(f.c)}%` } : {}),
    }));

  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(tabla(a.porArea, "Área", true)), "Por área");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(tabla(a.porSucursal, "Sucursal", true)), "Por sucursal");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(tabla(a.porCodigo, "Código", false)), "Por código");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(tabla(a.porColaborador, "Colaborador", true)), "Por colaborador");

  XLSX.writeFile(wb, `KPIs_Atencion_${hoyTxt()}.xlsx`);
}

// ---- Excel: lista de clientes (1 fila por cliente) ----
export async function exportarClientesExcel(items: ClienteSeguimiento[]): Promise<void> {
  const XLSX = await import("xlsx"); // se baja solo al exportar
  const filas = items
    .filter((x) => x.diasLimite != null)
    .map((x) => ({
      "Folio": x.cliente.folio || "",
      "Cliente": x.cliente.nombre || "",
      "Código": x.cliente.codigo || "",
      "Estado": ESTADO_LABEL[x.estado],
      "Área": x.cliente.area || "",
      "Sucursal": x.cliente.sucursal || "",
      "Colaborador": x.cliente.asesorAsignado || "(Sin asignar)",
      "Última llamada": fechaCorta(x.ultimaLlamada),
      "Último correo": fechaCorta(x.ultimoCorreo),
      "Días desde contacto": x.diasDesdeCiclo ?? "",
      "Plazo (días)": x.diasLimite ?? "",
      "Riesgo legal": x.contingencia ? "Sí" : "",
      "Convenio": x.convenio ? "Sí" : "",
    }));
  const ws = XLSX.utils.json_to_sheet(filas);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Clientes");
  XLSX.writeFile(wb, `Clientes_Seguimiento_${hoyTxt()}.xlsx`);
}

// ---- PDF: abre una ventana lista para "Imprimir → Guardar como PDF" ----
function tablaHTML(titulo: string, etiqueta: string, filas: { nombre: string; c: Conteo }[], conCumpl: boolean): string {
  const cab = `<th>${etiqueta}</th><th>Total</th><th>Al día</th><th>Por vencer</th><th>Vencidos</th>${conCumpl ? "<th>Cumpl.</th>" : ""}`;
  const cuerpo = filas.map((f) =>
    `<tr><td>${f.nombre}</td><td class="c">${f.c.total}</td><td class="c v">${f.c.alDia}</td><td class="c a">${f.c.porVencer}</td><td class="c r">${f.c.vencidos}</td>${conCumpl ? `<td class="c b">${cumpl(f.c)}%</td>` : ""}</tr>`
  ).join("");
  return `<h2>${titulo}</h2><table><thead><tr>${cab}</tr></thead><tbody>${cuerpo}</tbody></table>`;
}

export function imprimirReporteAtencion(items: ClienteSeguimiento[]): void {
  const a = agregarAtencion(items);
  const html = `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>KPIs de Atención</title>
  <style>
    body{font-family:system-ui,Arial,sans-serif;color:#1f2937;padding:24px;}
    h1{font-size:20px;margin:0 0 2px;} .sub{color:#6b7280;font-size:12px;margin:0 0 16px;}
    h2{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:#0b7285;margin:18px 0 6px;}
    table{width:100%;border-collapse:collapse;font-size:12px;}
    th,td{padding:5px 7px;border-bottom:1px solid #e5e7eb;text-align:left;}
    td.c,th{ text-align:center;} td:first-child{text-align:left;}
    .v{color:#0f6e56;} .a{color:#854f0b;} .r{color:#a32d2d;} .b{font-weight:bold;}
    .cards{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0 4px;}
    .card{border:1px solid #e5e7eb;border-radius:8px;padding:8px 14px;} .card b{font-size:18px;}
    @media print{ .noprint{display:none;} }
  </style></head><body>
    <h1>KPIs de Atención — DIIPA</h1>
    <p class="sub">Generado el ${new Date().toLocaleString("es-MX")}</p>
    <div class="cards">
      <div class="card"><b>${a.resumen.total}</b><br>En seguimiento</div>
      <div class="card"><b style="color:#0f6e56">${a.resumen.alDia}</b><br>Al día</div>
      <div class="card"><b style="color:#854f0b">${a.resumen.porVencer}</b><br>Por vencer</div>
      <div class="card"><b style="color:#a32d2d">${a.resumen.vencidos}</b><br>Vencidos</div>
      <div class="card"><b>${cumpl(a.resumen)}%</b><br>Cumplimiento</div>
    </div>
    ${tablaHTML("Por área", "Área", a.porArea, true)}
    ${tablaHTML("Por sucursal", "Sucursal", a.porSucursal, true)}
    ${tablaHTML("Por código", "Código", a.porCodigo, false)}
    ${tablaHTML("Por colaborador", "Colaborador", a.porColaborador, true)}
    <p class="sub" style="margin-top:14px;">Atendidos últimos 7 días: <b>${a.atendidos7}</b></p>
    <script>window.onload=function(){window.print();}<\/script>
  </body></html>`;
  const w = window.open("", "_blank");
  if (!w) { alert("Permite las ventanas emergentes para generar el PDF."); return; }
  w.document.write(html);
  w.document.close();
}
