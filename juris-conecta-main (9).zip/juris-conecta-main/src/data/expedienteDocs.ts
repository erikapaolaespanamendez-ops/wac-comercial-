// ===================================================================
// Expediente y Evidencia del cliente  →  src/data/expedienteDocs.ts
// Una fila por (cliente + documento). Los archivos viven en Google Drive
// (se suben con la función subir-grabacion); aquí solo guardamos su
// nombre + link. Tabla: public.expediente_documentos.
// ===================================================================
import { supabase } from "../lib/supabase";

// Un archivo subido (puede haber varios por documento).
export type ArchivoDoc = {
  nombre: string;
  link: string;          // webViewLink de Drive
  driveId: string;
  mime?: string | null;
  subidoPor?: string | null;
  fecha?: string;        // ISO
};

export type EstadoDoc =
  | "en_espera"
  | "existe"
  | "positivo"
  | "negativo"
  | "validado"
  | "no";

export type DocExpediente = {
  id: string;
  clienteId: string;
  clave: string;                 // identificador del documento (ej. "apartado")
  estado: EstadoDoc | null;
  valor: number | null;
  valorFirma: number | null;
  tiempo: string | null;
  terminos: string | null;
  fecha: string | null;
  origen: string | null;         // "administradora" | "banco"
  validado: boolean;
  validadoPor: string | null;
  sigaLink: string | null;
  nota: string | null;
  archivos: ArchivoDoc[];
  // 👇 Cita de validación presencial. Tener el archivo NO es haber visto el
  // papel: cotejadoOriginal solo se prende en ventanilla, con el cliente ahí.
  fechaExpedicion: string | null;
  cotejadoOriginal: boolean;
  cotejadoPor: string | null;
  cotejadoEn: string | null;
  updatedAt: string;
};

function mapDoc(r: any): DocExpediente {
  let archivos: ArchivoDoc[] = [];
  try {
    archivos = Array.isArray(r.archivos) ? r.archivos : JSON.parse(r.archivos || "[]");
  } catch {
    archivos = [];
  }
  return {
    id: String(r.id),
    clienteId: String(r.cliente_id),
    clave: r.clave ?? "",
    estado: (r.estado as EstadoDoc) ?? null,
    valor: r.valor != null ? Number(r.valor) : null,
    valorFirma: r.valor_firma != null ? Number(r.valor_firma) : null,
    tiempo: r.tiempo ?? null,
    terminos: r.terminos ?? null,
    fecha: r.fecha ?? null,
    origen: r.origen ?? null,
    validado: !!r.validado,
    validadoPor: r.validado_por ?? null,
    sigaLink: r.siga_link ?? null,
    nota: r.nota ?? null,
    archivos,
    fechaExpedicion: r.fecha_expedicion ?? null,
    cotejadoOriginal: !!r.cotejado_original,
    cotejadoPor: r.cotejado_por ?? null,
    cotejadoEn: r.cotejado_en ?? null,
    updatedAt: r.updated_at ?? "",
  };
}

// Trae TODOS los documentos del expediente de un cliente.
export async function fetchExpediente(clienteId: string): Promise<DocExpediente[]> {
  if (!clienteId) return [];
  const { data, error } = await supabase
    .from("expediente_documentos")
    .select("*")
    .eq("cliente_id", String(clienteId));
  if (error) { console.error("No se pudo leer el expediente:", error.message); return []; }
  return (data || []).map(mapDoc);
}

// Campos que se pueden guardar de un documento.
export type CambiosDoc = Partial<{
  estado: EstadoDoc | null;
  valor: number | null;
  valorFirma: number | null;
  tiempo: string | null;
  terminos: string | null;
  fecha: string | null;
  origen: string | null;
  validado: boolean;
  validadoPor: string | null;
  sigaLink: string | null;
  nota: string | null;
  archivos: ArchivoDoc[];
  fechaExpedicion: string | null;
  cotejadoOriginal: boolean;
  cotejadoPor: string | null;
  cotejadoEn: string | null;
}>;

// Crea o actualiza el documento (clave) de un cliente. Upsert por (cliente_id, clave).
export async function guardarDoc(
  clienteId: string,
  clave: string,
  cambios: CambiosDoc
): Promise<DocExpediente | null> {
  const fila: any = { cliente_id: String(clienteId), clave, updated_at: new Date().toISOString() };
  if ("estado" in cambios) fila.estado = cambios.estado;
  if ("valor" in cambios) fila.valor = cambios.valor;
  if ("valorFirma" in cambios) fila.valor_firma = cambios.valorFirma;
  if ("tiempo" in cambios) fila.tiempo = cambios.tiempo;
  if ("terminos" in cambios) fila.terminos = cambios.terminos;
  if ("fecha" in cambios) fila.fecha = cambios.fecha;
  if ("origen" in cambios) fila.origen = cambios.origen;
  if ("validado" in cambios) fila.validado = cambios.validado;
  if ("validadoPor" in cambios) fila.validado_por = cambios.validadoPor;
  if ("sigaLink" in cambios) fila.siga_link = cambios.sigaLink;
  if ("nota" in cambios) fila.nota = cambios.nota;
  if ("archivos" in cambios) fila.archivos = cambios.archivos;
  if ("fechaExpedicion" in cambios) fila.fecha_expedicion = cambios.fechaExpedicion;
  if ("cotejadoOriginal" in cambios) fila.cotejado_original = cambios.cotejadoOriginal;
  if ("cotejadoPor" in cambios) fila.cotejado_por = cambios.cotejadoPor;
  if ("cotejadoEn" in cambios) fila.cotejado_en = cambios.cotejadoEn;

  const { data, error } = await supabase
    .from("expediente_documentos")
    .upsert(fila, { onConflict: "cliente_id,clave" })
    .select()
    .single();
  if (error) { console.error("No se pudo guardar el documento:", error.message); return null; }
  return mapDoc(data);
}

// Sube un archivo (base64) a la carpeta de Drive del cliente, en la
// subcarpeta "Expediente y Evidencia". Reutiliza la función subir-grabacion.
export async function subirArchivoDrive(p: {
  carpetaId: string;
  nombre: string;
  base64: string;
  subcarpeta?: string;
  mime?: string | null;   // 👈 tipo real del archivo (image/jpeg, application/pdf…). Si falta, Drive lo trataba como audio.
  publico?: boolean;      // 👈 si true, deja la foto visible por enlace (para mostrarla embebida en el CRM).
}): Promise<{ ok: boolean; id?: string; link?: string; nombre?: string; error?: string }> {
  try {
    const r = await fetch("/.netlify/functions/subir-grabacion", {
      method: "POST",
      body: JSON.stringify({
        archivo: p.base64,
        nombre: p.nombre,
        carpetaId: p.carpetaId,
        subcarpeta: p.subcarpeta || "Expediente y Evidencia",
        tipo: p.mime || undefined,   // 👈 se lo pasamos a la función para que Drive guarde el tipo correcto
        publico: p.publico || undefined,   // 👈 pide a la función que la comparta por enlace
      }),
    });
    const data = await r.json();
    if (!data.ok) return { ok: false, error: data.error || "Drive rechazó la subida" };
    return { ok: true, id: data.id, link: data.link, nombre: data.nombre };
  } catch (e: any) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}
