// GENERAR EXPEDIENTE EN DRIVE → va en: src/data/expediente.ts
import { type Cliente, etapaDe, guardarCarpetaDrive, leerCarpetaDrive } from "./clientes";

export type TipoExpediente = "Clientes" | "Prospectos" | "Otras";

// Convierte texto (con acentos) a base64 de forma segura en el navegador.
function textoABase64(s: string): string {
  return btoa(unescape(encodeURIComponent(s)));
}
// Quita caracteres que Drive no acepta en nombres de carpeta.
function limpio(s: string): string {
  return (s || "").replace(/[\\/:*?"<>|]/g, "-").trim();
}
// Nombre de la carpeta del expediente: Cliente · Autoriza X · Créd 123
function nombreCarpeta(c: Cliente): string {
  const partes: string[] = [c.nombre || "Sin nombre"];
  if (c.autorizadoNombre) partes.push("Autoriza " + c.autorizadoNombre);
  if (c.creditoSiga) partes.push("Créd " + c.creditoSiga);
  return limpio(partes.join(" · "));
}
// Texto de la "Ficha del expediente" (se guarda dentro de la carpeta).
function fichaTexto(c: Cliente, autor: string): string {
  const correo = c.email || "(PENDIENTE — agregar correo)";
  const autorizado =
    [c.autorizadoNombre, c.autorizadoTelefono, c.autorizadoCorreo].filter(Boolean).join(" · ") || "—";
  return [
    "FICHA DEL EXPEDIENTE — DIIPA",
    "",
    "Cliente: " + (c.nombre || "—"),
    "Teléfono: " + (c.telefono || "—") + (c.telefono2 ? "   Tel 2: " + c.telefono2 : ""),
    "Correo: " + correo,
    "WhatsApp: " + (c.whatsapp || "—"),
    "Persona autorizada: " + autorizado,
    "",
    "Garantía: " + (c.garantia || "—") + "   Expediente: " + (c.expediente || "—"),
    "SIGA → Folio: " + (c.folioSiga || "—") +
      "   Folio garantía: " + (c.folioGarantiaSiga || "—") +
      "   Crédito: " + (c.creditoSiga || "—"),
    "Estatus: " + (c.estatus || "—") + "   Código: " + (c.codigo || "—") + "   Área: " + (c.area || "—"),
    "",
    "Generado: " + new Date().toLocaleString("es-MX") + " por " + (autor || "—"),
  ].join("\n");
}
// Crea la carpeta del expediente en Drive con su ficha.
// RUTA NUEVA (Fase D.1):  Sucursal → Etapa → Registro
//   Ej:  Guadalajara → Apartados → Juan Pérez · Autoriza María · Créd 1234
// CANDADO: si el registro ya tiene carpeta guardada (c.carpetaDriveId), NO crea otra:
//   solo devuelve la que ya existe. Si no tiene, la crea y guarda su id en Supabase.
// El parámetro "tipo" se conserva por compatibilidad: solo se usa para mandar a la
//   carpeta "Otras" (lo usa el módulo Llamar/Grabar); en el flujo normal se ignora
//   y la etapa la decide etapaDe() según el registro.
export async function generarExpediente(
  c: Cliente,
  tipo: TipoExpediente = "Clientes"
): Promise<{ ok: boolean; link?: string; carpetaId?: string; etapa?: string; yaExistia?: boolean; error?: string }> {
  try {
    // 🔒 CANDADO: ya tiene carpeta → la abrimos, no creamos otra.
    //  Revisamos PRIMERO el dato que traemos en mano...
    let idGuardado = (c.carpetaDriveId || "").trim();
    let etapaGuardada = (c.carpetaDriveEtapa || "").trim();
    //  ...y si viene vacío, lo confirmamos EN VIVO contra la base (por si a la
    //  pantalla le llegó un cliente "viejo"). Así nunca se duplica la carpeta.
    if (!idGuardado) {
      try {
        const enVivo = await leerCarpetaDrive(String(c.id));
        if (enVivo.carpetaId) { idGuardado = enVivo.carpetaId; etapaGuardada = enVivo.etapa; }
      } catch {}
    }
    if (idGuardado) {
      return {
        ok: true,
        link: "https://drive.google.com/drive/folders/" + idGuardado,
        carpetaId: idGuardado,
        etapa: (etapaGuardada || etapaDe(c)),
        yaExistia: true,
      };
    }

    let autor = "Sistema";
    try {
      const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
      autor = y?.nombre || autor;
    } catch {}

    // Etapa: "Otras" solo si lo pide Llamar/Grabar; si no, la decide el registro.
    const etapa: string = tipo === "Otras" ? "Otras" : etapaDe(c);
    const sucursal = limpio((c.sucursal || "").trim() || "Sin sucursal");

    const ficha = fichaTexto(c, autor);
    const ruta = [sucursal, etapa, nombreCarpeta(c)];

    const r = await fetch("/.netlify/functions/subir-grabacion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        archivo: textoABase64(ficha),
        nombre: "Ficha del expediente.txt",
        tipo: "text/plain",
        ruta,
      }),
    });
    const data = await r.json();
    if (data && data.ok) {
      const carpetaId = data.carpeta || "";
      const link = carpetaId
        ? "https://drive.google.com/drive/folders/" + carpetaId
        : data.link;
      // 🔒 Guarda el id de la carpeta (candado) + la etapa en que quedó.
      if (carpetaId) {
        try { await guardarCarpetaDrive(c, carpetaId, etapa); } catch {}
      }
      return { ok: true, link, carpetaId, etapa, yaExistia: false };
    }
    return { ok: false, error: (data && data.error) || "No se pudo crear el expediente" };
  } catch (e: any) {
    return { ok: false, error: (e && e.message) || String(e) };
  }
}

// =====================================================================
//  FASE D.2 — Mover la carpeta de etapa cuando el registro avanza.
//  Compara la etapa donde está la carpeta (c.carpetaDriveEtapa) contra la
//  que le toca ahora (etapaDe). Si son distintas y ya tiene carpeta, la mueve
//  a  Sucursal → NuevaEtapa  y guarda la nueva etapa. No duplica nada.
// =====================================================================
export async function moverCarpetaEtapa(
  c: Cliente
): Promise<{ ok: boolean; movido: boolean; etapa?: string; error?: string }> {
  const idGuardado = (c.carpetaDriveId || "").trim();
  if (!idGuardado) return { ok: true, movido: false }; // no tiene carpeta → nada que mover

  const destino = etapaDe(c);
  const actual = (c.carpetaDriveEtapa || "").trim();
  if (actual === destino) return { ok: true, movido: false }; // ya está en su etapa

  const sucursal = limpio((c.sucursal || "").trim() || "Sin sucursal");
  try {
    const r = await fetch("/.netlify/functions/mover-expediente", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ carpetaId: idGuardado, sucursal, etapa: destino }),
    });
    const data = await r.json();
    if (data && data.ok) {
      // Guardamos la nueva etapa (mismo id de carpeta).
      try { await guardarCarpetaDrive(c, idGuardado, destino); } catch {}
      return { ok: true, movido: Boolean(data.movido), etapa: destino };
    }
    return { ok: false, movido: false, error: (data && data.error) || "No se pudo mover la carpeta" };
  } catch (e: any) {
    return { ok: false, movido: false, error: (e && e.message) || String(e) };
  }
}
