// =====================================================================
//  MÓDULO COMERCIAL · Datos de proyectos propios
//  →  src/data/proyectos.ts
//
//  Un PROYECTO es un desarrollo que DIIPA construye y vende por
//  unidades: Plaza Leville y sus ocho locales. No es una cartera de
//  cesión, aunque viva en la misma tabla `cartera`.
//
//  Se distinguen con la columna `es_proyecto`. No basta con mirar
//  tipo_origen='PRO', porque CAPTURA DIRECTA también es propia y no es
//  un desarrollo: es el cajón donde se capturan garantías sueltas.
//
//  Este archivo es el único que habla con la base para esta pantalla.
// =====================================================================
import { supabase } from "../lib/supabase";
// El mismo lector que usa el catálogo de garantías. Aguanta las fotos
// viejas (texto suelto) y las nuevas ({url, tipo}), así que aquí no se
// escribe otra vez esa lógica ni se desincroniza con el resto.
import { leerGaleria, type FotoGarantia } from "./fotos-garantia";

// ── Una unidad en venta (un local, un departamento, un lote) ─────────
export type Unidad = {
  id: string;
  folio: string;
  /** El número que ve el cliente: "Local 3". Sale de la dirección. */
  nombre: string;
  direccion: string;
  /** "planta baja" / "planta alta", si la dirección lo trae. */
  planta: string | null;
  m2: number | null;
  /** La plaza (GDL, MAZ...): la usa el filtro del mapa. */
  sucursal: string | null;
  precio: number | null;
  precioEstado: string | null;
  apartado: number | null;
  banos: number | null;
  fotoFachada: string | null;
  /** Planos y renders de esa unidad, en el orden en que se subieron. */
  galeria: FotoGarantia[];
  mapsLink: string | null;
  lat: number | null;
  lng: number | null;
  etapa: string;
};

// ── Formas de pago del desarrollo ────────────────────────────────────
// Viven en la cartera, no en el código, para que se puedan cambiar sin
// volver a publicar. Cada pago es un porcentaje del precio de la unidad.
export type PagoEsquema = {
  etiqueta: string;
  pct: number;
  /** Si viene, ese porcentaje se parte en tantas mensualidades. */
  meses?: number;
  momento?: string | null;
};

export type EsquemaPago = {
  clave: string;
  nombre: string;
  nota?: string | null;
  pagos: PagoEsquema[];
};

// ── Reglas de descuento del desarrollo ──────────────────────────────
export type Acabado = {
  clave: string;
  nombre: string;
  pct: number;
  incluye: string[];
  condicion?: string | null;
};

export type ReglasDescuento = {
  /** Hasta cuánto puede descontar el asesor sin pedir permiso. */
  comercialMaxPct: number;
  /** Quién autoriza si se pasa de ese tope. */
  comercialAutoriza: string;
  acabados: Acabado[];
  promocion: { titulo: string; incluye: string[] } | null;
};

export type Proyecto = {
  id: string;
  codigo: string | null;
  nombre: string;
  notas: string | null;
  logoUrl: string | null;
  precioM2: number | null;
  colorMarca: string;
  colorAcento: string;
  /** La fachada, para la portada. Sale de la primera unidad. */
  portada: string | null;
  /** Lo que se paga de apartado para entrar al proceso. */
  apartado: number | null;
  /** Cuota mensual de mantenimiento y administración de la plaza. */
  cuotaMantenimiento: number | null;
  esquemas: EsquemaPago[];
  reglas: ReglasDescuento | null;
  /** Contra qué pago se abona el apartado: "enganche" o "ultimo". */
  apartadoAplica: "enganche" | "ultimo";
  /** En cuántos meses se puede financiar el saldo. */
  plazoMin: number;
  plazoMax: number;
  /** El enganche de lista. Bajarlo necesita autorización. */
  engancheListaPct: number;
  /** Hasta dónde puede llegar el descuento, ya con autorización. */
  descuentoTopePct: number;
  /** El enganche no baja de aquí ni con autorización. */
  engancheMinPct: number;
  /** El apartado no baja de aquí. */
  apartadoMin: number;
  municipio: string | null;
  estado: string | null;
  direccion: string | null;
  unidades: Unidad[];
};

// De "Av. Insurgentes 26AE, Local 3, Plaza Leville (planta baja)" saca
// "Local 3" y "planta baja". Si la dirección no trae ese formato, se
// regresa la dirección tal cual y planta en nulo: nunca se rompe.
function partirDireccion(dir: string): { nombre: string; planta: string | null } {
  const planta = dir.match(/\(([^)]+)\)\s*$/)?.[1] ?? null;
  const unidad = dir.match(/(Local|Depto\.?|Departamento|Lote|Casa)\s+[\w-]+/i)?.[0] ?? null;
  return { nombre: unidad ?? dir, planta };
}

const COLS_UNIDAD =
  "id,folio,direccion,m2_construccion,precio_venta,precio_estado,apartado," +
  "banos,foto_fachada,galeria_fotos,maps_link,lat,lng,etapa,archivada,cartera_id";

export async function listarProyectos(): Promise<Proyecto[]> {
  const { data: cart, error } = await supabase
    .from("cartera")
    .select("id,codigo,nombre,notas,logo_url,precio_m2,color_marca,color_acento," +
            "apartado,cuota_mantenimiento,esquemas_pago,reglas_descuento," +
            "apartado_aplica,plazo_min,plazo_max,enganche_lista_pct," +
            "descuento_tope_pct,enganche_min_pct,apartado_min")
    .eq("es_proyecto", true)
    .neq("estatus", "archivada")
    .order("codigo");

  if (error) {
    console.warn("proyectos · no se pudo leer:", error.message);
    return [];
  }

  const carteras = (cart ?? []) as unknown as Record<string, unknown>[];
  if (!carteras.length) return [];

  const ids = carteras.map((c) => String(c.id));
  const { data: gar } = await supabase
    .from("garantia")
    .select(COLS_UNIDAD + ",municipio,estado_mx,sucursal")
    .in("cartera_id", ids)
    .eq("archivada", false)
    .order("folio");

  const filas = (gar ?? []) as unknown as Record<string, unknown>[];

  return carteras.map((c) => {
    const mias = filas.filter((f) => String(f.cartera_id) === String(c.id));
    const primera = mias[0];

    return {
      id: String(c.id),
      codigo: (c.codigo as string) ?? null,
      nombre: String(c.nombre || ""),
      notas: (c.notas as string) ?? null,
      logoUrl: (c.logo_url as string) ?? null,
      precioM2: (c.precio_m2 as number) ?? null,
      colorMarca: (c.color_marca as string) || "#0C2E66",
      colorAcento: (c.color_acento as string) || "#C9A227",
      portada: (primera?.foto_fachada as string) ?? null,
      apartado: (c.apartado as number) ?? null,
      cuotaMantenimiento: (c.cuota_mantenimiento as number) ?? null,
      esquemas: leerEsquemas(c.esquemas_pago),
      reglas: leerReglas(c.reglas_descuento),
      apartadoAplica: c.apartado_aplica === "ultimo" ? "ultimo" : "enganche",
      plazoMin: Number(c.plazo_min) || 6,
      plazoMax: Number(c.plazo_max) || 12,
      engancheListaPct: Number(c.enganche_lista_pct) || 35,
      descuentoTopePct: Number(c.descuento_tope_pct) || 0,
      engancheMinPct: Number(c.enganche_min_pct) || 0,
      apartadoMin: Number(c.apartado_min) || 0,
      municipio: (primera?.municipio as string) ?? null,
      estado: (primera?.estado_mx as string) ?? null,
      // La dirección del proyecto es la de sus unidades sin el número:
      // todas comparten domicilio.
      direccion: primera
        ? String(primera.direccion).replace(/,\s*(Local|Depto\.?|Lote|Casa)\s+[\w-]+/i, "")
                                    .replace(/\s*\([^)]*\)\s*$/, "")
        : null,
      unidades: mias.map((f) => {
        const dir = String(f.direccion || "");
        const { nombre, planta } = partirDireccion(dir);
        return {
          id: String(f.id),
          folio: String(f.folio || ""),
          nombre,
          direccion: dir,
          planta,
          m2: (f.m2_construccion as number) ?? null,
          sucursal: (f.sucursal as string) ?? null,
          precio: (f.precio_venta as number) ?? null,
          precioEstado: (f.precio_estado as string) ?? null,
          apartado: (f.apartado as number) ?? null,
          banos: (f.banos as number) ?? null,
          fotoFachada: (f.foto_fachada as string) ?? null,
          galeria: leerGaleria(f.galeria_fotos),
          mapsLink: (f.maps_link as string) ?? null,
          lat: (f.lat as number) ?? null,
          lng: (f.lng as number) ?? null,
          etapa: String(f.etapa || "en_cartera"),
        };
      }),
    };
  });
}

// Lee la columna `esquemas_pago`. Si trae basura o viene vacía, se
// regresa una lista vacía y la ficha simplemente no enseña esa parte:
// nunca se inventa un esquema de pago.
function leerEsquemas(bruto: unknown): EsquemaPago[] {
  if (!Array.isArray(bruto)) return [];
  const salida: EsquemaPago[] = [];
  for (const x of bruto) {
    if (!x || typeof x !== "object") continue;
    const e = x as Record<string, unknown>;
    const pagos = Array.isArray(e.pagos) ? e.pagos : [];
    const limpios: PagoEsquema[] = [];
    for (const y of pagos) {
      if (!y || typeof y !== "object") continue;
      const pg = y as Record<string, unknown>;
      const pct = Number(pg.pct);
      if (!Number.isFinite(pct)) continue;
      limpios.push({
        etiqueta: String(pg.etiqueta || ""),
        pct,
        meses: Number.isFinite(Number(pg.meses)) ? Number(pg.meses) : undefined,
        momento: (pg.momento as string) ?? null,
      });
    }
    if (!limpios.length) continue;
    salida.push({
      clave: String(e.clave || ""),
      nombre: String(e.nombre || ""),
      nota: (e.nota as string) ?? null,
      pagos: limpios,
    });
  }
  return salida;
}

// Lee `reglas_descuento`. Si viene vacía se regresa nulo y la ficha
// simplemente no enseña la calculadora: nunca se inventa un tope.
function leerReglas(bruto: unknown): ReglasDescuento | null {
  if (!bruto || typeof bruto !== "object" || Array.isArray(bruto)) return null;
  const r = bruto as Record<string, unknown>;

  const acabados: Acabado[] = [];
  for (const x of Array.isArray(r.acabados) ? r.acabados : []) {
    if (!x || typeof x !== "object") continue;
    const a = x as Record<string, unknown>;
    const pct = Number(a.pct);
    acabados.push({
      clave: String(a.clave || ""),
      nombre: String(a.nombre || ""),
      pct: Number.isFinite(pct) ? pct : 0,
      incluye: Array.isArray(a.incluye)
        ? (a.incluye as unknown[]).filter((y): y is string => typeof y === "string")
        : [],
      condicion: (a.condicion as string) ?? null,
    });
  }

  const promo = r.promocion_precio_lista as Record<string, unknown> | undefined;

  return {
    comercialMaxPct: Number.isFinite(Number(r.comercial_max_pct)) ? Number(r.comercial_max_pct) : 0,
    comercialAutoriza: String(r.comercial_autoriza || "Gerencia Comercial"),
    acabados,
    promocion: promo && typeof promo === "object"
      ? {
          titulo: String(promo.titulo || ""),
          incluye: Array.isArray(promo.incluye)
            ? (promo.incluye as unknown[]).filter((y): y is string => typeof y === "string")
            : [],
        }
      : null,
  };
}

// ── Formato de dinero ────────────────────────────────────────────────
export function money(n: number | null | undefined): string {
  if (n == null) return "—";
  return "$" + Math.round(n).toLocaleString("es-MX");
}

// Agrupa las unidades por planta, conservando el orden en que vienen.
// Si ninguna trae planta, regresa un solo grupo sin título.
export function porPlanta(us: Unidad[]): { titulo: string | null; unidades: Unidad[] }[] {
  const grupos: { titulo: string | null; unidades: Unidad[] }[] = [];
  for (const u of us) {
    const t = u.planta;
    const ultimo = grupos[grupos.length - 1];
    if (ultimo && ultimo.titulo === t) ultimo.unidades.push(u);
    else grupos.push({ titulo: t, unidades: [u] });
  }
  return grupos;
}
