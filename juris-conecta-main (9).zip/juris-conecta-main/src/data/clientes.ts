import { supabase } from "../lib/supabase";
import { avisarEvento } from "./avisarEvento"; // 👈 NUEVO
import type { AccionCodigo } from "./catalogoCodigos"; // 👈 FASE F2

// =====================================================================
//  CLIENTES  —  los datos vienen de Supabase. Aquí quedan los "tipos",
//  el semáforo de estatus, los códigos, y las funciones (traer / guardar).
// =====================================================================

export type Estatus =
  | "apartado"
  | "proceso"
  | "juicio"
  | "formalizacion"
  | "entregado"
  | "riesgo"
  | "cancelado"
  | "devolucion"
  | "negativo_r1";

export const ESTATUS: Record<Estatus, { label: string; punto: string; chip: string }> = {
  apartado:      { label: "En apartado",            punto: "bg-emerald-500", chip: "bg-emerald-50 text-emerald-700" },
  proceso:       { label: "En proceso · Fase A",     punto: "bg-yellow-400",  chip: "bg-yellow-50 text-yellow-700" },
  juicio:        { label: "En juicio · Fase B",      punto: "bg-orange-500",  chip: "bg-orange-50 text-orange-700" },
  formalizacion: { label: "En formalización · Fase C", punto: "bg-blue-500",  chip: "bg-blue-50 text-blue-700" },
  entregado:     { label: "Entregado",               punto: "bg-teal",        chip: "bg-teal-soft text-teal-dark" },
  riesgo:        { label: "En riesgo",               punto: "bg-amber-500",   chip: "bg-amber-50 text-amber-700" },
  cancelado:     { label: "Cancelado · Devuelto",    punto: "bg-rose-500",    chip: "bg-rose-50 text-rose-700" },
  devolucion:    { label: "En devolución",           punto: "bg-fuchsia-500", chip: "bg-fuchsia-50 text-fuchsia-700" },
  negativo_r1:   { label: "Negativo · R1",           punto: "bg-slate-500",   chip: "bg-slate-100 text-slate-700" },
};

// Cuando el estatus guardado NO es ninguno de los de arriba.
// Pasa porque en algunas fichas se capturaron notas completas en la casilla
// del estatus. Antes el sistema se caía al no encontrarlo; ahora lo pinta en
// gris, recorta el texto para que no rompa la pantalla y deja el original en
// el título, para que se pueda leer completo al pasar el cursor.
const ESTATUS_DESCONOCIDO = { punto: "bg-slate-400", chip: "bg-slate-100 text-slate-600" };

export type EstatusVista = { label: string; punto: string; chip: string; textoCompleto: string; conocido: boolean };

export function estatusDe(valor: string | null | undefined): EstatusVista {
  const bruto = (valor ?? "").trim();
  const conocido = ESTATUS[bruto as Estatus];
  if (conocido) return { ...conocido, textoCompleto: conocido.label, conocido: true };

  if (!bruto) return { ...ESTATUS_DESCONOCIDO, label: "Sin estatus", textoCompleto: "Sin estatus", conocido: false };

  // Se queda con la primera línea y a lo más 40 caracteres.
  const primeraLinea = bruto.split(/[\n|·]/)[0].trim();
  const corto = primeraLinea.length > 40 ? primeraLinea.slice(0, 40).trimEnd() + "…" : primeraLinea;
  return { ...ESTATUS_DESCONOCIDO, label: corto, textoCompleto: bruto, conocido: false };
}

// 👇 Los 9 códigos del catálogo oficial (tabla `catalogo_codigos`). El orden
// es el mismo campo `orden` del catálogo. Aquí solo viven la clave y una
// etiqueta corta para las pastillas de pantalla; la definición completa
// (área dueña, ritmo, días límite, escalamiento, salidas) vive SIEMPRE en la
// base, no aquí.
export type Codigo = "SVT" | "RV" | "R1" | "R1V" | "R2" | "R2C" | "R3" | "RD" | "RDC";

export const CODIGO: Record<Codigo, string> = {
  SVT: "Recién firmado",
  RV: "Seguimiento mensual",
  R1: "Sensible",
  R1V: "Sensible · 2 dictámenes negativos",
  R2: "En juicio",
  R2C: "Con contingencia",
  R3: "Cambio concluido",
  RD: "Devolución sin compensación",
  RDC: "Devolución compensada",
};

export type Area = "Comercial" | "RAC" | "Admin" | "Jurídico" | "UFC";

// 👇 NUEVO: un registro puede ser PROSPECTO o ya CLIENTE.
export type TipoRegistro = "prospecto" | "cliente";

// 👇 NUEVO (Fase E.1): un renglón del historial de asesores de un registro.
export interface AsesorHistorial {
  nombre: string;
  correo: string;
  asignadoPor: string; // quién lo asignó en su momento
  desde: string;       // cuándo se le asignó
  hasta: string;       // cuándo se le quitó (al reasignar)
}

export interface Cliente {
  id: string;
  nombre: string;
  curpRfc: string;
  ine: string;
  estadoCivil: string;
  conyuge?: string;
  conyugeNotificado?: boolean;
  domicilio: string;
  telefono: string;
  telefono2: string;
  email: string;
  whatsapp: string;
  comoConocio: string;
  refirio: string;
  valorFirma: string;
  montoApartado: string;
  segundosPagos: string;
  pagoCesion: string;
  pagoEscritura: string;
  pagoGestoria: string;
  otrosPagos: string;
  tieneSolicitudDevolucion: boolean;
  fechaSolicitudDevolucion: string;
  docSolicitudDevolucion: { url: string; nombre: string } | null;
  autorizadoNombre: string;
  autorizadoTelefono: string;
  autorizadoCorreo: string;
  prospecto: string;
  garantia: string;
  expediente: string;
  folioSiga: string;
  folioGarantiaSiga: string;
  creditoSiga: string;
  fechaFirma: string;
  estatus: Estatus;
  codigo: Codigo;
  // 👇 FASE F: regla especial por cliente (si están vacíos, usa la regla del código)
  overrideDiasLimite?: number | null;
  overrideDiasAviso?: number | null;
  overrideResponsable?: string | null;
  overrideAcciones?: AccionCodigo[] | null;
  area: Area;
  nomenclaturaValidada: boolean;
  fechaVencimiento: string;   // 👈 fecha en que vence el contrato (firma + 15 meses hábiles)
  archivado: boolean;
  terminado: boolean;
  terminadoTipo: string | null;   // 'devolucion' | 'entrega' | null
  ultimaActuacionAt: string;      // 👈 FASE 2: fecha de la última actuación/cambio (reloj para ordenar)
  eliminado: boolean;
  folio: string;
  folioCierre: string;
  // 👇 NUEVO: prospecto/cliente + vínculo SIGA manual
  tipo: TipoRegistro;
  direccionGarantia: string;
  fechaConversion: string;
  convertidoPor: string;
  // 👇 NUEVO: validación de datos en sucursal contra el contrato físico
  // (candado para RDC: hasta que esto sea true, la Solicitud Formal no
  // puede tomar estos datos como confiables)
  datosValidadosSucursal: boolean;
  validadoSucursalPor: string | null;
  fechaValidadoSucursal: string | null;
  // 👇 Cita de validación presencial. requiereCitaSucursal es la BANDERA: el
  // cliente tiene devolución abierta y debe presentarse con sus documentos
  // antes de que se le habilite la Solicitud Formal. validacionPresencialEn es
  // lo único que acredita que ya vino; las banderas viejas no valían.
  requiereCitaSucursal: boolean;
  citaSucursalMotivo: string | null;
  citaSucursalDocumentos: string | null;
  validacionPresencialEn: string | null;
  validacionPresencialPor: string | null;
  // 👇 NUEVO: candado de edición de la DGE. Es DISTINTO de
  // datosValidadosSucursal (cotejo contra contrato físico) y de
  // nomenclaturaValidada (código correcto). Cuando bloqueado es true,
  // la ficha es de SOLO LECTURA: se pueden AGREGAR abonos, actuaciones
  // y notas, pero no editar ni borrar lo ya confirmado.
  bloqueado: boolean;
  bloqueadoPor: string | null;
  bloqueadoEn: string | null;
  motivoBloqueo: string | null;
  ineDoc: { url: string; nombre: string } | null;
  comprobanteDomicilioDoc: { url: string; nombre: string } | null;
  curpDoc: { url: string; nombre: string } | null;
  datosLlenadosSucursalEn: string | null;
  datosLlenadosSucursalPor: string | null;
  // 👇 NUEVO (Fase B): asesor a cargo
  asesorAsignado: string;
  asesorCorreo: string;
  asesorAsignadoPor: string;
  fechaAsignacion: string;
  // 👇 NUEVO (Fase E.1): historial de quién ha tenido este registro
  historialAsesores: AsesorHistorial[];
  // 👇 NUEVO (Fase D.1): sucursal + carpeta de Drive (con candado)
  sucursal: string;            // GDL / MAZ / CUL / LAP → guardamos el NOMBRE (ej. "Guadalajara")
  carpetaDriveId: string;      // id de la carpeta ya creada (el candado: si está, no se duplica)
  carpetaDriveEtapa: string;   // en qué etapa quedó la carpeta (Prospectos/Apartados/Clientes) → lo usa D.2
  // 👇 NUEVO (Mejora B): indicador del R3
  r3Tipo: string;              // cómo cerró: "devolucion" | "entrega" | ""
  r3Seguimiento: boolean;      // ¿sigue requiriendo seguimiento? (true = pendiente; false = terminó del todo)
  r3DireccionNueva: string;    // nueva dirección (garantía del cambio)
  r3ValorNuevo: string;        // valor nuevo
  r3Terminos: string;          // términos y condiciones del nuevo contrato
  r3DocCambio: { url: string; nombre: string } | null;  // contrato / solicitud de cambio
}

// 👇 NUEVO (Fase D.1): las tres etapas que ordenan el expediente en Drive.
export type EtapaExpediente = "Prospectos" | "Apartados" | "Clientes";

// Decide SOLA en qué etapa va el registro (no se captura a mano):
//  - Prospecto                         → Prospectos
//  - Cliente y todavía "En apartado"   → Apartados
//  - Cliente ya más avanzado           → Clientes
// Esto deja listo el D.2, que solo va a MOVER la carpeta cuando cambie la etapa.
export function etapaDe(c: Cliente): EtapaExpediente {
  if (c.tipo === "prospecto") return "Prospectos";
  if (c.estatus === "apartado") return "Apartados";
  return "Clientes";
}

// 👇 NUEVO: lee quién está usando la app ahora mismo (para decir quién registró al cliente).
function quienSoy(): string {
  try {
    const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
    return y?.nombre || "Alguien";
  } catch { return "Alguien"; }
}

// Convierte un renglón de Supabase (snake_case) al Cliente que usa la app.
function mapearCliente(f: Record<string, unknown>): Cliente {
  return {
    id: String(f.id),
    nombre: (f.nombre as string) ?? "",
    curpRfc: (f.curp_rfc as string) ?? "",
    ine: (f.ine as string) ?? "",
    estadoCivil: (f.estado_civil as string) ?? "",
    conyuge: (f.conyuge as string) ?? undefined,
    conyugeNotificado: Boolean(f.conyuge_notificado),
    domicilio: (f.domicilio as string) ?? "",
    telefono: (f.telefono as string) ?? "",
    telefono2: (f.telefono2 as string) ?? "",
    email: (f.email as string) ?? "",
    whatsapp: (f.whatsapp as string) ?? "",
    comoConocio: (f.como_conocio as string) ?? "",
    refirio: (f.refirio as string) ?? "",
    valorFirma: (f.valor_firma as string) ?? "",
    montoApartado: (f.monto_apartado as string) ?? "",
    segundosPagos: (f.segundos_pagos as string) ?? "",
    pagoCesion: (f.pago_cesion as string) ?? "",
    pagoEscritura: (f.pago_escritura as string) ?? "",
    pagoGestoria: (f.pago_gestoria as string) ?? "",
    otrosPagos: (f.otros_pagos as string) ?? "",
    tieneSolicitudDevolucion: !!f.tiene_solicitud_devolucion,
    fechaSolicitudDevolucion: (f.fecha_solicitud_devolucion as string) ?? "",
    docSolicitudDevolucion: (f.doc_solicitud_devolucion as { url: string; nombre: string }) ?? null,
    autorizadoNombre: (f.autorizado_nombre as string) ?? "",
    autorizadoTelefono: (f.autorizado_telefono as string) ?? "",
    autorizadoCorreo: (f.autorizado_correo as string) ?? "",
    prospecto: (f.prospecto as string) ?? "",
    garantia: (f.garantia as string) ?? "",
    expediente: (f.expediente as string) ?? "",
    folioSiga: (f.folio_siga as string) ?? "",
    folioGarantiaSiga: (f.folio_garantia_siga as string) ?? "",
    creditoSiga: (f.credito_siga as string) ?? "",
    fechaFirma: (f.fecha_firma as string) ?? "",
    estatus: (f.estatus as Estatus) ?? "apartado",
    codigo: (f.codigo as Codigo) ?? "SVT",
    overrideDiasLimite: (f.override_dias_limite as number) ?? null,
    overrideDiasAviso: (f.override_dias_aviso as number) ?? null,
    overrideResponsable: (f.override_responsable as string) ?? null,
    overrideAcciones: (f.override_acciones as AccionCodigo[]) ?? null,
    area: (f.area as Area) ?? "Comercial",
    nomenclaturaValidada: Boolean(f.nomenclatura_validada),
    fechaVencimiento: (f.fecha_vencimiento as string) ?? "",
    archivado: Boolean(f.archivado),
    terminado: Boolean(f.terminado),
    terminadoTipo: (f.terminado_tipo as string) ?? null,
    ultimaActuacionAt: (f.ultima_actuacion_at as string) ?? "",
    eliminado: Boolean(f.eliminado),
    folio: (f.folio as string) ?? "",
    folioCierre: (f.folio_cierre as string) ?? "",
    tipo: (f.tipo as TipoRegistro) ?? "cliente",
    direccionGarantia: (f.direccion_garantia as string) ?? "",
    fechaConversion: (f.fecha_conversion as string) ?? "",
    convertidoPor: (f.convertido_por as string) ?? "",
    datosValidadosSucursal: Boolean(f.datos_validados_sucursal),
    validadoSucursalPor: (f.validado_sucursal_por as string) ?? null,
    fechaValidadoSucursal: (f.fecha_validado_sucursal as string) ?? null,
    requiereCitaSucursal: Boolean(f.requiere_cita_sucursal),
    citaSucursalMotivo: (f.cita_sucursal_motivo as string) ?? null,
    citaSucursalDocumentos: (f.cita_sucursal_documentos as string) ?? null,
    validacionPresencialEn: (f.validacion_presencial_en as string) ?? null,
    validacionPresencialPor: (f.validacion_presencial_por as string) ?? null,
    bloqueado: Boolean(f.bloqueado),
    bloqueadoPor: (f.bloqueado_por as string) ?? null,
    bloqueadoEn: (f.bloqueado_en as string) ?? null,
    motivoBloqueo: (f.motivo_bloqueo as string) ?? null,
    ineDoc: (f.ine_doc as { url: string; nombre: string }) ?? null,
    comprobanteDomicilioDoc: (f.comprobante_domicilio_doc as { url: string; nombre: string }) ?? null,
    curpDoc: (f.curp_doc as { url: string; nombre: string }) ?? null,
    datosLlenadosSucursalEn: (f.datos_llenados_sucursal_en as string) ?? null,
    datosLlenadosSucursalPor: (f.datos_llenados_sucursal_por as string) ?? null,
    asesorAsignado: (f.asesor_asignado as string) ?? "",
    asesorCorreo: (f.asesor_correo as string) ?? "",
    asesorAsignadoPor: (f.asesor_asignado_por as string) ?? "",
    fechaAsignacion: (f.fecha_asignacion as string) ?? "",
    historialAsesores: Array.isArray(f.historial_asesores) ? (f.historial_asesores as AsesorHistorial[]) : [],
    sucursal: (f.sucursal as string) ?? "",
    carpetaDriveId: (f.carpeta_drive_id as string) ?? "",
    carpetaDriveEtapa: (f.carpeta_drive_etapa as string) ?? "",
    r3Tipo: (f.r3_tipo as string) ?? "",
    r3Seguimiento: (f.r3_seguimiento as boolean) ?? true,
    r3DireccionNueva: (f.r3_direccion_nueva as string) ?? "",
    r3ValorNuevo: (f.r3_valor_nuevo as string) ?? "",
    r3Terminos: (f.r3_terminos as string) ?? "",
    r3DocCambio: (f.r3_doc_cambio as { url: string; nombre: string }) ?? null,
  };
}
// ============================================================================
//  CACHÉ COMPARTIDA DE CLIENTES
//
//  Motivo (04-sep-2026): ocho módulos llamaban fetchClientes() por su cuenta
//  (Clientes, Seguimiento, ControlDevoluciones, KpisDevoluciones, Papelera,
//  FoliosRegistro, LlamarGrabar, Videollamadas). Cada llamada se traía las 407
//  filas con sus 98 columnas —459 kB— y sumaban unas 21,000 cargas completas.
//
//  Ahora hay una sola copia viva:
//   · Si dos módulos piden al mismo tiempo, comparten UNA sola petición.
//   · La copia se reutiliza durante 20 s.
//   · CUALQUIER escritura sobre la tabla la tira de inmediato (escribirClientes),
//     así que nadie ve datos viejos después de guardar.
//
//  Si agregas una escritura nueva a la tabla, úsala con escribirClientes()
//  en vez de supabase.from("clientes"), o llama invalidarClientes() a mano.
// ============================================================================
const VIGENCIA_CACHE_MS = 20000;
let cacheClientes: Cliente[] | null = null;
let cacheHasta = 0;
let peticionEnVuelo: Promise<Cliente[]> | null = null;

/** Tira la copia guardada. Se llama sola en cada escritura. */
export function invalidarClientes(): void {
  cacheClientes = null;
  cacheHasta = 0;
  peticionEnVuelo = null;
}

/** Usar para TODA escritura sobre la tabla clientes: invalida y devuelve la tabla. */
function escribirClientes() {
  invalidarClientes();
  return supabase.from("clientes");
}

// Trae los clientes de Supabase (con caché compartida).
export async function fetchClientes(opts?: { forzar?: boolean }): Promise<Cliente[]> {
  if (opts?.forzar) invalidarClientes();

  // Copia todavía fresca.
  if (cacheClientes && Date.now() < cacheHasta) return cacheClientes;

  // Ya hay una petición en camino: súmate a ella en vez de abrir otra.
  if (peticionEnVuelo) return peticionEnVuelo;

  peticionEnVuelo = (async () => {
    const { data, error } = await supabase
      .from("clientes")
      .select("*")
      .order("id", { ascending: true });

    if (error) { peticionEnVuelo = null; throw error; }

    const lista = (data ?? []).map(mapearCliente);
    cacheClientes = lista;
    cacheHasta = Date.now() + VIGENCIA_CACHE_MS;
    peticionEnVuelo = null;
    return lista;
  })();

  return peticionEnVuelo;
}

// 👇 NUEVO (Fase 2.1): deduce el origen del cliente.
//  - Si trae garantía / folio SIGA / folio de garantía SIGA / crédito SIGA  → es de SIGA (cliente real).
//  - Si no trae nada de eso  → se creó en JurisConecta (le falta información para sincronizar).
export function origenCliente(c: Cliente): { enSiga: boolean; faltaInfo: boolean } {
  const enSiga = !!(
    (c.folioSiga || "").trim() ||
    (c.folioGarantiaSiga || "").trim() ||
    (c.creditoSiga || "").trim() ||
    (c.garantia || "").trim()
  );
  return { enSiga, faltaInfo: !enSiga };
}

// =====================================================================
//  FOLIOS  —  AREA-AÑO-Qxx-### (consecutivo corrido por área y año).
//  Ej: JUR-2026-Q14-007  ·  cierre: JUR-2026-Q18-007-C
// =====================================================================

// Prefijo de 3 letras por área.
export function prefijoArea(area: Area): string {
  switch (area) {
    case "Comercial": return "COM";
    case "RAC": return "RAC";
    case "Admin": return "ADM";
    case "Jurídico": return "JUR";
    case "UFC": return "UFC";
    default: return "COM";
  }
}

// Quincena 1–24 de una fecha (días 1–15 = primera; 16–fin = segunda).
export function quincenaDe(d: Date): number {
  return d.getMonth() * 2 + (d.getDate() <= 15 ? 1 : 2);
}

// Siguiente consecutivo del año para esa área (cuenta los folios ya existentes).
async function siguienteConsecutivo(prefijo: string, anio: number): Promise<number> {
  const { count } = await supabase
    .from("clientes")
    .select("id", { count: "exact", head: true })
    .like("folio", `${prefijo}-${anio}-%`);
  return (count ?? 0) + 1;
}

// Construye el folio de cierre a partir del folio de registro + la fecha de hoy.
function construirFolioCierre(c: Cliente): string {
  const ahora = new Date();
  const anio = ahora.getFullYear();
  const q = "Q" + String(quincenaDe(ahora)).padStart(2, "0");
  let prefijo = prefijoArea(c.area);
  let consec = "000";
  const partes = (c.folio || "").split("-"); // [AREA, AÑO, Qxx, nnn]
  if (partes.length >= 4) { prefijo = partes[0]; consec = partes[3]; }
  return `${prefijo}-${anio}-${q}-${consec}-C`;
}

// Archiva o desarchiva un cliente (Opción A: queda guardado en la base, para todos).
// Al archivar genera el folio de cierre; al desarchivar lo quita.
export async function archivarCliente(c: Cliente, valor: boolean): Promise<{ ok: boolean; folioCierre: string }> {
  const folioCierre = valor ? (c.folioCierre || construirFolioCierre(c)) : "";
  const { error } = await escribirClientes()
    .update({ archivado: valor, folio_cierre: folioCierre })
    .eq("id", c.id);
  return { ok: !error, folioCierre: error ? (c.folioCierre || "") : folioCierre };
}

// Manda a la papelera (valor=true) o restaura (valor=false). NO borra de la base.
export async function eliminarCliente(id: string, valor: boolean): Promise<boolean> {
  const { error } = await escribirClientes().update({ eliminado: valor }).eq("id", id);
  return !error;
}

// Borrado DEFINITIVO: sí elimina la fila de la base. No se puede deshacer.
export async function borrarClienteDefinitivo(id: string): Promise<boolean> {
  const { error } = await escribirClientes().delete().eq("id", id);
  return !error;
}

// 👇 NUEVO: convierte un PROSPECTO en CLIENTE (botón manual mientras no hay SIGA).
//  Marca tipo='cliente', guarda la fecha y quién lo convirtió → esto alimenta los KPIs de atención.
export async function convertirACliente(c: Cliente): Promise<{ ok: boolean; cliente?: Cliente }> {
  const ahora = new Date().toISOString();
  const por = quienSoy();
  const { data, error } = await escribirClientes()
    .update({ tipo: "cliente", fecha_conversion: ahora, convertido_por: por })
    .eq("id", c.id)
    .select()
    .single();
  if (error || !data) return { ok: false };
  const actualizado = mapearCliente(data as Record<string, unknown>);
  avisarEvento({
    tipo: "cliente",
    accion: "convertido",
    titulo: `Prospecto convertido a cliente: ${actualizado.nombre}`,
    detalle: por === "Alguien" ? "Un prospecto pasó a cliente" : `Lo convirtió ${por}`,
    autor: por,
    modulo: "clientes",
    refId: String(actualizado.id),
  });
  return { ok: true, cliente: actualizado };
}

// 👇 NUEVO (Fase B): asigna (o reasigna) el asesor a cargo de un registro.
//  Guarda el asesor, quién lo asignó y la fecha → base para las reglas de meta/venta.
export async function asignarAsesor(c: Cliente, nombre: string, correo: string): Promise<{ ok: boolean; cliente?: Cliente }> {
  const por = quienSoy();
  const ahora = new Date().toISOString();
  // 👇 NUEVO (Fase E.1): si ya tenía un asesor, lo mandamos al historial ANTES de cambiarlo.
  const historial: AsesorHistorial[] = Array.isArray(c.historialAsesores) ? [...c.historialAsesores] : [];
  if ((c.asesorAsignado || "").trim()) {
    historial.push({
      nombre: c.asesorAsignado,
      correo: c.asesorCorreo || "",
      asignadoPor: c.asesorAsignadoPor || "",
      desde: c.fechaAsignacion || "",
      hasta: ahora,
    });
  }
  const { data, error } = await escribirClientes()
    .update({ asesor_asignado: nombre, asesor_correo: correo, asesor_asignado_por: por, fecha_asignacion: ahora, historial_asesores: historial })
    .eq("id", c.id)
    .select()
    .single();
  if (error || !data) return { ok: false };
  const actualizado = mapearCliente(data as Record<string, unknown>);
  avisarEvento({
    tipo: "cliente",
    accion: "asesor_asignado",
    titulo: `Asesor a cargo: ${nombre}`,
    detalle: `${actualizado.nombre} — asignado por ${por}`,
    autor: por,
    modulo: "clientes",
    refId: String(actualizado.id),
  });
  return { ok: true, cliente: actualizado };
}

// 👇 NUEVO (Fase D.1): guarda el id de la carpeta de Drive y la etapa en que quedó.
//  Esto es el CANDADO: una vez guardado el id, la próxima vez NO se crea otra carpeta,
//  solo se abre la que ya existe. La etapa la usará el D.2 para saber si hay que mover.
export async function guardarCarpetaDrive(
  c: Cliente,
  carpetaId: string,
  etapa: string
): Promise<{ ok: boolean; cliente?: Cliente }> {
  const { data, error } = await escribirClientes()
    .update({ carpeta_drive_id: carpetaId, carpeta_drive_etapa: etapa })
    .eq("id", c.id)
    .select()
    .single();
  if (error || !data) return { ok: false };
  return { ok: true, cliente: mapearCliente(data as Record<string, unknown>) };
}

// 👇 NUEVO: lee EN VIVO de la base si el cliente ya tiene carpeta de Drive.
//  Sirve para el candado: aunque a la pantalla le haya llegado un cliente "viejo"
//  (sin el id), aquí se consulta el dato real y no se duplica la carpeta.
export async function leerCarpetaDrive(
  clienteId: string
): Promise<{ carpetaId: string; etapa: string }> {
  const { data, error } = await supabase
    .from("clientes")
    .select("carpeta_drive_id, carpeta_drive_etapa")
    .eq("id", clienteId)
    .single();
  if (error || !data) return { carpetaId: "", etapa: "" };
  return {
    carpetaId: (data.carpeta_drive_id as string) ?? "",
    etapa: (data.carpeta_drive_etapa as string) ?? "",
  };
}
export interface NuevoCliente {
  nombre: string;
  curpRfc?: string;
  ine?: string;
  estadoCivil?: string;
  conyuge?: string;
  conyugeNotificado?: boolean;
  domicilio?: string;
  telefono: string;
  telefono2?: string;
  email?: string;
  whatsapp?: string;
  comoConocio?: string;
  refirio?: string;
  autorizadoNombre?: string;
  autorizadoTelefono?: string;
  autorizadoCorreo?: string;
  prospecto?: string;
  garantia?: string;
  expediente: string;
  folioSiga?: string;
  folioGarantiaSiga?: string;
  creditoSiga?: string;
  fechaFirma?: string;
  estatus?: Estatus;
  codigo?: Codigo;
  area?: Area;
  tipo?: TipoRegistro;
  direccionGarantia?: string;
  sucursal?: string; // 👈 NUEVO (Fase D.1)
}

// Campos que se pueden corregir desde "Rellenar y validar datos" (CRM).
export type CamposClienteEditables = {
  nombre: string; curpRfc: string; ine: string; estadoCivil: string; conyuge: string; domicilio: string;
  telefono: string; telefono2: string; whatsapp: string; email: string;
  autorizadoNombre: string; autorizadoTelefono: string; autorizadoCorreo: string;
  direccionGarantia: string; creditoSiga: string; folioSiga: string; folioGarantiaSiga: string; sucursal: string;
  fechaFirma: string; // 👈 NUEVO (Mejora A): fecha de firma del contrato
  valorFirma: string; montoApartado: string; segundosPagos: string; pagoCesion: string; pagoEscritura: string; pagoGestoria: string; otrosPagos: string;
};

// Actualiza SOLO los campos editables del cliente (no toca folios, estatus, etc.).
export async function actualizarCliente(clienteId: string, cambios: Partial<CamposClienteEditables>): Promise<boolean> {
  const map: Record<keyof CamposClienteEditables, string> = {
    nombre: "nombre", curpRfc: "curp_rfc", ine: "ine", estadoCivil: "estado_civil", conyuge: "conyuge", domicilio: "domicilio",
    telefono: "telefono", telefono2: "telefono2", whatsapp: "whatsapp", email: "email",
    autorizadoNombre: "autorizado_nombre", autorizadoTelefono: "autorizado_telefono", autorizadoCorreo: "autorizado_correo",
    direccionGarantia: "direccion_garantia", creditoSiga: "credito_siga", folioSiga: "folio_siga", folioGarantiaSiga: "folio_garantia_siga", sucursal: "sucursal",
    fechaFirma: "fecha_firma",
    valorFirma: "valor_firma", montoApartado: "monto_apartado", segundosPagos: "segundos_pagos",
    pagoCesion: "pago_cesion", pagoEscritura: "pago_escritura", pagoGestoria: "pago_gestoria", otrosPagos: "otros_pagos",
  };
  const fila: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(cambios)) {
    const col = map[k as keyof CamposClienteEditables];
    if (col) fila[col] = v ?? "";
  }
  if (Object.keys(fila).length === 0) return true;
  const { error } = await escribirClientes().update(fila).eq("id", clienteId);
  return !error;
}

// 👇 NUEVO (Mejora A): cambia el código del cliente (p. ej. RV → R1 por contrato vencido).
// Opcionalmente reasigna el área (R1 lo atiende el RAC).
export async function cambiarCodigoCliente(clienteId: string, codigo: Codigo, area?: Area): Promise<boolean> {
  const fila: Record<string, unknown> = { codigo };
  if (area) fila.area = area;
  // Verifica que SÍ se aplicó (si RLS bloquea, cambia 0 filas sin dar error).
  const { data, error } = await escribirClientes().update(fila).eq("id", clienteId).select("id");
  if (error) { console.error("cambiarCodigoCliente no guardó:", error.message); return false; }
  return Array.isArray(data) && data.length > 0;
}

// 👇 NUEVO: valida la nomenclatura (código) de un cliente: confirma o corrige el código que
//  vino del Excel y lo deja marcado como VALIDADO (le quita el triángulo amarillo).
export async function validarNomenclatura(clienteId: string, codigo: Codigo, area?: Area): Promise<boolean> {
  const fila: Record<string, unknown> = { codigo, nomenclatura_validada: true };
  if (area) fila.area = area;
  // OJO: si RLS (permisos) bloquea el UPDATE, Supabase NO devuelve error pero cambia 0 filas.
  // Con .select("id") confirmamos que la fila SÍ se actualizó (regresa) — si no regresa, no se guardó.
  const { data, error } = await escribirClientes().update(fila).eq("id", clienteId).select("id");
  if (error) { console.error("validarNomenclatura no guardó:", error.message); return false; }
  return Array.isArray(data) && data.length > 0;
}

// 👇 FASE F: guarda (o limpia) la regla especial de UN cliente.
export async function guardarReglaEspecial(
  clienteId: string,
  r: { diasLimite: number | null; diasAviso: number | null; responsable: string | null; acciones: AccionCodigo[] | null },
): Promise<boolean> {
  const { error } = await escribirClientes().update({
    override_dias_limite: r.diasLimite,
    override_dias_aviso: r.diasAviso,
    override_responsable: r.responsable,
    override_acciones: r.acciones,
  }).eq("id", clienteId);
  return !error;
}

// 👇 NUEVO: actualiza un RV con contrato VENCIDO a R1 (lo pasa a RAC).
//  Solo lo usa ADM. El contrato venció (firma + 15 meses hábiles), ya no puede seguir como RV.
export async function actualizarVencidoR1(clienteId: string): Promise<boolean> {
  const { error } = await escribirClientes()
    .update({ codigo: "R1", area: "RAC" })
    .eq("id", clienteId);
  return !error;
}

// 👇 NUEVO: marca al cliente como ENTREGADO / completado (R3, estatus entregado, lo atiende RAC).
//  Se usa con el botón "Marcar entregado" para ir cerrando los casos terminados.
export async function marcarEntregado(clienteId: string): Promise<boolean> {
  const { error } = await escribirClientes()
    .update({ codigo: "R3", estatus: "entregado", area: "RAC" })
    .eq("id", clienteId);
  return !error;
}

// 👇 NUEVO (Mejora B): guarda el indicador del R3 (cómo cerró + si sigue con seguimiento).
export async function guardarIndicadorR3(clienteId: string, r3Tipo: string, r3Seguimiento: boolean): Promise<boolean> {
  const { error } = await escribirClientes()
    .update({ r3_tipo: r3Tipo, r3_seguimiento: r3Seguimiento })
    .eq("id", clienteId);
  return !error;
}

// Guarda un cliente nuevo en Supabase y lo regresa ya mapeado.
export async function registrarCliente(c: NuevoCliente): Promise<Cliente> {
  // 👇 Folio automático de registro: AREA-AÑO-Qxx-### (corrido por área/año).
  const ahora = new Date();
  const anio = ahora.getFullYear();
  const prefijo = prefijoArea(c.area || "Comercial");
  const consec = await siguienteConsecutivo(prefijo, anio);
  const q = "Q" + String(quincenaDe(ahora)).padStart(2, "0");
  const folio = `${prefijo}-${anio}-${q}-${String(consec).padStart(3, "0")}`;

  const fila = {
    nombre: c.nombre,
    curp_rfc: c.curpRfc || "",
    ine: c.ine || "",
    estado_civil: c.estadoCivil || "",
    conyuge: c.conyuge || null,
    conyuge_notificado: c.conyugeNotificado ?? false,
    domicilio: c.domicilio || "",
    telefono: c.telefono,
    telefono2: c.telefono2 || "",
    email: c.email || "",
    whatsapp: c.whatsapp || "",
    como_conocio: c.comoConocio || "",
    refirio: c.refirio || "",
    autorizado_nombre: c.autorizadoNombre || "",
    autorizado_telefono: c.autorizadoTelefono || "",
    autorizado_correo: c.autorizadoCorreo || "",
    prospecto: c.prospecto || "",
    garantia: c.garantia || "",
    expediente: c.expediente,
    folio_siga: c.folioSiga || "",
    folio_garantia_siga: c.folioGarantiaSiga || "",
    credito_siga: c.creditoSiga || "",
    fecha_firma: c.fechaFirma || null,
    estatus: c.estatus || "apartado",
    codigo: c.codigo || "SVT",
    area: c.area || "Comercial",
    tipo: c.tipo || "prospecto",
    direccion_garantia: c.direccionGarantia || "",
    sucursal: c.sucursal || "",            // 👈 NUEVO (Fase D.1)
    carpeta_drive_id: "",                  // 👈 NUEVO: arranca sin carpeta
    carpeta_drive_etapa: "",               // 👈 NUEVO
    historial_asesores: [],                // 👈 NUEVO (Fase E.1)
    folio,
    folio_cierre: "",
  };

  const { data, error } = await escribirClientes().insert(fila).select().single();
  if (error) throw error;
  const creado = mapearCliente(data as Record<string, unknown>); // 👈 NUEVO

  // 👇 NUEVO: avisa a TODOS que se dio de alta un cliente (no espera, no rompe nada).
  const yo = quienSoy();
  avisarEvento({
    tipo: "cliente",
    accion: "creado",
    titulo: `Nuevo cliente: ${creado.nombre}`,
    detalle: yo === "Alguien" ? "Se registró un cliente nuevo" : `Lo registró ${yo}`,
    autor: yo,
    modulo: "clientes",
    refId: String(creado.id),
  });

  return creado; // 👈 NUEVO
}

// Guarda el indicador de "solicitud de devolución" (RDC). El documento es opcional; la fecha sí va.
export async function guardarSolicitudDevolucion(
  clienteId: string | number,
  p: { tiene: boolean; fecha: string; doc?: { url: string; nombre: string } | null }
): Promise<boolean> {
  const fila: Record<string, unknown> = {
    tiene_solicitud_devolucion: p.tiene,
    fecha_solicitud_devolucion: p.tiene ? (p.fecha || null) : null,
    doc_solicitud_devolucion: p.tiene ? (p.doc ?? null) : null,
  };
  const { error } = await escribirClientes().update(fila).eq("id", String(clienteId));
  return !error;
}

// Pasa un cliente a R3 (cambio concluido) guardando los datos del nuevo contrato.
// Como pasa de negativo a positivo, sale de devoluciones/posibles devoluciones (se refleja en KPIs).
export async function guardarCambioR3(
  clienteId: string | number,
  p: { direccionNueva: string; valorNuevo: string; terminos: string; doc?: { url: string; nombre: string } | null }
): Promise<boolean> {
  const { error } = await escribirClientes().update({
    codigo: "R3",
    nomenclatura_validada: true,
    area: "RAC",
    r3_direccion_nueva: p.direccionNueva || null,
    r3_valor_nuevo: p.valorNuevo || null,
    r3_terminos: p.terminos || null,
    r3_doc_cambio: p.doc ?? null,
  }).eq("id", String(clienteId));
  return !error;
}

/**
 * Paso 1 de 2: alguien de sucursal (colaborador, asesor, gerente de
 * sucursal, gerente, director comercial o RAC) llena/coteja los datos
 * del cliente contra su INE, comprobante de domicilio y CURP. Esto NO
 * valida todavía — solo deja los datos listos para que RAC/sub-RAC los
 * confirmen en el paso 2 (marcarDatosValidadosSucursal).
 */
export interface LineaPagoRdc {
  tipo: "contrato" | "apartado" | "segundo_pago" | "cesion" | "escritura" | "otro";
  monto: number;
  soporte: "notarial_original" | "documento_original" | "efectivo_apoderado" | "correo" | "sin_soporte";
  nota?: string; // obligatoria si soporte === "sin_soporte"
  doc?: { url: string; nombre: string } | null;
}

export async function guardarDatosSucursalRdc(
  clienteId: string | number,
  datos: {
    capital?: string; direccionGarantia?: string; fechaFirma?: string; fechaVencimiento?: string;
    telefono?: string; celular?: string; domicilio?: string;
    lineasPago?: LineaPagoRdc[];
  },
  llenadoPor: string
): Promise<boolean> {
  const fila: Record<string, unknown> = {
    datos_llenados_sucursal_en: new Date().toISOString(),
    datos_llenados_sucursal_por: llenadoPor,
  };
  if (datos.capital !== undefined) fila.valor_firma = datos.capital;
  if (datos.direccionGarantia !== undefined) fila.direccion_garantia = datos.direccionGarantia;
  if (datos.fechaFirma !== undefined) fila.fecha_firma = datos.fechaFirma;
  if (datos.fechaVencimiento !== undefined) fila.fecha_vencimiento = datos.fechaVencimiento;
  if (datos.telefono !== undefined) fila.telefono = datos.telefono;
  if (datos.celular !== undefined) fila.telefono2 = datos.celular;
  if (datos.domicilio !== undefined) fila.domicilio = datos.domicilio;

  const { error } = await escribirClientes().update(fila).eq("id", String(clienteId));
  if (error) return false;

  if (datos.lineasPago) {
    const { error: errPagos } = await supabase
      .from("compensacion_devolucion")
      .update({ pagos_lineas: datos.lineasPago })
      .eq("cliente_id", String(clienteId));
    if (errPagos) return false;
  }
  return true;
}

/**
 * Sub-RAC confirma que ya cotejó los datos del cliente (capital, garantía,
 * fechas) contra el contrato físico en sucursal. Hasta que esto sea true,
 * la Solicitud Formal de Devolución no debe tomar estos datos como
 * confiables — se muestran "sin validar" en el formulario.
 */
export async function marcarDatosValidadosSucursal(clienteId: string | number, validadoPor: string): Promise<boolean> {
  const { error } = await escribirClientes().update({
    datos_validados_sucursal: true,
    validado_sucursal_por: validadoPor,
    fecha_validado_sucursal: new Date().toISOString(),
  }).eq("id", String(clienteId));
  return !error;
}

/**
 * La DGE bloquea o desbloquea una ficha ya revisada contra los documentos
 * originales (contrato, Drive, CRM). Con bloqueado = true la ficha queda
 * de SOLO LECTURA: se pueden AGREGAR abonos, actuaciones y notas, pero no
 * editar ni borrar lo confirmado.
 *
 * OJO: esto es distinto de marcarDatosValidadosSucursal, que confirma que
 * los datos coinciden con el contrato físico para efectos de la Solicitud
 * Formal de Devolución. Aquí se trata del candado de edición del registro.
 *
 * Solo el perfil de Dirección debe poder desbloquear.
 */
export async function cambiarBloqueoCliente(
  clienteId: string | number,
  bloquear: boolean,
  quien: string,
  motivo?: string
): Promise<boolean> {
  const { error } = await escribirClientes().update({
    bloqueado: bloquear,
    bloqueado_por: bloquear ? quien : null,
    bloqueado_en: bloquear ? new Date().toISOString() : null,
    motivo_bloqueo: bloquear ? (motivo ?? null) : null,
  }).eq("id", String(clienteId));
  return !error;
}
