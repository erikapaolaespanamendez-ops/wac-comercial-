// BITÁCORA DE LLAMADAS EN EXCEL → va en: src/data/exportarBitacora.ts
// Toma las llamadas que ya están cargadas en pantalla (las que veas filtradas)
// y arma un archivo Excel (.xlsx) que se descarga al instante. No guarda nada
// en el servidor: el Excel se genera en el momento que lo pides.
// xlsx se carga BAJO DEMANDA dentro de la función (import dinámico), para no pesar el arranque.
import { AREAS, type Llamada } from "./llamadas";

// Convierte la clave del área (ej. "juridico") al nombre bonito (ej. "Jurídico").
function nombreArea(clave: string): string {
  return AREAS.find((a) => a.clave === clave)?.nombre || clave || "—";
}

// Convierte la fecha ISO a algo legible: 18/06/2026 04:08
function fechaBonita(iso: string): string {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleString("es-MX", {
      day: "2-digit", month: "2-digit", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

// Función principal: recibe la lista de llamadas y descarga el Excel.
export async function exportarBitacoraExcel(llamadas: Llamada[]): Promise<void> {
  const XLSX = await import("xlsx"); // se baja solo al exportar
  // Armamos una fila por cada llamada, con encabezados en español.
  const filas = llamadas.map((l) => ({
    "Folio": l.folio || "",
    "Fecha y hora": fechaBonita(l.fecha),
    "Tipo": l.tipo === "saliente" ? "Saliente" : "Entrante",
    "Área": nombreArea(l.area),
    "Colaborador": l.registradoPor || "",
    "Cliente": l.clienteNombre || "",
    "Teléfono": l.telefono || "",
    "Garantía": l.garantia || "",
    "Expediente": l.expediente || "",
    "Motivo": l.motivo || "",
    "Nota": l.nota || "",
    "Resultado": l.resultado || "",
    "Duración (seg)": l.duracion ?? "",
    "Urgente": l.urgente ? "Sí" : "No",
    "Por devolver": l.devolver ? "Sí" : "No",
    "Devuelta": l.devuelta ? "Sí" : "No",
    "Fecha compromiso": l.fechaCompromiso || "",
    "Grabación": l.grabacionUrl || "",
  }));

  // Creamos la hoja de cálculo a partir de las filas.
  const hoja = XLSX.utils.json_to_sheet(filas);

  // Anchos de columna para que se lea cómodo.
  hoja["!cols"] = [
    { wch: 10 }, // Folio
    { wch: 18 }, // Fecha y hora
    { wch: 10 }, // Tipo
    { wch: 14 }, // Área
    { wch: 28 }, // Colaborador
    { wch: 22 }, // Cliente
    { wch: 16 }, // Teléfono
    { wch: 14 }, // Garantía
    { wch: 14 }, // Expediente
    { wch: 22 }, // Motivo
    { wch: 32 }, // Nota
    { wch: 16 }, // Resultado
    { wch: 12 }, // Duración
    { wch: 9 },  // Urgente
    { wch: 12 }, // Por devolver
    { wch: 10 }, // Devuelta
    { wch: 16 }, // Fecha compromiso
    { wch: 40 }, // Grabación
  ];

  // Creamos el libro y le pegamos la hoja.
  const libro = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(libro, hoja, "Bitácora");

  // Nombre del archivo con la fecha de hoy: Bitacora_llamadas_2026-06-18.xlsx
  const hoy = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(libro, `Bitacora_llamadas_${hoy}.xlsx`);
}
