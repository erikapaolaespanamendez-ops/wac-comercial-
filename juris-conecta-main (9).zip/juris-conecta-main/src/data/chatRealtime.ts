import { supabase } from "../lib/supabase";
import type { Mensaje } from "./chat";

// =====================================================================
//  "EN VIVO" DEL CHAT  —  UN SOLO canal broadcast global para todo.
//  Broadcast es el mismo "en vivo" que usa el video (y que SÍ funciona).
//  DETALLE: el canal tarda un instante en "conectar" (SUBSCRIBED). Si
//  mandamos un mensaje ANTES de que conecte, se pierde. Por eso guardamos
//  en una cola lo que salga mientras conecta, y lo soltamos al quedar listo.
// =====================================================================
const canalGlobal = supabase.channel("chat_global_v1", { config: { broadcast: { self: false } } });
let estado: "no" | "conectando" | "listo" = "no";
const oyentes = new Set<(m: Mensaje) => void>();
const pendientes: Mensaje[] = [];

function enviarPorCanal(m: Mensaje) {
  canalGlobal.send({ type: "broadcast", event: "nuevo_mensaje", payload: m });
}

function asegurarSuscrito() {
  if (estado !== "no") return;
  estado = "conectando";
  canalGlobal
    .on("broadcast", { event: "nuevo_mensaje" }, ({ payload }) => {
      const m = payload as Mensaje;
      oyentes.forEach((fn) => { try { fn(m); } catch {} });
    })
    .subscribe((status) => {
      if (status === "SUBSCRIBED") {
        estado = "listo";
        while (pendientes.length) enviarPorCanal(pendientes.shift() as Mensaje);
      }
    });
}

export function avisarMensajeEnVivo(m: Mensaje) {
  asegurarSuscrito();
  if (estado === "listo") enviarPorCanal(m);
  else pendientes.push(m);
}

export function escucharMensajes(fn: (m: Mensaje) => void): () => void {
  asegurarSuscrito();
  oyentes.add(fn);
  return () => { oyentes.delete(fn); };
}
