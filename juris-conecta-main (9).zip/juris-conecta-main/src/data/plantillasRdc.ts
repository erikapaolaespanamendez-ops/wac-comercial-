// Generador de VISTA PREVIA de los 4 documentos de RDC — usa datos de
// EJEMPLO (no un cliente real), y siempre marca "BORRADOR / SIN FOLIO" con
// marca de agua. Sirve para que RAC/asesores le muestren al cliente lo que
// va a firmar, SIN gastar descargas reales ni activar el candado de 24h.
//
// Mismo formato azul profesional, cláusulas reforzadas y línea de tiempo
// con montos que ya usan los documentos reales (SolicitudFormalRDC.tsx,
// ConvenioRDC.tsx) — para que lo que el cliente ve de ejemplo sea idéntico
// a lo que después firma de verdad.
import {
  PLAZO_MESES_PARA_COMPENSACION, PLAZO_DEFINICION_DIAS, PLAZO_FIRMA_HORAS,
  M1_MESES_INICIO_CAPITAL, M1_NUM_PAGOS_CAPITAL, M1_MESES_INICIO_COMPENSACION, M1_NUM_PAGOS_COMPENSACION,
  MESES_ENTRE_PAGOS_MIN, MESES_ENTRE_PAGOS_MAX, M2_MESES_INICIO, M2_NUM_PAGOS_MAX,
} from "./rdc";

function money(n: number): string {
  return "$" + Math.round(n || 0).toLocaleString("es-MX");
}

const MARCA_AGUA = `
<div style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:999;display:flex;align-items:center;justify-content:center;overflow:hidden">
  <div style="transform:rotate(-35deg);font-size:64px;font-weight:900;color:rgba(220,38,38,0.14);white-space:nowrap;letter-spacing:6px;line-height:1.4;text-align:center">
    BORRADOR · SIN FOLIO<br>SOLO MUESTRA PARA EL CLIENTE<br>EXCLUSIVO DIIPA S.A. DE C.V.
  </div>
</div>`;

const ESTILO_BASE = `body{margin:0;padding:0;font-family:"Times New Roman",serif;font-size:12pt;line-height:1.65;color:#000;background:#fff;position:relative}
.contenido{padding:40px 50px}
table{border-collapse:collapse;width:100%}td{vertical-align:top}
@media print{.contenido{padding:20mm 25mm}@page{margin:0;size:letter}}`;

function envolver(titulo: string, encabezado: { linea1: string; linea2: string; linea3: string }, cuerpo: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${titulo} — Vista previa</title><style>${ESTILO_BASE}</style></head><body>${MARCA_AGUA}
<div class="contenido">
<p style="margin:0 0 4px;font-size:16pt;font-weight:700;text-align:center">${encabezado.linea2}</p>
<p style="margin:0 0 24px;font-size:10.5pt;text-align:center;font-style:italic">${encabezado.linea3}</p>
${cuerpo}</div>
</body></html>`;
}

function filaLinea(num: string, detalle: string, monto: string): string {
  return `
<tr>
<td style="padding:8px 12px 8px 0;border-bottom:1px solid #000;width:35%"><strong>${num}</strong></td>
<td style="padding:8px 12px 8px 0;border-bottom:1px solid #000">${detalle}</td>
<td style="padding:8px 0;border-bottom:1px solid #000;text-align:right;white-space:nowrap"><strong>${monto}</strong></td>
</tr>`;
}

export function previewSolicitudFormal(): string {
  const hoyTexto = new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" });
  return envolver("Solicitud Formal de Devolución", { linea1: "DIIPA · DEVOLUCIÓN COMPENSADA", linea2: "Solicitud formal de devolución", linea3: "Paso 1 · elección del cliente" }, `
<p style="text-align:right;margin-bottom:24px">Mazatlán, Sinaloa a ${hoyTexto}</p>
<p style="margin-bottom:2px"><strong>DESARROLLOS INTELIGENTES DE INMUEBLES Y PROPIEDADES ACCESIBLES, S.A. DE C.V.</strong></p>
<p style="margin-bottom:20px"><strong>Presente.</strong></p>
<p style="text-align:justify;margin-bottom:12px">Por medio de la presente, yo, <strong style="border-bottom:1px solid #000;padding:0 4px">NOMBRE DEL CLIENTE</strong>, en mi carácter de <strong>CLIENTE</strong>, solicito formalmente la devolución de mi capital, en pleno uso de mi derecho y por voluntad propia.</p>
<p style="text-align:justify;margin-bottom:12px">Esta solicitud debe presentarse de manera <strong>personal en sucursal</strong>, mostrando mi identificación oficial vigente (INE) en mano. <strong>No se acepta por correo electrónico ni por ningún otro medio remoto.</strong></p>
<p style="text-align:justify;margin-bottom:12px">La relación jurídica es de carácter estrictamente civil, derivada de un contrato de prestación de servicios de gestión y recuperación de derechos, en términos de los artículos 2029 y 2032 del Código Civil Federal (cesión de derechos), por lo que queda fuera de la competencia de CONDUSEF y de PROFECO (arts. 2 y 2 Bis de la Ley para la Transparencia y Ordenamiento de los Servicios Financieros).</p>

<div style="border:1px dashed #9ca3af;border-radius:6px;padding:12px 16px;margin:16px 0">
<p style="font-weight:800;text-transform:uppercase;font-size:10pt;color:#000;margin:0 0 8px">Solicitud hecha a mano por el cliente <span style="font-weight:400;text-transform:none;font-size:9.5pt">(opcional)</span></p>
<div style="border-bottom:1px solid #9ca3af;height:20px;margin-bottom:6px"></div>
<div style="border-bottom:1px solid #9ca3af;height:20px;margin-bottom:6px"></div>
<div style="border-bottom:1px solid #9ca3af;height:20px"></div>
</div>

<div style="border:1px solid #000;border-radius:0;padding:12px 16px;margin:16px 0">
<p style="font-weight:800;text-transform:uppercase;font-size:10pt;color:#000;margin:0 0 8px">Validación de datos contra documentos originales</p>
<table style="font-size:10.5pt">
<tr><td style="padding:3px 0;width:38%;color:#000">Capital</td><td style="padding:3px 0;font-weight:700">$__________</td></tr>
<tr><td style="padding:3px 0;color:#000">Fecha de firma</td><td style="padding:3px 0;font-weight:700">____________________________</td></tr>
<tr><td style="padding:3px 0;color:#000">Domicilio de la garantía</td><td style="padding:3px 0;font-weight:700">____________________________</td></tr>
</table>
</div>

<div style="border:1px solid #000;border-radius:0;padding:10px 16px;margin:16px 0">
<p style="font-weight:800;text-transform:uppercase;font-size:10pt;color:#000;margin:0 0 6px">Estado del contrato original</p>
<p style="margin:0 0 2px;font-size:10.5pt">&#9744;&nbsp;&nbsp;Contrato <strong>VIGENTE</strong> al momento de esta solicitud</p>
<p style="margin:0;font-size:10.5pt">&#9744;&nbsp;&nbsp;Contrato <strong>VENCIDO</strong> al momento de esta solicitud</p>
</div>

<p style="font-weight:800;text-transform:uppercase;margin:20px 0 10px;font-size:11.5pt">Elección del cliente sobre la compensación</p>
<p style="margin:0 0 8px">&#9744;&nbsp;&nbsp;Sí deseo esperar la compensación (Modalidad 1) — 4% al primer año, 5% desde el segundo.</p>
<p style="margin:0 0 16px">&#9744;&nbsp;&nbsp;NO deseo esperar — solo mi capital, en convenio simple (Modalidad 2).</p>

<div style="border:1px solid #000;border-radius:0;padding:12px 16px;margin:16px 0">
<p style="font-weight:800;text-transform:uppercase;font-size:10.5pt;color:#000;margin:0 0 6px">Qué sigue después de esta solicitud</p>
<p style="text-align:justify;margin:0;font-size:11pt">La empresa cuenta con ${PLAZO_DEFINICION_DIAS()} días naturales para definir y confirmar por escrito los términos de la Devolución. Esos términos quedarán documentados en un Convenio de Transacción por separado, el cual se deberá firmar dentro de las 24 horas siguientes a que se entregue. El calendario de pagos (capital y, en su caso, compensación) se contará a partir de esa firma, según la modalidad elegida.</p>
</div>

<p style="text-align:justify;margin-bottom:24px">Declaro que la presente solicitud se presenta de buena fe, sin que medie engaño alguno, en términos del artículo 1815 del Código Civil Federal.</p>

<table style="margin-top:50px;width:100%"><tr>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:45%"><strong>NOMBRE DEL CLIENTE</strong><br><span style="font-size:10.5pt">CLIENTE</span></td>
<td style="width:10%"></td>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:45%"><strong>RAC / Sub-RAC</strong><br><span style="font-size:10.5pt">DIIPA</span></td>
</tr></table>`);
}

export function previewConvenioModalidad1(): string {
  const capital = 1200000;
  const contratoYaVencido = true;
  const compensacionTerminacion = contratoYaVencido ? capital * 0.05 : 0;
  const compAnio1Min = capital * 0.04;
  const compAnio1Max = capital * 0.05;
  const compAnio2 = capital * 0.05;
  const totalSiPideEntre12y24 = capital + compensacionTerminacion + compAnio1Min;
  const totalSiEsperaLos24Meses = capital + compensacionTerminacion + compAnio1Max + compAnio2;
  const hoyTexto = new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" });

  return envolver("Convenio RDC · Modalidad 1", { linea1: "DIIPA · DEVOLUCIÓN COMPENSADA", linea2: "Convenio de transacción", linea3: "Modalidad 1 · con compensación" }, `
<p style="text-align:right;margin-bottom:24px">Mazatlán, Sinaloa a ${hoyTexto}</p>
<p style="margin-bottom:2px"><strong>DESARROLLOS INTELIGENTES DE INMUEBLES Y PROPIEDADES ACCESIBLES, S.A. DE C.V.</strong></p>
<p style="margin-bottom:20px"><strong>Presente.</strong></p>
<p style="text-align:justify;margin-bottom:12px">Por medio de la presente, yo, <strong style="border-bottom:1px solid #000;padding:0 4px">NOMBRE DEL CLIENTE</strong>, en mi carácter de <strong>CLIENTE</strong>, manifiesto estar plenamente consciente de que el contrato original consiste en una prestación de servicios de gestión y recuperación de derechos, y no en una inversión.</p>

<div style="border:1px solid #000;border-radius:0;padding:16px 18px;margin:18px 0">
<p style="margin:0 0 10px;font-family:Arial,sans-serif;font-size:10pt;font-weight:700;color:#000;letter-spacing:0.5px;text-transform:uppercase">Cuándo recibe su capital y su compensación</p>
<table>
${filaLinea("DÍA DE LA FIRMA", "Compensación por Terminación (pago único, contrato ya vencido)", money(compensacionTerminacion))}
${filaLinea(M1_MESES_INICIO_CAPITAL() + " MESES DESDE LA FIRMA", "Inicia el capital · " + M1_NUM_PAGOS_CAPITAL() + " pagos, cada " + MESES_ENTRE_PAGOS_MIN() + "-" + MESES_ENTRE_PAGOS_MAX() + " meses según ventas", "")}
${filaLinea(M1_MESES_INICIO_COMPENSACION() + " MESES DESDE LA FIRMA", "Inicia la compensación · " + M1_NUM_PAGOS_COMPENSACION() + " pagos, cada " + MESES_ENTRE_PAGOS_MIN() + "-" + MESES_ENTRE_PAGOS_MAX() + " meses · siempre DESPUÉS de terminar el capital", money(compAnio1Min + compAnio2))}
</table>
<table style="margin-top:10px"><tr>
<td style="width:50%;padding:10px 12px;border:1px solid #000">
<p style="margin:0 0 2px;font-size:9pt;color:#000">Si pide su capital entre 12 y 24 meses</p>
<p style="margin:0;font-size:13pt;font-weight:800;color:#000">${money(totalSiPideEntre12y24)}</p>
</td>
<td style="width:50%;padding:10px 12px;border:1px solid #000;border-left:none">
<p style="margin:0 0 2px;font-size:9pt;color:#000">Si espera los 24 meses completos</p>
<p style="margin:0;font-size:13pt;font-weight:800;color:#000">${money(totalSiEsperaLos24Meses)}</p>
</td>
</tr></table>
</div>

<p style="margin-bottom:4px;font-family:Arial,sans-serif;font-size:10pt;font-weight:700;color:#000;letter-spacing:0.5px;text-transform:uppercase">Declaraciones</p>
<p style="text-align:justify;margin-bottom:8px"><strong>I.</strong> DIIPA declara ser una sociedad legalmente constituida (Escritura Pública 1,809 de 20 de abril de 2022, Notaría 256 de Mazatlán, Sinaloa).</p>
<p style="text-align:justify;margin-bottom:8px"><strong>II.</strong> Que entre las partes se celebró el contrato de prestación de servicios de fecha [FECHA DE FIRMA], respecto de la garantía [GARANTÍA].</p>
<p style="text-align:justify;margin-bottom:16px"><strong>III.</strong> Que el CLIENTE presentó Solicitud Formal de Devolución, la cual DIIPA acepta en este acto mediante el presente Convenio.</p>

<p style="text-align:justify;margin-bottom:12px"><strong>PRIMERA.</strong> Relación estrictamente civil, fuera de la competencia de CONDUSEF y PROFECO (arts. 2 y 2 Bis, Ley para la Transparencia y Ordenamiento de los Servicios Financieros).</p>
<p style="text-align:justify;margin-bottom:12px"><strong>SEGUNDA.</strong> En términos de los artículos 2944 a 2963 del Código Civil Federal, este instrumento se celebra como convenio de transacción; conforme al art. 2953 tiene, entre las partes, la misma eficacia que la cosa juzgada. No se celebra sobre título nulo ni documentos falsos, ni existe mala fe (arts. 2954–2957).</p>
<p style="text-align:justify;margin-bottom:12px"><strong>TERCERA.</strong> El capital proviene de cesión y gestión de derechos de cobro (arts. 2029 y 2032 CCF), no de inversión, depósito ni captación de recursos del público.</p>
<table style="margin-bottom:16px;font-size:11pt">
<tr><td style="padding:8px;border:1px solid #000;width:65%"><strong>1. Devolución del capital</strong></td><td style="padding:8px;border:1px solid #000;text-align:right;font-weight:800">${money(capital)}</td></tr>
<tr><td style="padding:8px;border:1px solid #000"><strong>2. Compensación por Terminación</strong></td><td style="padding:8px;border:1px solid #000;text-align:right;font-weight:800">${money(compensacionTerminacion)}</td></tr>
<tr><td style="padding:8px;border:1px solid #000"><strong>3. Compensación por Espera</strong><br><span style="font-size:10pt">Aún faltan ${PLAZO_MESES_PARA_COMPENSACION()} meses para la primera.</span></td><td style="padding:8px;border:1px solid #000;text-align:right;font-weight:800">$0</td></tr>
<tr><td style="padding:10px 8px;border:2px solid #000"><strong style="color:#000">Total Devolución Compensada (RDC)</strong></td><td style="padding:10px 8px;border:2px solid #000;text-align:right;font-weight:800;font-size:13pt;color:#000">${money(capital + compensacionTerminacion)}</td></tr>
</table>
<p style="text-align:justify;margin-bottom:12px"><strong>CUARTA.</strong> El CLIENTE cuenta con ${PLAZO_FIRMA_HORAS()} horas a partir de la entrega/descarga para firmar el convenio; de no hacerlo, la solicitud queda cancelada.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>QUINTA.</strong> El capital se cubrirá en ${M1_NUM_PAGOS_CAPITAL()} pagos, cada ${MESES_ENTRE_PAGOS_MIN()} a ${MESES_ENTRE_PAGOS_MAX()} meses según ventas — no mensuales ni de monto fijo. Inician a partir de los ${M1_MESES_INICIO_CAPITAL()} meses desde la firma.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>SEXTA.</strong> La Compensación por Espera requiere permanecer mínimo ${PLAZO_MESES_PARA_COMPENSACION()} meses desde la firma: 4% al año 1, 5% desde el año 2, sobre el saldo pendiente. Se cubre en ${M1_NUM_PAGOS_COMPENSACION()} pagos, cada ${MESES_ENTRE_PAGOS_MIN()} a ${MESES_ENTRE_PAGOS_MAX()} meses, iniciando a los ${M1_MESES_INICIO_COMPENSACION()} meses de firmado — siempre después de terminar el capital. Si a los 24 meses el cliente pide solo la compensación, el plazo se extiende un año más.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>SÉPTIMA.</strong> Ambas partes declaran buena fe, sin dolo ni mala fe (arts. 1815–1817 CCF), sin actualizarse el tipo penal de fraude (art. 386 CPF). El convenio tiene, entre ellas, la misma eficacia que una sentencia ejecutoriada.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>OCTAVA.</strong> El CLIENTE podrá optar, en lugar de recibir su Devolución en efectivo, por solicitar un cambio de garantía, aplicando el monto correspondiente al valor de la nueva garantía.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>NOVENA.</strong> Cubierta la Devolución, el CLIENTE otorga a DIIPA el más amplio finiquito, sin reservarse acción ni derecho alguno, y se obliga a guardar confidencialidad sobre los términos de este convenio.</p>
<p style="text-align:justify;margin-bottom:24px"><strong>DÉCIMA.</strong> En caso de incumplimiento del CLIENTE, los honorarios devengados por DIIPA quedan firmes a su favor (15% del valor de la operación). Cualquier demanda, costa, daño o difamación promovida por el CLIENTE relacionada con este convenio corre por su cuenta exclusiva.</p>

<table style="margin-top:50px;width:100%"><tr>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:45%"><strong>NOMBRE DEL CLIENTE</strong><br><span style="font-size:10.5pt">CLIENTE</span></td>
<td style="width:10%"></td>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:45%"><strong>Apoderado DIIPA</strong></td>
</tr></table>`);
}

export function previewConvenioModalidad2(): string {
  const capital = 350000;
  const contratoYaVencido = true;
  const compensacionPorVencimiento = contratoYaVencido ? capital * 0.05 : 0;
  const total = capital + compensacionPorVencimiento;
  const hoyTexto = new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" });

  return envolver("Convenio · Modalidad 2", { linea1: "DIIPA · DEVOLUCIÓN DE CAPITAL", linea2: "Convenio de devolución de capital", linea3: "Modalidad 2 · sin espera de compensación" }, `
<p style="text-align:right;margin-bottom:24px">Mazatlán, Sinaloa a ${hoyTexto}</p>
<p style="margin-bottom:2px"><strong>DESARROLLOS INTELIGENTES DE INMUEBLES Y PROPIEDADES ACCESIBLES, S.A. DE C.V.</strong></p>
<p style="margin-bottom:20px"><strong>Presente.</strong></p>
<p style="text-align:justify;margin-bottom:12px">Por medio de la presente, yo, <strong style="border-bottom:1px solid #000;padding:0 4px">NOMBRE DEL CLIENTE</strong>, manifiesto que NO deseo esperar la compensación del 5% anual, y opto por esta vía expedita, en pleno uso de mi derecho.</p>

<div style="border:1px solid #000;border-radius:0;padding:16px 18px;margin:18px 0">
<p style="margin:0 0 10px;font-family:Arial,sans-serif;font-size:10pt;font-weight:700;color:#000;letter-spacing:0.5px;text-transform:uppercase">Cuándo recibe su capital</p>
<table>
${filaLinea("DÍA DE LA FIRMA", "Compensación por Terminación (pago único, contrato ya vencido)", money(compensacionPorVencimiento))}
${filaLinea("DESDE LA FIRMA", "Hasta " + M2_NUM_PAGOS_MAX() + " pagos de capital, cada " + MESES_ENTRE_PAGOS_MIN() + "-" + MESES_ENTRE_PAGOS_MAX() + " meses según ventas · empiezan a los " + M2_MESES_INICIO() + " meses de firmado", "")}
</table>
<table style="margin-top:10px"><tr><td style="padding:10px 12px;border:1px solid #000">
<p style="margin:0 0 2px;font-size:9pt;color:#000">Total estimado a devolver</p>
<p style="margin:0;font-size:13pt;font-weight:800;color:#000">${money(total)}</p>
</td></tr></table>
</div>

<p style="margin-bottom:4px;font-family:Arial,sans-serif;font-size:10pt;font-weight:700;color:#000;letter-spacing:0.5px;text-transform:uppercase">Declaraciones</p>
<p style="text-align:justify;margin-bottom:8px"><strong>I.</strong> DIIPA declara ser una sociedad legalmente constituida (Escritura Pública 1,809 de 20 de abril de 2022, Notaría 256 de Mazatlán, Sinaloa).</p>
<p style="text-align:justify;margin-bottom:8px"><strong>II.</strong> Que entre las partes se celebró el contrato de prestación de servicios de fecha [FECHA DE FIRMA], respecto de la garantía [GARANTÍA].</p>
<p style="text-align:justify;margin-bottom:16px"><strong>III.</strong> Que el CLIENTE presentó Solicitud Formal de Devolución, la cual DIIPA acepta en este acto mediante el presente Convenio.</p>

<p style="text-align:justify;margin-bottom:12px"><strong>PRIMERA.</strong> Relación estrictamente civil (arts. 2029, 2032 CCF), fuera de la competencia de CONDUSEF y PROFECO.</p>
<table style="margin-bottom:16px;font-size:11pt">
<tr><td style="padding:8px;border:1px solid #000;width:65%"><strong>1. Devolución del capital</strong></td><td style="padding:8px;border:1px solid #000;text-align:right;font-weight:800">${money(capital)}</td></tr>
<tr><td style="padding:8px;border:1px solid #000"><strong>2. Compensación por terminación</strong></td><td style="padding:8px;border:1px solid #000;text-align:right;font-weight:800">${money(compensacionPorVencimiento)}</td></tr>
<tr><td style="padding:10px 8px;border:2px solid #000"><strong style="color:#000">Total a devolver</strong></td><td style="padding:10px 8px;border:2px solid #000;text-align:right;font-weight:800;font-size:13pt;color:#000">${money(total)}</td></tr>
</table>
<p style="text-align:justify;margin-bottom:12px"><strong>SEGUNDA.</strong> El capital se cubrirá en hasta ${M2_NUM_PAGOS_MAX()} pagos, cada ${MESES_ENTRE_PAGOS_MIN()} a ${MESES_ENTRE_PAGOS_MAX()} meses según ventas — no mensuales ni de monto fijo. Inician a los ${M2_MESES_INICIO()} meses de firmado.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>TERCERA.</strong> El convenio únicamente puede firmarse en presencia del Gerente de sucursal, quien co-firma como testigo (sin responsabilidad solidaria por los pagos de DIIPA). ${PLAZO_FIRMA_HORAS()} horas para firmarlo y subirlo.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>CUARTA.</strong> Esta vía entra con menor prioridad de pago que las devoluciones con compensación (RDC) — un criterio de orden, no una penalización (art. 1840 CCF).</p>
<p style="text-align:justify;margin-bottom:12px"><strong>QUINTA.</strong> Buena fe, sin dolo (arts. 1815–1817 CCF). El convenio tiene, entre las partes, la misma eficacia que una sentencia ejecutoriada (art. 2953 CCF).</p>
<p style="text-align:justify;margin-bottom:12px"><strong>SEXTA.</strong> El CLIENTE podrá optar, en lugar de recibir su Devolución en efectivo, por solicitar un cambio de garantía, aplicando el monto correspondiente al valor de la nueva garantía.</p>
<p style="text-align:justify;margin-bottom:12px"><strong>SÉPTIMA.</strong> Cubierta la Devolución, el CLIENTE otorga a DIIPA el más amplio finiquito, sin reservarse acción ni derecho alguno, y se obliga a guardar confidencialidad sobre los términos de este convenio.</p>
<p style="text-align:justify;margin-bottom:24px"><strong>OCTAVA.</strong> En caso de incumplimiento del CLIENTE, los honorarios devengados por DIIPA quedan firmes a su favor (15% del valor de la operación). Cualquier demanda, costa, daño o difamación promovida por el CLIENTE relacionada con este convenio corre por su cuenta exclusiva.</p>

<table style="margin-top:50px;width:100%"><tr>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:33%"><strong>NOMBRE DEL CLIENTE</strong><br><span style="font-size:10.5pt">CLIENTE</span></td>
<td style="width:10%"></td>
<td style="text-align:center;border-top:1px solid #000;padding-top:6px;width:33%"><strong>NOMBRE DEL GERENTE</strong><br><span style="font-size:10.5pt">Gerente de sucursal · testigo</span></td>
</tr></table>`);
}

export function previewExplicacionCliente(): string {
  const capital = 1200000;
  const terminacion = capital * 0.05;
  const anio1 = capital * 0.04;
  const anio1Completo = capital * 0.05;
  const anio2 = capital * 0.05;
  const totalEntre12y24 = capital + terminacion + anio1;
  const total24Completos = capital + terminacion + anio1Completo + anio2;
  const diario = anio1 / 365;

  return envolver("Tu devolución — explicación", { linea1: "DIIPA · DEVOLUCIÓN COMPENSADA", linea2: "Esto es lo que puedes hacer con tu capital", linea3: "Una explicación sencilla, para que decidas informado" }, `
<div style="border:1px solid #000;border-radius:0;padding:16px 20px;margin-bottom:20px">
<p style="font-weight:800;color:#000;margin:0 0 6px;font-size:12.5pt">Antes que nada: ¿y si te quedas con nosotros?</p>
<p style="margin:0;color:#000">Con un cambio de garantía (R3) puedes ganar hasta el <strong>45%</strong> — sobre ${money(capital)}, serían aproximadamente <strong>${money(capital * 0.45)}</strong> — con una garantía positiva ya predictaminada, conservas tu antigüedad y no esperas ningún trámite. Pregúntale a tu asesor.</p>
</div>

<p style="text-align:justify;margin-bottom:8px;font-weight:800">¿Cómo se ve el proceso completo, de la solicitud al pago?</p>
<ol style="margin:0 0 20px;padding-left:20px">
<li style="margin-bottom:6px">Presentas tu solicitud en sucursal, con tu INE en mano.</li>
<li style="margin-bottom:6px">Gerente/DGE/RAC validan tus datos y documentos contra tu contrato original.</li>
<li style="margin-bottom:6px">RAC/Sub-RAC revisan y liberan tu Solicitud Formal (15-30 días).</li>
<li style="margin-bottom:6px">DIIPA tiene hasta ${PLAZO_DEFINICION_DIAS()} días para confirmarte por escrito monto y calendario.</li>
<li style="margin-bottom:6px">Firmas tu Convenio dentro de las 24 horas siguientes a que se te entregue.</li>
<li>Entras al calendario de pagos — Modalidad 1 siempre antes que Modalidad 2.</li>
</ol>

<div style="border:1px solid #000;border-radius:0;padding:16px 18px;margin-bottom:20px">
<p style="margin:0 0 10px;font-family:Arial,sans-serif;font-size:10pt;font-weight:700;color:#000;letter-spacing:0.5px;text-transform:uppercase">Cuánto vas ganando, y cuándo</p>
<table>
${filaLinea("DÍA DE LA FIRMA", "Compensación por Terminación (si tu contrato ya venció)", money(terminacion))}
${filaLinea("MIENTRAS ESTÉS EN EL AÑO 1", "Tu compensación va generando cada día", money(diario) + "/día")}
${filaLinea(M1_MESES_INICIO_CAPITAL() + " MESES DESPUÉS DE LA FIRMA", "Inicia tu capital · " + M1_NUM_PAGOS_CAPITAL() + " pagos, cada " + MESES_ENTRE_PAGOS_MIN() + "-" + MESES_ENTRE_PAGOS_MAX() + " meses según ventas", "")}
${filaLinea(M1_MESES_INICIO_COMPENSACION() + " MESES DESPUÉS DE LA FIRMA", "Inicia tu compensación · " + M1_NUM_PAGOS_COMPENSACION() + " pagos, siempre DESPUÉS de tu capital completo", money(anio1 + anio2))}
</table>
</div>

<table style="width:100%;border-collapse:collapse;margin-bottom:20px">
<tr>
<td style="width:50%;vertical-align:top;padding:14px;border:1px solid #000;border-radius:0">
<p style="font-weight:800;margin:0 0 8px;color:#000">Modalidad 1 · esperando (con ganancia)</p>
<p style="margin:0 0 4px">Capital: <strong>${money(capital)}</strong></p>
<p style="margin:0 0 4px;color:#000">Si pides entre 12 y 24 meses: <strong>${money(totalEntre12y24)}</strong></p>
<p style="margin:0;color:#000">Si esperas los 24 meses completos: <strong>${money(total24Completos)}</strong></p>
</td>
<td style="width:50%;vertical-align:top;padding:14px;border:1.5px solid #e5e7eb;border-radius:0 10px 10px 0">
<p style="font-weight:800;margin:0 0 8px;color:#000">Modalidad 2 · convenio simple</p>
<p style="margin:0 0 4px">Capital: <strong>${money(capital)}</strong></p>
<p style="margin:0 0 10px;color:#000">+ ${money(terminacion)} por terminación (si tu contrato ya venció) — sin compensación adicional por espera</p>
<p style="margin:0;font-size:10.5pt;color:#000">Entra a la fila de pago después de que se cubran todos los de Modalidad 1, en pagos de hasta $40,000.</p>
</td>
</tr>
</table>

<div style="border:1px solid #000;padding:12px 16px">
<p style="margin:0;font-size:10.5pt;color:#000">*Los montos son un ejemplo — los tuyos se calculan sobre tu capital real cuando presentes tu solicitud.</p>
</div>`);
}

export function abrirVistaPrevia(html: string) {
  const win = window.open("", "_blank", "width=820,height=900");
  if (!win) { alert("Tu navegador bloqueó la ventana. Permite popups para esta página."); return; }
  win.document.write(html);
  win.document.close();
}
