// EXPEDIENTE DEL COLABORADOR (Drive, Word .docx) → va en: src/data/expedienteColaborador.ts
import { type Colaborador } from "./colaboradores";
import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  ImageRun, AlignmentType, WidthType, BorderStyle, TableLayoutType,
} from "docx";

const AREA_NOMBRE: Record<string, string> = {
  juridico: "Jurídico", comercial: "Comercial", atencion: "Atención al Cliente",
  administracion: "Administración", contabilidad: "Contabilidad", tecnologia: "Tecnología", direccion: "Dirección",
};
function carpetaArea(a?: string | null): string {
  const k = (a || "").trim();
  return AREA_NOMBRE[k] || k || "General";
}
function fechaBonita(iso?: string | null): string {
  if (!iso) return "—";
  try { return new Date(iso).toLocaleDateString("es-MX", { day: "2-digit", month: "long", year: "numeric" }); } catch { return iso; }
}

// Colores de la marca DIIPA (sin #).
const AZUL = "102A43";
const TEAL = "0E7C7B";
const GRIS = "5A6B78";
const HUMO = "8A97A3";
const LINEA = "D9E1E8";
const FONDO_ET = "F1F5F8";

type ImgType = "jpg" | "png" | "gif" | "bmp";

// Baja la foto del colaborador para meterla al Word (si se puede).
async function bajarFoto(url?: string | null): Promise<{ data: Uint8Array; type: ImgType } | null> {
  if (!url) return null;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    const buf = new Uint8Array(await res.arrayBuffer());
    let type: ImgType = "jpg";
    const u = url.toLowerCase();
    if (ct.includes("png") || u.endsWith(".png")) type = "png";
    else if (ct.includes("gif") || u.endsWith(".gif")) type = "gif";
    else if (ct.includes("bmp") || u.endsWith(".bmp")) type = "bmp";
    return { data: buf, type };
  } catch { return null; }
}

// Una fila de la tabla de datos: etiqueta (gris, fondo) + valor.
function filaDato(label: string, valor?: string | null): TableRow {
  return new TableRow({
    children: [
      new TableCell({
        width: { size: 34, type: WidthType.PERCENTAGE },
        shading: { fill: FONDO_ET },
        margins: { top: 70, bottom: 70, left: 140, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: label.toUpperCase(), bold: true, size: 16, color: GRIS })] })],
      }),
      new TableCell({
        width: { size: 66, type: WidthType.PERCENTAGE },
        margins: { top: 70, bottom: 70, left: 140, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: valor || "—", size: 20, color: AZUL })] })],
      }),
    ],
  });
}

async function construirDocx(c: Colaborador, autor: string): Promise<Document> {
  const area = carpetaArea(c.area);
  const foto = await bajarFoto(c.foto_url);

  const encabezado: Paragraph[] = [];
  encabezado.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "DIIPA · INMUEBLES ACCESIBLES", bold: true, size: 16, color: TEAL, characterSpacing: 30 })],
  }));
  if (foto) {
    encabezado.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 160, after: 80 },
      children: [new ImageRun({ data: foto.data, type: foto.type, transformation: { width: 96, height: 96 } })],
    }));
  }
  encabezado.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: foto ? 0 : 120, after: 20 },
    children: [new TextRun({ text: c.nombre || "—", bold: true, size: 44, color: AZUL })],
  }));
  encabezado.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: c.puesto || "—", size: 22, color: GRIS })],
  }));
  encabezado.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 60 },
    children: [
      new TextRun({ text: `Área: ${area}`, size: 18, color: GRIS }),
      new TextRun({ text: "      " }),
      new TextRun({ text: c.activo ? "● Activo" : "● Inactivo", bold: true, size: 18, color: c.activo ? "0F7A43" : "B42318" }),
    ],
  }));

  const titulo = new Paragraph({
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text: "FICHA DEL COLABORADOR", bold: true, size: 20, color: TEAL, characterSpacing: 20 })],
  });

  const bordeFino = { style: BorderStyle.SINGLE, size: 4, color: LINEA };
  const tabla = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    columnWidths: [3000, 7080],
    borders: {
      top: bordeFino, bottom: bordeFino, left: bordeFino, right: bordeFino,
      insideHorizontal: bordeFino, insideVertical: bordeFino,
    },
    rows: [
      filaDato("Extensión", c.extension),
      filaDato("Teléfono", c.telefono),
      filaDato("Número oficial", c.numero_oficial),
      filaDato("WhatsApp", c.whatsapp),
      filaDato("Correo", c.correo),
      filaDato("Rol en el sistema", c.rol_sistema),
      filaDato("Área", area),
      filaDato("Fecha de alta", fechaBonita(c.created_at)),
    ],
  });

  const pie = new Paragraph({
    spacing: { before: 280 },
    children: [new TextRun({
      text: `Generado el ${fechaBonita(new Date().toISOString())} por ${autor || "—"} · Documento interno de DIIPA`,
      size: 16, color: HUMO, italics: true,
    })],
  });

  return new Document({
    creator: "DIIPA",
    title: `Ficha del colaborador — ${c.nombre || ""}`,
    sections: [{
      properties: { page: { margin: { top: 1080, bottom: 1080, left: 1080, right: 1080 } } },
      children: [...encabezado, titulo, tabla, pie],
    }],
  });
}

// Crea/usa la carpeta del colaborador (Área → Colaborador) y guarda su ficha en Word (.docx).
export async function generarExpedienteColaborador(
  c: Colaborador
): Promise<{ ok: boolean; link?: string; error?: string }> {
  try {
    let autor = "Sistema";
    try {
      const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
      autor = y?.nombre || autor;
    } catch {}

    const doc = await construirDocx(c, autor);
    const base64 = await Packer.toBase64String(doc); // el .docx ya viene en base64
    const ruta = [carpetaArea(c.area), c.nombre || "Colaborador"];

    const r = await fetch("/.netlify/functions/subir-grabacion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        archivo: base64,
        nombre: "Ficha del colaborador.docx",
        tipo: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ruta,
      }),
    });
    const data = await r.json();
    if (data && data.ok) {
      const link = data.carpeta
        ? "https://drive.google.com/drive/folders/" + data.carpeta
        : data.link;
      return { ok: true, link };
    }
    return { ok: false, error: (data && data.error) || "No se pudo crear el expediente" };
  } catch (e: any) {
    return { ok: false, error: (e && e.message) || String(e) };
  }
}
