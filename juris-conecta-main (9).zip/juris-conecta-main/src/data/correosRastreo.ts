// Rastreo de apertura de correos (estilo HubSpot).
// Cada correo enviado con rastreo crea una fila aquí. El pixel invisible del
// correo, al abrirse, suma aperturas y guarda la fecha de la 1ª apertura.
import { supabase } from "../lib/supabase";

export type CorreoRastreo = {
  id: string;
  clienteId: string;
  asunto: string | null;
  para: string | null;
  enviadoPor: string | null;
  enviadoAt: string;
  aperturas: number;
  abiertoAt: string | null;
};

// Crea la fila ANTES de enviar y devuelve su id (para armar el pixel).
export async function crearRastreo(p: {
  clienteId: string;
  para?: string | null;
  enviadoPor?: string | null;
}): Promise<{ id: string } | null> {
  const { data, error } = await supabase
    .from("correos_rastreo")
    .insert({
      cliente_id: p.clienteId,
      para: p.para || null,
      enviado_por: p.enviadoPor || null,
    })
    .select("id")
    .single();
  if (error || !data) return null;
  return { id: data.id as string };
}

// Una vez enviado, le ponemos el asunto a la fila (para mostrarlo en la lista).
export async function actualizarAsuntoRastreo(id: string, asunto: string): Promise<void> {
  await supabase.from("correos_rastreo").update({ asunto }).eq("id", id);
}

// Si el envío FALLÓ (ej. permiso de Google expirado), hay que borrar la fila que
// se había creado de antemano para el pixel — si no, queda un "Enviado" fantasma
// aunque el correo nunca haya salido.
export async function borrarRastreo(id: string): Promise<void> {
  await supabase.from("correos_rastreo").delete().eq("id", id);
}

export async function fetchRastreoCliente(clienteId: string): Promise<CorreoRastreo[]> {
  const { data, error } = await supabase
    .from("correos_rastreo")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("enviado_at", { ascending: false });
  if (error || !data) return [];
  return data.map((r: any) => ({
    id: r.id,
    clienteId: r.cliente_id,
    asunto: r.asunto,
    para: r.para,
    enviadoPor: r.enviado_por,
    enviadoAt: r.enviado_at,
    aperturas: r.aperturas || 0,
    abiertoAt: r.abierto_at,
  }));
}
