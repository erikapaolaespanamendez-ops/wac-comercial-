// =====================================================================
//  CACHÉ DE PERMISOS  →  va en: src/data/permisosCache.ts
//
//  Guarda EN MEMORIA lo último que se leyó de la tabla app_permisos, para
//  poder consultarlo de forma SÍNCRONA (puedeAccion, niveles, seguimiento)
//  sin tener que esperar a Supabase en cada render.
//
//  Este archivo NO importa nada de roles.ts ni de permisos.ts, a propósito,
//  para que no haya "import circular". Solo es un cajoncito con avisos.
// =====================================================================

export type PermisosCache = {
  modulos: Record<string, string[]>;
  acciones: Record<string, string[]>;
  clientes: Record<string, Record<string, string>>;
  seguimiento: Record<string, { prospecto: Record<string, boolean>; cliente: Record<string, boolean> }>;
};

let _cache: PermisosCache | null = null;
let _version = 0;
const _subs = new Set<() => void>();

// Lo que tenemos cargado ahora (null = todavía no se ha leído nada → usar el código).
export function getPermisosCache(): PermisosCache | null {
  return _cache;
}

// Un número que sube cada vez que cambia el caché (para forzar re-render con un hook).
export function getPermisosVersion(): number {
  return _version;
}

// Guarda lo recién leído y avisa a quien esté escuchando.
export function setPermisosCache(c: PermisosCache | null): void {
  _cache = c;
  _version++;
  _subs.forEach((fn) => {
    try { fn(); } catch { /* sin ruido */ }
  });
}

// Escuchar cambios del caché (devuelve la función para dejar de escuchar).
export function suscribirPermisos(fn: () => void): () => void {
  _subs.add(fn);
  return () => { _subs.delete(fn); };
}
