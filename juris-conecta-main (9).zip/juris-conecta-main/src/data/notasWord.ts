// =====================================================================
//  NOTAS DE VIDEOLLAMADA · genera un Word (.docx) con membrete DIIPA
//  y lo descarga en la computadora. (Fase 2 · notas con IA)
// =====================================================================
import { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } from "docx";
import { BRAND } from "../brand";
import type { Reunion } from "./reuniones";

// Colores de la marca DIIPA (sin #).
const AZUL = "102A43";
const TEAL = "0E7C7B";
const GRIS = "5A6B78";

function fechaBonita(iso?: string | null): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("es-MX", {
      day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit",
    });
  } catch { return iso; }
}

function nombreArchivo(r: Reunion): string {
  const base = (r.titulo || r.destino || "videollamada")
    .toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "videollamada";
  return `notas-${base}.docx`;
}

// ¿La línea parece un título de sección? (ej. "1) Resumen", "Acuerdos:", "ACUERDOS")
function esEncabezado(linea: string): boolean {
  const t = linea.trim();
  if (!t) return false;
  if (/^\d+[\).\-]\s+/.test(t)) return true;               // "1) ..."  "2. ..."
  if (/^[A-ZÁÉÍÓÚÑ][^a-z]*:?\s*$/.test(t) && t.length <= 30) return true; // "ACUERDOS"
  if (/:$/.test(t) && t.length <= 40) return true;          // "Pendientes:"
  return false;
}

// Convierte el texto de las notas en párrafos de Word (encabezados en negritas).
function parrafosDeNotas(notas: string): Paragraph[] {
  const lineas = (notas || "").split(/\r?\n/);
  const out: Paragraph[] = [];
  for (const raw of lineas) {
    const linea = raw.replace(/^[•*\-]\s*/, "• "); // viñetas uniformes
    if (!linea.trim()) { out.push(new Paragraph({ text: "" })); continue; }
    const encabezado = esEncabezado(linea);
    out.push(new Paragraph({
      spacing: { before: encabezado ? 160 : 0, after: 60 },
      children: [new TextRun({
        text: linea,
        bold: encabezado,
        size: encabezado ? 24 : 22,         // 12pt / 11pt
        color: encabezado ? TEAL : "1F2933",
      })],
    }));
  }
  return out;
}

function lineaSep(): Paragraph {
  return new Paragraph({
    spacing: { before: 80, after: 160 },
    border: { bottom: { color: "D9E1E8", space: 1, style: BorderStyle.SINGLE, size: 6 } },
    children: [new TextRun({ text: "" })],
  });
}

function dato(etiqueta: string, valor: string): Paragraph {
  return new Paragraph({
    spacing: { after: 40 },
    children: [
      new TextRun({ text: etiqueta + ": ", bold: true, size: 20, color: GRIS }),
      new TextRun({ text: valor, size: 20, color: "1F2933" }),
    ],
  });
}

// Arma el documento Word completo.
function construirDoc(r: Reunion): Document {
  const titulo = r.titulo || r.destino || "Videollamada";
  return new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({
          alignment: AlignmentType.LEFT,
          spacing: { after: 20 },
          children: [new TextRun({ text: BRAND.empresa, bold: true, size: 20, color: TEAL })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          children: [new TextRun({ text: "Notas de la videollamada", bold: true, size: 32, color: AZUL })],
        }),
        dato("Reunión", titulo),
        dato("Tipo", r.tipo === "cliente" ? "Con cliente" : "Equipo"),
        dato("Creada por", r.creado_por || "—"),
        dato("Fecha", fechaBonita(r.created_at)),
        ...(r.notas_at ? [dato("Notas generadas", fechaBonita(r.notas_at))] : []),
        lineaSep(),
        ...parrafosDeNotas(r.notas || "Esta reunión no tiene notas."),
        ...(r.transcripcion ? [
          lineaSep(),
          new Paragraph({
            spacing: { before: 120, after: 60 },
            children: [new TextRun({ text: "Transcripción (lo que se habló)", bold: true, size: 24, color: TEAL })],
          }),
          ...parrafosDeNotas(r.transcripcion),
        ] : []),
        new Paragraph({
          spacing: { before: 240 },
          children: [new TextRun({
            text: "Documento generado automáticamente por " + BRAND.nombre + ".",
            italics: true, size: 16, color: "8A97A3",
          })],
        }),
      ],
    }],
  });
}

// Genera y descarga el Word de notas de una reunión.
export async function descargarNotasWord(r: Reunion): Promise<void> {
  const doc = construirDoc(r);
  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nombreArchivo(r);
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
