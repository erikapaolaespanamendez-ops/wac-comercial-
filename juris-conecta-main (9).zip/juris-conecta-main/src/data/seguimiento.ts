// ===================================================================
// Motor de seguimiento  →  src/data/seguimiento.ts
// ===================================================================
import { supabase } from "../lib/supabase";
import { fetchClientes, invalidarClientes, type Cliente, type Codigo } from "./clientes";
import { fetchCatalogo, type CatalogoCodigo, type AccionCodigo, type Etiqueta } from "./catalogoCodigos";
import { avisarEvento } from "./avisarEvento";
import { registrarComunicacion } from "./comunicaciones";

export type EstadoSeguimiento = "vencido" | "porvencer" | "aldia" | "sinplazo";
export type Falta = "llamada" | "correo" | "ambos" | null;

export const CODIGOS_VALIDOS: Codigo[] = ["SVT", "RV", "R1", "R1V", "R2", "R2C", "R3", "RD", "RDC"];

export type ClienteSeguimiento = {
  cliente: Cliente;
  ultimaLlamada: string | null;
  ultimoCorreo: string | null;
  ultimoContacto: string | null;
  diasDesdeCiclo: number | null;
  diasLimite: number | null;
  estado: EstadoSeguimiento;
  responsable: string;
  falta: Falta;
  faltaBoletin: boolean;   // 👈 NUEVO (Fase 3B): R2/R2C/R3 sin boletín de esta semana
  contingencia: boolean;   // 👈 NUEVO (Fase G3): cliente con demanda activa (prioritario)
  faltaAvance: boolean;    // 👈 NUEVO (Fase G3): contingencia activa sin avance de esta semana
  convenio: boolean;       // 👈 NUEVO (H1): cliente con convenio de devolución
  salidas: Codigo[];
  acciones: AccionCodigo[];   // 👈 FASE D2b: acciones para atender (del catálogo)
  accionesHechas: Record<string, string>;   // 👈 FASE D3c: acción -> última fecha hecha
  faltaAccion: string | null;               // 👈 FASE D3c: acción obligatoria pendiente
  etiquetas: Etiqueta[];                     // 👈 FASE G1: indicadores activos del cliente
  areasCompartidas: string[];
  rolesApoyo: string[];
};

const DIAS_AVISO = 3;

// 👇 Fase 3B: códigos que DEBEN tener boletín judicial cada semana.
const CODIGOS_BOLETIN = new Set<string>(["R2", "R2C", "R3"]);

// Última fecha de boletín (tipo 'boletin') por cliente.
async function fetchBoletines(): Promise<Map<string, string>> {
  const m = new Map<string, string>();
  try {
    const { data, error } = await supabase
      .from("actuaciones_cliente")
      .select("cliente_id, fecha")
      .eq("tipo", "boletin");
    if (!error && data) {
      for (const r of data as any[]) {
        const id = String(r.cliente_id);
        const prev = m.get(id);
        if (r.fecha && (!prev || r.fecha > prev)) m.set(id, r.fecha);
      }
    }
  } catch {}
  return m;
}

// Clientes con contingencia/demanda activa.
async function fetchContingencias(): Promise<Set<string>> {
  const s = new Set<string>();
  try {
    const { data, error } = await supabase
      .from("contingencia_cliente")
      .select("cliente_id, tiene_demanda")
      .eq("tiene_demanda", true);
    if (!error && data) {
      for (const r of data as any[]) if (r.cliente_id) s.add(String(r.cliente_id));
    }
  } catch {}
  return s;
}

// Clientes con convenio de devolución activo.
async function fetchConvenios(): Promise<Set<string>> {
  const s = new Set<string>();
  try {
    const { data, error } = await supabase
      .from("convenio_devolucion")
      .select("cliente_id, tiene_convenio")
      .eq("tiene_convenio", true);
    if (!error && data) {
      for (const r of data as any[]) if (r.cliente_id) s.add(String(r.cliente_id));
    }
  } catch {}
  return s;
}

// Última fecha de "avance" (actuación jurídica) por cliente.
async function fetchAvances(): Promise<Map<string, string>> {
  const m = new Map<string, string>();
  try {
    const { data, error } = await supabase
      .from("actuaciones_cliente")
      .select("cliente_id, fecha")
      .eq("tipo", "actuacion");
    if (!error && data) {
      for (const r of data as any[]) {
        const id = String(r.cliente_id);
        const prev = m.get(id);
        if (r.fecha && (!prev || r.fecha > prev)) m.set(id, r.fecha);
      }
    }
  } catch {}
  return m;
}

type Contactos = { ultima_llamada: string | null; ultimo_correo: string | null; ultimo_cualquiera: string | null };

async function fetchContactos(): Promise<Map<string, Contactos>> {
  const m = new Map<string, Contactos>();
  const { data, error } = await supabase
    .from("seguimiento_contactos_cliente")
    .select("cliente_id, ultima_llamada, ultimo_correo, ultimo_cualquiera");
  if (!error && data) {
    for (const r of data as any[]) {
      if (r.cliente_id) m.set(String(r.cliente_id), {
        ultima_llamada: r.ultima_llamada ?? null,
        ultimo_correo: r.ultimo_correo ?? null,
        ultimo_cualquiera: r.ultimo_cualquiera ?? null,
      });
    }
  }
  return m;
}

async function fetchCompartidas(): Promise<Map<string, string[]>> {
  const m = new Map<string, string[]>();
  try {
    const { data, error } = await supabase.from("clientes").select("id, areas_compartidas");
    if (!error && data) {
      for (const r of data as any[]) {
        if (r.id) m.set(String(r.id), Array.isArray(r.areas_compartidas) ? r.areas_compartidas : []);
      }
    }
  } catch {}
  return m;
}

function diasDesde(iso: string): number {
  return Math.floor((Date.now() - new Date(iso).getTime()) / (1000 * 60 * 60 * 24));
}

function calcEstado(dias: number, limite: number, aviso: number = DIAS_AVISO): EstadoSeguimiento {
  if (dias > limite) return "vencido";
  if (dias >= limite - aviso) return "porvencer";
  return "aldia";
}

function parsearSalidas(texto: string | undefined, actual: string): Codigo[] {
  if (!texto) return [];
  return texto
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter((s) => (CODIGOS_VALIDOS as string[]).includes(s) && s !== actual) as Codigo[];
}

// 👇 FASE D3c: trae las acciones marcadas como hechas, agrupadas por cliente (la más reciente por acción).
async function fetchAcciones(): Promise<Map<string, Map<string, string>>> {
  const m = new Map<string, Map<string, string>>();
  const { data, error } = await supabase
    .from("acciones_cliente")
    .select("cliente_id, accion, fecha")
    .order("fecha", { ascending: false });
  if (error || !data) return m;
  for (const row of data as Array<{ cliente_id: string; accion: string; fecha: string }>) {
    const cid = String(row.cliente_id);
    if (!m.has(cid)) m.set(cid, new Map());
    const inner = m.get(cid)!;
    if (!inner.has(row.accion)) inner.set(row.accion, row.fecha); // la primera (orden desc) es la más reciente
  }
  return m;
}

// ============================================================================
//  CACHÉ COMPARTIDA DE SEGUIMIENTO
//
//  Motivo (04-sep-2026): fetchSeguimiento() dispara NUEVE consultas en paralelo
//  (clientes, catálogo, contactos, compartidas, boletines, contingencias,
//  avances, convenios y acciones). La campanita lo ejecutaba cada 5 minutos en
//  cada pestaña abierta SOLO para contar cuántos clientes van vencidos, y
//  además lo llaman Seguimiento, MiListaDelDia y KpisAtencion.
//
//  Se ejecutó unas 24,600 veces en 82 días. De ahí salen los 49,207 barridos
//  de actuaciones_cliente, los 24,474 de contingencia y los 24,270 de convenios.
//
//  Ahora hay una sola copia viva por 2 minutos, y las llamadas simultáneas
//  comparten una sola ejecución. Cualquier escritura la tira.
// ============================================================================
const VIGENCIA_SEG_MS = 120000;
let cacheSeg: ClienteSeguimiento[] | null = null;
let cacheSegHasta = 0;
let segEnVuelo: Promise<ClienteSeguimiento[]> | null = null;

/** Tira la copia guardada del seguimiento. */
export function invalidarSeguimiento(): void {
  cacheSeg = null;
  cacheSegHasta = 0;
  segEnVuelo = null;
}

export async function fetchSeguimiento(opts?: { forzar?: boolean }): Promise<ClienteSeguimiento[]> {
  if (opts?.forzar) invalidarSeguimiento();
  if (cacheSeg && Date.now() < cacheSegHasta) return cacheSeg;
  if (segEnVuelo) return segEnVuelo;

  segEnVuelo = (async () => {
    try {
      const lista = await calcularSeguimiento();
      cacheSeg = lista;
      cacheSegHasta = Date.now() + VIGENCIA_SEG_MS;
      return lista;
    } finally {
      segEnVuelo = null;
    }
  })();

  return segEnVuelo;
}

async function calcularSeguimiento(): Promise<ClienteSeguimiento[]> {
  const [clientes, catalogo, contactos, compartidas, boletines, contingencias, avances, convenios, accionesHechasMap] = await Promise.all([
    fetchClientes(),
    fetchCatalogo(),
    fetchContactos(),
    fetchCompartidas(),
    fetchBoletines(),
    fetchContingencias(),
    fetchAvances(),
    fetchConvenios(),
    fetchAcciones(),
  ]);

  const reglaPorCodigo = new Map<string, CatalogoCodigo>();
  for (const c of catalogo) reglaPorCodigo.set(c.codigo, c);

  return clientes
    .filter((c) => !c.archivado && !c.eliminado)
    .map((cliente) => {
      const regla = reglaPorCodigo.get(cliente.codigo);
      const diasLimite = cliente.overrideDiasLimite ?? regla?.dias_limite ?? null;
      const responsable = cliente.overrideResponsable || regla?.responsable_rol || "—";
      const salidas = parsearSalidas(regla?.salidas, cliente.codigo);
      const rolesApoyo = (() => {
        const toks: Array<string | null | undefined> = [cliente.overrideResponsable];
        if (regla) toks.push(regla.responsable_rol, regla.alterno_rol, regla.respaldo_rol, ...(regla.apoyos ? regla.apoyos.split(",") : []));
        return Array.from(new Set(toks.map((t) => (t || "").trim()).filter(Boolean)));
      })();

      const cont = contactos.get(String(cliente.id));
      const ultimaLlamada = cont?.ultima_llamada ?? null;
      const ultimoCorreo = cont?.ultimo_correo ?? null;
      const ultimoContacto = cont?.ultimo_cualquiera ?? null;

      let estado: EstadoSeguimiento = "aldia";
      let diasDesdeCiclo: number | null = null;
      let falta: Falta = null;

      if (diasLimite == null) {
        estado = "sinplazo";
      } else {
        // 👇 FASE D: qué cuenta como "atendido" lo define el catálogo (por código).
        const reqLlam = regla?.requiere_llamada ?? true;
        const reqCorr = regla?.requiere_correo ?? (cliente.codigo !== "SVT");
        const faltaLlam = reqLlam && !ultimaLlamada;
        const faltaCorr = reqCorr && !ultimoCorreo;
        if (faltaLlam && faltaCorr) { estado = "vencido"; falta = "ambos"; }
        else if (faltaLlam) { estado = "vencido"; falta = "llamada"; }
        else if (faltaCorr) { estado = "vencido"; falta = "correo"; }
        else {
          const stamps: number[] = [];
          if (reqLlam && ultimaLlamada) stamps.push(new Date(ultimaLlamada).getTime());
          if (reqCorr && ultimoCorreo) stamps.push(new Date(ultimoCorreo).getTime());
          if (stamps.length === 0 && ultimoContacto) stamps.push(new Date(ultimoContacto).getTime());
          if (stamps.length === 0) { estado = "vencido"; falta = reqLlam ? "llamada" : "correo"; }
          else {
            diasDesdeCiclo = Math.floor((Date.now() - Math.min(...stamps)) / (1000 * 60 * 60 * 24));
            estado = calcEstado(diasDesdeCiclo, diasLimite, cliente.overrideDiasAviso ?? regla?.dias_aviso ?? undefined);
          }
        }
      }

      const ultimoBoletin = boletines.get(String(cliente.id)) ?? null;
      const requiereBoletin = regla?.requiere_boletin ?? CODIGOS_BOLETIN.has(cliente.codigo);
      const faltaBoletin = requiereBoletin && (!ultimoBoletin || diasDesde(ultimoBoletin) > 7);

      const contingencia = contingencias.has(String(cliente.id));
      const ultimoAvance = avances.get(String(cliente.id)) ?? null;
      const faltaAvance = contingencia && (!ultimoAvance || diasDesde(ultimoAvance) > 7);
      const convenio = convenios.has(String(cliente.id));

      // 👇 FASE D3c: acciones del catálogo que cuentan para atendido
      const hechasMap = accionesHechasMap.get(String(cliente.id)) ?? new Map<string, string>();
      const accionesHechas: Record<string, string> = {};
      hechasMap.forEach((fecha, nombre) => { accionesHechas[nombre] = fecha; });
      // 👇 FASE F2: si el cliente tiene acciones propias, reemplazan a las del código
      const accionesEfectivas = (cliente.overrideAcciones && cliente.overrideAcciones.length > 0)
        ? cliente.overrideAcciones
        : (regla?.acciones ?? []);
      let faltaAccion: string | null = null;
      if (diasLimite != null) {
        for (const ac of accionesEfectivas) {
          if (!ac.cuenta) continue;
          const f = hechasMap.get(ac.nombre);
          if (!f || diasDesde(f) > diasLimite) { faltaAccion = ac.nombre; break; }
        }
      }
      if (faltaAccion && estado !== "sinplazo") estado = "vencido";

      // 👇 FASE G1: etiquetas que aplican según su disparador
      const etiquetas = (regla?.etiquetas ?? []).filter((e) => {
        switch (e.cuando) {
          case "siempre": return true;
          case "vencido": return estado === "vencido";
          case "porvencer": return estado === "porvencer";
          case "falta_accion": return !!faltaAccion;
          case "contingencia": return contingencia;
          default: return false;
        }
      });

      return { cliente, ultimaLlamada, ultimoCorreo, ultimoContacto, diasDesdeCiclo, diasLimite, estado, responsable, falta, faltaBoletin, contingencia, faltaAvance, convenio, salidas, acciones: accionesEfectivas, accionesHechas, faltaAccion, etiquetas, areasCompartidas: compartidas.get(String(cliente.id)) ?? [], rolesApoyo };
    });
}

// 👇 NUEVO (Mejora C): "Mi lista del día"
// Un cliente "toca hoy" si está vencido o por vencer. Se excluyen los R3 ya terminados.
export function esDelDia(it: ClienteSeguimiento): boolean {
  if (it.cliente.terminado) return false;   // los casos terminados ya no salen en el inicio
  if (it.cliente.codigo === "R3" && it.cliente.r3Seguimiento === false) return false;
  return it.estado === "vencido" || it.estado === "porvencer";
}

// Orden por prioridad: 1) riesgo legal (contingencia), 2) vencidos antes que por vencer,
// 3) el más atrasado primero.
function ordenarPrioridad(a: ClienteSeguimiento, b: ClienteSeguimiento): number {
  if (a.contingencia !== b.contingencia) return a.contingencia ? -1 : 1;
  const rank = (e: EstadoSeguimiento) => (e === "vencido" ? 0 : 1);
  if (rank(a.estado) !== rank(b.estado)) return rank(a.estado) - rank(b.estado);
  const exceso = (it: ClienteSeguimiento) => (it.diasDesdeCiclo ?? 99999) - (it.diasLimite ?? 0);
  return exceso(b) - exceso(a);
}

// Devuelve los clientes que le tocan HOY a un rol (responsable o apoyo del código).
// DGE y Super_Admin ven todos.
export function miLista(items: ClienteSeguimiento[], miRol: string | null): ClienteSeguimiento[] {
  const verTodo = miRol === "DGE" || miRol === "Super_Admin";
  return items
    .filter(esDelDia)
    .filter((it) => verTodo || (miRol != null && it.rolesApoyo.includes(miRol)))
    .sort(ordenarPrioridad);
}

export async function cambiarCodigo(
  clienteId: string,
  nombreCliente: string,
  codigoActual: string,
  nuevoCodigo: Codigo,
  autor: string,
): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase
    .from("clientes")
    .update({ codigo: nuevoCodigo })
    .eq("id", clienteId);
  invalidarClientes();
  if (error) return { ok: false, error: error.message };

  try {
    await avisarEvento({
      tipo: "seguimiento",
      accion: "cambio_codigo",
      titulo: `🔄 ${nombreCliente}: ${codigoActual} → ${nuevoCodigo}`,
      detalle: `Cambio de código por ${autor}`,
      autor,
      modulo: "seguimiento",
      refId: clienteId,
      icono: "🔄",
      meta: { cliente_id: clienteId, de: codigoActual, a: nuevoCodigo },
    });
  } catch {}

  return { ok: true };
}

export async function compartirCliente(
  clienteId: string,
  nombreCliente: string,
  areas: string[],
  autor: string,
): Promise<{ ok: boolean; error?: string }> {
  const limpias = Array.from(new Set(areas.map((a) => a.trim()).filter(Boolean)));
  const { error } = await supabase
    .from("clientes")
    .update({ areas_compartidas: limpias })
    .eq("id", clienteId);
  invalidarClientes();
  if (error) return { ok: false, error: error.message };
  invalidarClientes();
  invalidarSeguimiento();

  try {
    await avisarEvento({
      tipo: "seguimiento",
      accion: "compartir_cliente",
      titulo: `🔗 ${nombreCliente}: compartido con ${limpias.length ? limpias.join(", ") : "(nadie)"}`,
      detalle: `Compartición de áreas por ${autor}`,
      autor,
      modulo: "seguimiento",
      refId: clienteId,
      icono: "🔗",
      meta: { cliente_id: clienteId, areas: limpias },
    });
  } catch {}

  return { ok: true };
}

export async function registrarContacto(
  clienteId: string,
  clienteNombre: string,
  tipo: "llamada" | "correo" | "whatsapp",
  detalle: string,
  autor: string,
): Promise<{ ok: boolean; error?: string }> {
  const r = await registrarComunicacion({ clienteId, clienteNombre, tipo, detalle, autor });
  if (!r) return { ok: false, error: "No se pudo registrar la comunicación." };
  invalidarSeguimiento();
  return { ok: true };
}

// 👇 FASE D3: registra que se hizo una acción del catálogo para un cliente (con fecha + quién).
export async function registrarAccion(clienteId: string, accion: string, por: string): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("acciones_cliente").insert({ cliente_id: clienteId, accion, por });
  if (error) return { ok: false, error: error.message };
  invalidarSeguimiento();
  return { ok: true };
}

// 👇 FASE G2: indicadores (contadores) configurables del tablero
export type Indicador = { id: string; nombre: string; condicion: string; codigo: string | null; color: string; orden: number; avisar: boolean; avisar_min: number; avisado_fecha: string | null };

export async function fetchIndicadores(): Promise<Indicador[]> {
  const { data, error } = await supabase.from("indicadores_tablero").select("*").order("orden", { ascending: true });
  if (error || !data) return [];
  return data as Indicador[];
}
export async function crearIndicador(i: { nombre: string; condicion: string; codigo: string | null; color: string; orden: number; avisar: boolean; avisar_min: number }): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("indicadores_tablero").insert(i);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}
export async function borrarIndicador(id: string): Promise<boolean> {
  const { error } = await supabase.from("indicadores_tablero").delete().eq("id", id);
  return !error;
}

// 👇 FASE G3: marca que un indicador ya avisó hoy (para no repetir)
export async function marcarAvisado(id: string): Promise<void> {
  const hoy = new Date().toISOString().slice(0, 10);
  await supabase.from("indicadores_tablero").update({ avisado_fecha: hoy }).eq("id", id);
}
