// ===================================================================
// Mi Agenda  →  src/data/tareas.ts
// Tareas personales: citas, correos por enviar, tareas y llamadas.
// ===================================================================
import { supabase } from "../lib/supabase";
import { crearEventoEspejoJF, actualizarEventoEspejoJF, esAreaJuridico, buscarClienteJF, crearClienteJFDesdeJC } from "../lib/justiciaFacil";

export type TipoTarea = "tarea" | "llamada" | "correo" | "cita";
export type EstadoTarea = "pendiente" | "hecha";

export type Tarea = {
  id: string;
  autorEmail: string;
  autorNombre: string | null;
  tipo: TipoTarea;
  titulo: string;
  detalle: string | null;
  clienteId: string | null;
  clienteNombre: string | null;
  expediente: string | null;
  aQuien: string | null;
  fecha: string | null;
  estado: EstadoTarea;
  createdAt: string;
};

function mapTarea(r: any): Tarea {
  return {
    id: String(r.id),
    autorEmail: r.autor_email ?? "",
    autorNombre: r.autor_nombre ?? null,
    tipo: (r.tipo as TipoTarea) ?? "tarea",
    titulo: r.titulo ?? "",
    detalle: r.detalle ?? null,
    clienteId: r.cliente_id ?? null,
    clienteNombre: r.cliente_nombre ?? null,
    expediente: r.expediente ?? null,
    aQuien: r.a_quien ?? null,
    fecha: r.fecha ?? null,
    estado: (r.estado as EstadoTarea) ?? "pendiente",
    createdAt: r.created_at ?? "",
  };
}

// Trae las tareas pendientes de una persona. Si la tabla no existe, regresa [].
export async function fetchTareas(autorEmail: string): Promise<Tarea[]> {
  try {
    const { data, error } = await supabase
      .from("tareas")
      .select("*")
      .eq("autor_email", autorEmail)
      .eq("estado", "pendiente")
      .order("fecha", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });
    if (error || !data) return [];
    return (data as any[]).map(mapTarea);
  } catch {
    return [];
  }
}

// Caché chiquita para no consultar el área del colaborador en cada tarea.
const cacheArea = new Map<string, string | null>();
async function areaDeCorreo(correo: string): Promise<string | null> {
  const k = (correo || "").trim().toLowerCase();
  if (!k) return null;
  if (cacheArea.has(k)) return cacheArea.get(k)!;
  const { data } = await supabase.from("colaboradores").select("area").eq("correo", correo).maybeSingle();
  const area = (data as any)?.area ?? null;
  cacheArea.set(k, area);
  return area;
}

export async function agregarTarea(t: {
  autorEmail: string;
  autorNombre?: string;
  tipo: TipoTarea;
  titulo: string;
  detalle?: string;
  fecha?: string | null;
  aQuien?: string;
  clienteId?: string;
  clienteNombre?: string;
  /** Número de expediente/garantía al que pertenece esta tarea (para clientes con más de una garantía). */
  expediente?: string;
  /** Si esta tarea viene de resolver una solicitud creada desde JusticiaFácil, aquí va el id de ese evento (se actualiza en vez de duplicar). */
  jfEventoId?: string;
  /** Evita el espejo hacia JusticiaFácil (para casos ya cubiertos por otro flujo). */
  omitirEspejoJF?: boolean;
}): Promise<{ ok: boolean; error?: string; id?: string }> {
  const { data, error } = await supabase.from("tareas").insert({
    autor_email: t.autorEmail,
    autor_nombre: t.autorNombre ?? null,
    tipo: t.tipo,
    titulo: t.titulo,
    detalle: t.detalle ?? null,
    fecha: t.fecha ?? null,
    a_quien: t.aQuien ?? null,
    cliente_id: t.clienteId ?? null,
    cliente_nombre: t.clienteNombre ?? null,
    expediente: t.expediente ?? null,
    estado: "pendiente",
  }).select().single();
  if (error) return { ok: false, error: error.message };
  const nuevaId = (data as any)?.id as string | undefined;

  // ---- Espejo hacia JusticiaFácil: solo si a quien se le asignó es del área jurídico ----
  if (!t.omitirEspejoJF && nuevaId) {
    try {
      const area = await areaDeCorreo(t.autorEmail);
      if (esAreaJuridico(area)) {
        // Si la tarea trae cliente y ese cliente todavía no existe en el módulo de
        // Clientes de JusticiaFácil, se da de alta ahí mismo (sin pedir confirmación),
        // con toda la info de JurisConecta, marcado como pendiente de validar.
        if (t.clienteId && t.clienteNombre) {
          const yaExiste = await buscarClienteJF(t.clienteNombre);
          if (!yaExiste) {
            const { data: cli } = await supabase.from("clientes").select("*").eq("id", t.clienteId).maybeSingle();
            if (cli) {
              await crearClienteJFDesdeJC({
                id: String((cli as any).id), nombre: (cli as any).nombre || t.clienteNombre,
                domicilio: (cli as any).domicilio || null, telefono: (cli as any).telefono || null,
                telefono2: (cli as any).telefono2 || null, whatsapp: (cli as any).whatsapp || null,
                email: (cli as any).email || null, curpRfc: (cli as any).curp_rfc || null,
                codigo: (cli as any).codigo || null, area: (cli as any).area || null, estatus: (cli as any).estatus || null,
              });
            }
          }
        }
        const datosEspejo = { tipo: t.tipo, titulo: t.titulo, detalle: t.detalle || null, fecha: t.fecha || null, asignadoCorreo: t.autorEmail, clienteNombre: t.clienteNombre || null, clienteId: t.clienteId || null, jcTareaId: nuevaId };
        if (t.jfEventoId) {
          await actualizarEventoEspejoJF(t.jfEventoId, { cliente_estado: t.clienteId ? "vinculado" : null, cliente_jc_id: t.clienteId || null, jc_tarea_id: nuevaId });
          await supabase.from("tareas").update({ jf_evento_id: t.jfEventoId }).eq("id", nuevaId);
        } else {
          const espejo = await crearEventoEspejoJF(datosEspejo);
          if (espejo.ok && espejo.id) await supabase.from("tareas").update({ jf_evento_id: espejo.id }).eq("id", nuevaId);
        }
      }
    } catch { /* si falla el espejo, la tarea en JurisConecta ya quedó creada de todas formas */ }
  }

  return { ok: true, id: nuevaId };
}

export async function marcarTarea(id: string, estado: EstadoTarea): Promise<{ ok: boolean; error?: string }> {
  const { data, error } = await supabase.from("tareas").update({ estado }).eq("id", id).select("jf_evento_id").maybeSingle();
  if (error) return { ok: false, error: error.message };
  const jfEventoId = (data as any)?.jf_evento_id as string | null | undefined;
  if (jfEventoId) actualizarEventoEspejoJF(jfEventoId, { estado: estado === "hecha" ? "hecho" : "pendiente" }).catch(() => {});
  return { ok: true };
}

export async function borrarTarea(id: string): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("tareas").delete().eq("id", id);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

// Trae TODAS las tareas (pendientes y hechas) ligadas a un cliente.
export async function fetchTareasCliente(clienteId: string): Promise<Tarea[]> {
  if (!clienteId) return [];
  try {
    const { data, error } = await supabase
      .from("tareas")
      .select("*")
      .eq("cliente_id", clienteId)
      .order("estado", { ascending: true })
      .order("fecha", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });
    if (error || !data) return [];
    return (data as any[]).map(mapTarea);
  } catch {
    return [];
  }
}

// Trae tareas pendientes de VARIAS personas (jerarquía).
// emails = lista de correos a ver. Si emails === null → TODAS (RAC / Dirección).
export async function fetchTareasVisibles(emails: string[] | null): Promise<Tarea[]> {
  try {
    let q = supabase.from("tareas").select("*").eq("estado", "pendiente");
    if (emails !== null) {
      if (emails.length === 0) return [];
      q = q.in("autor_email", emails);
    }
    const { data, error } = await q
      .order("fecha", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });
    if (error || !data) return [];
    return (data as any[]).map(mapTarea);
  } catch {
    return [];
  }
}
