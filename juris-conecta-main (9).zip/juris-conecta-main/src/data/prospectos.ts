// CRM Prospectos Comercial · capa de datos (Fase 2)
// Leads del área comercial + sus "toques" (llamadas de calidad).
import { supabase } from "../lib/supabase";

// ----- Catálogos -----
export const ORIGENES = ["Facebook", "Instagram", "Referido", "Campaña", "Chatwoot", "Otro"] as const;
export type Origen = (typeof ORIGENES)[number];

export const FASES = ["Nuevo", "Contactado", "Cita", "Perfilado", "Apartado", "Contrato", "Cliente", "Frío", "Perdido"] as const;
export type Fase = (typeof FASES)[number];

// El flujo del PROSPECTO solo llega hasta Apartado. Al apartar se convierte en Cliente
// (eso ya no es fase del prospecto, es la conversión a CRM Clientes UAC).
export const FASES_FUNNEL: Fase[] = ["Nuevo", "Contactado", "Cita", "Perfilado", "Apartado"];
// Lo que se ofrece en los selectores: el embudo + Frío/Perdido. "Cliente" solo por el botón Convertir.
export const FASES_SELECT: Fase[] = [...FASES_FUNNEL, "Frío", "Perdido"];

// ----- Catálogos de segmentación -----
export const NECESIDADES = ["Recuperación", "Regularización", "Compra", "Venta"] as const;
export const FORMAS_PAGO = ["Contado", "Parcialidades", "Crédito"] as const;
export const TIPOS_ACTIVO = ["Contingencia", "Entrega inmediata"] as const;
export const CREDITO_TIPOS = ["Bancario", "INFONAVIT", "FOVISSSTE", "Cofinanciado"] as const;
export const TAMANOS_CASA = ["Chica", "Mediana", "Grande"] as const;
export const PRESUPUESTOS = ["<$500K", "$500K–$1M", "$1M–$2M", "+$2M"] as const;
export const ZONAS = ["GDL", "Culiacán", "Mazatlán", "La Paz"] as const;
export const ORIGENES_ACTIVO = ["Banco", "INFONAVIT", "FOVISSSTE", "Administradora"] as const;

// ----- Bolsas (grupos que se arman solos por los campos) -----
export type Bolsa = "contado_contingencia" | "credito_entrega" | "recuperacion_banco" | "infonavit" | "otros";
export const BOLSAS: { clave: Bolsa; etiqueta: string; color: string }[] = [
  { clave: "contado_contingencia", etiqueta: "🟦 Contado · Contingencia", color: "blue" },
  { clave: "credito_entrega", etiqueta: "🟩 Crédito · Entrega inmediata", color: "emerald" },
  { clave: "recuperacion_banco", etiqueta: "🟧 Recuperación bancaria", color: "amber" },
  { clave: "infonavit", etiqueta: "🟥 INFONAVIT", color: "rose" },
  { clave: "otros", etiqueta: "⬜ Otros", color: "slate" },
];

// A qué bolsa cae un prospecto según sus campos.
export function bolsaDe(p: { formaPago?: string; tipoActivo?: string; necesidad?: string; creditoTipo?: string; origenActivo?: string }): Bolsa {
  if (p.creditoTipo === "INFONAVIT" || p.origenActivo === "INFONAVIT") return "infonavit";
  if (p.formaPago === "Contado" && p.tipoActivo === "Contingencia") return "contado_contingencia";
  if (p.formaPago === "Crédito" && p.tipoActivo === "Entrega inmediata") return "credito_entrega";
  if (p.necesidad === "Recuperación" && p.origenActivo === "Banco") return "recuperacion_banco";
  return "otros";
}

export const TIPOS_TOQUE = ["llamada", "whatsapp", "correo", "cita"] as const;
export type TipoToque = (typeof TIPOS_TOQUE)[number];

// ----- Tipos -----
export type Prospecto = {
  id: string;
  nombre: string;
  telefono: string;
  email: string;
  origen: Origen;
  asesor: string;
  sucursal: string;
  fase: Fase;
  fechaLead: string;        // YYYY-MM-DD
  activoInteres: string;
  busca: string;
  presupuesto: string;
  urgencia: string;
  apto: boolean | null;
  proximoPaso: string;
  fechaProximo: string | null;
  notas: string;
  registradoPor: string;
  createdAt: string;
  // Apartado + conversión a cliente
  fechaFirma: string | null;
  montoContrato: string;
  montoApartado: string;
  recibo: { nombre: string; link: string } | null;
  convertido: boolean;
  clienteId: string;
  // Segmentación
  folio: string;
  necesidad: string;
  formaPago: string;
  tipoActivo: string;
  creditoTipo: string;
  tamanoCasa: string;
  presupuestoRango: string;
  zona: string;
  colonia: string;
  origenActivo: string;
};

export type Toque = {
  id: string;
  prospectoId: string;
  fecha: string;
  tipo: TipoToque;
  resultado: string;
  calidad: boolean;
  perfilado: string;
  siguientePaso: string;
  fechaSiguiente: string | null;
  autor: string;
  createdAt: string;
};

// ----- Ritmo de toques (la tabla de Paola: cada cuándo se vuelve a tocar) -----
export const RITMO: Record<Fase, { dias: number; nota: string }> = {
  Nuevo:      { dias: 0, nota: "Llamar HOY (mismo día, ideal < 1 hora). El que llama primero, gana." },
  Contactado: { dias: 2, nota: "Insistir cada 2–3 días hasta agendar cita." },
  Cita:       { dias: 1, nota: "Recordatorio 1 día antes y el mismo día (que no se caiga)." },
  Perfilado:  { dias: 2, nota: "Cerrar el siguiente paso: cita o visita con fecha." },
  Apartado:   { dias: 7, nota: "Seguimiento semanal hasta firmar/pagar." },
  Contrato:   { dias: 3, nota: "Acompañar firma y validación (DIL)." },
  Cliente:    { dias: 0, nota: "Convertido. Pasa a CRM Clientes (UAC)." },
  Frío:       { dias: 15, nota: "Reactivar a los 15 y 30 días; luego se cierra." },
  Perdido:    { dias: 0, nota: "Cerrado." },
};

// Sugiere el próximo toque (fecha + nota) según la fase actual.
export function sugerirProximo(fase: Fase, desde: Date = new Date()): { fecha: string; nota: string } {
  const r = RITMO[fase] ?? RITMO.Nuevo;
  const d = new Date(desde);
  d.setDate(d.getDate() + r.dias);
  return { fecha: d.toISOString().slice(0, 10), nota: r.nota };
}

// ¿Un lead nuevo lleva demasiado sin tocarse? (regla de oro: lead nuevo = mismo día)
export function leadSinContactar(p: Prospecto): boolean {
  return p.fase === "Nuevo" && p.fechaLead <= new Date().toISOString().slice(0, 10);
}

// ----- Mapeos fila <-> objeto -----
function mapP(r: any): Prospecto {
  return {
    id: r.id,
    nombre: r.nombre || "",
    telefono: r.telefono || "",
    email: r.email || "",
    origen: (ORIGENES as readonly string[]).includes(r.origen) ? r.origen : "Otro",
    asesor: r.asesor || "",
    sucursal: r.sucursal || "",
    fase: (FASES as readonly string[]).includes(r.fase) ? r.fase : "Nuevo",
    fechaLead: r.fecha_lead || "",
    activoInteres: r.activo_interes || "",
    busca: r.busca || "",
    presupuesto: r.presupuesto || "",
    urgencia: r.urgencia || "",
    apto: typeof r.apto === "boolean" ? r.apto : null,
    proximoPaso: r.proximo_paso || "",
    fechaProximo: r.fecha_proximo || null,
    notas: r.notas || "",
    registradoPor: r.registrado_por || "",
    createdAt: r.created_at || "",
    fechaFirma: r.fecha_firma || null,
    montoContrato: r.monto_contrato || "",
    montoApartado: r.monto_apartado || "",
    recibo: r.recibo && typeof r.recibo === "object" ? r.recibo : null,
    convertido: !!r.convertido,
    clienteId: r.cliente_id || "",
    folio: r.folio || "",
    necesidad: r.necesidad || "",
    formaPago: r.forma_pago || "",
    tipoActivo: r.tipo_activo || "",
    creditoTipo: r.credito_tipo || "",
    tamanoCasa: r.tamano_casa || "",
    presupuestoRango: r.presupuesto_rango || "",
    zona: r.zona || "",
    colonia: r.colonia || "",
    origenActivo: r.origen_activo || "",
  };
}

function mapT(r: any): Toque {
  return {
    id: r.id,
    prospectoId: r.prospecto_id,
    fecha: r.fecha || "",
    tipo: (TIPOS_TOQUE as readonly string[]).includes(r.tipo) ? r.tipo : "llamada",
    resultado: r.resultado || "",
    calidad: !!r.calidad,
    perfilado: r.perfilado || "",
    siguientePaso: r.siguiente_paso || "",
    fechaSiguiente: r.fecha_siguiente || null,
    autor: r.autor || "",
    createdAt: r.created_at || "",
  };
}

// ----- Prospectos: leer / crear / actualizar / mover / borrar -----
export async function fetchProspectos(): Promise<Prospecto[]> {
  const { data, error } = await supabase
    .from("prospectos")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5000);
  if (error || !data) return [];
  return data.map(mapP);
}

// Folio PROS-AÑO-#### (corrido por año).
export async function generarFolioProspecto(): Promise<string> {
  const anio = new Date().getFullYear();
  const { count } = await supabase
    .from("prospectos")
    .select("*", { count: "exact", head: true })
    .gte("created_at", `${anio}-01-01`);
  return `PROS-${anio}-${String((count || 0) + 1).padStart(4, "0")}`;
}

export async function agregarProspecto(p: {
  nombre: string; telefono?: string; email?: string; origen?: Origen; asesor?: string; sucursal?: string;
  activoInteres?: string; notas?: string; registradoPor?: string | null;
  necesidad?: string; formaPago?: string; tipoActivo?: string; creditoTipo?: string;
  tamanoCasa?: string; presupuestoRango?: string; zona?: string; colonia?: string; origenActivo?: string;
}): Promise<Prospecto | null> {
  const sug = sugerirProximo("Nuevo");
  const folio = await generarFolioProspecto();
  const { data, error } = await supabase
    .from("prospectos")
    .insert({
      nombre: p.nombre,
      telefono: p.telefono || null,
      email: p.email || null,
      origen: p.origen || "Otro",
      asesor: p.asesor || null,
      sucursal: p.sucursal || null,
      fase: "Nuevo",
      activo_interes: p.activoInteres || null,
      notas: p.notas || null,
      registrado_por: p.registradoPor || null,
      proximo_paso: sug.nota,
      fecha_proximo: sug.fecha,
      folio,
      necesidad: p.necesidad || null,
      forma_pago: p.formaPago || null,
      tipo_activo: p.tipoActivo || null,
      credito_tipo: p.creditoTipo || null,
      tamano_casa: p.tamanoCasa || null,
      presupuesto_rango: p.presupuestoRango || null,
      zona: p.zona || null,
      colonia: p.colonia || null,
      origen_activo: p.origenActivo || null,
    })
    .select("*")
    .single();
  if (error || !data) return null;
  return mapP(data);
}

export type CamposProspecto = Partial<{
  nombre: string; telefono: string; email: string; origen: Origen; asesor: string; sucursal: string;
  activoInteres: string; busca: string; presupuesto: string; urgencia: string;
  apto: boolean | null; notas: string;
  necesidad: string; formaPago: string; tipoActivo: string; creditoTipo: string;
  tamanoCasa: string; presupuestoRango: string; zona: string; colonia: string; origenActivo: string;
}>;

export async function actualizarProspecto(id: string, campos: CamposProspecto): Promise<boolean> {
  const fila: any = {};
  if (campos.nombre !== undefined) fila.nombre = campos.nombre;
  if (campos.telefono !== undefined) fila.telefono = campos.telefono;
  if (campos.email !== undefined) fila.email = campos.email;
  if (campos.origen !== undefined) fila.origen = campos.origen;
  if (campos.asesor !== undefined) fila.asesor = campos.asesor;
  if (campos.sucursal !== undefined) fila.sucursal = campos.sucursal;
  if (campos.activoInteres !== undefined) fila.activo_interes = campos.activoInteres;
  if (campos.busca !== undefined) fila.busca = campos.busca;
  if (campos.presupuesto !== undefined) fila.presupuesto = campos.presupuesto;
  if (campos.urgencia !== undefined) fila.urgencia = campos.urgencia;
  if (campos.apto !== undefined) fila.apto = campos.apto;
  if (campos.notas !== undefined) fila.notas = campos.notas;
  if (campos.necesidad !== undefined) fila.necesidad = campos.necesidad;
  if (campos.formaPago !== undefined) fila.forma_pago = campos.formaPago;
  if (campos.tipoActivo !== undefined) fila.tipo_activo = campos.tipoActivo;
  if (campos.creditoTipo !== undefined) fila.credito_tipo = campos.creditoTipo;
  if (campos.tamanoCasa !== undefined) fila.tamano_casa = campos.tamanoCasa;
  if (campos.presupuestoRango !== undefined) fila.presupuesto_rango = campos.presupuestoRango;
  if (campos.zona !== undefined) fila.zona = campos.zona;
  if (campos.colonia !== undefined) fila.colonia = campos.colonia;
  if (campos.origenActivo !== undefined) fila.origen_activo = campos.origenActivo;
  if (Object.keys(fila).length === 0) return true;
  const { error } = await supabase.from("prospectos").update(fila).eq("id", id);
  return !error;
}

// Asigna (o reasigna) el asesor dueño del lead.
export async function asignarAsesor(id: string, asesor: string): Promise<boolean> {
  const { error } = await supabase.from("prospectos").update({ asesor }).eq("id", id);
  return !error;
}

// Mueve de fase y recalcula el próximo toque según el ritmo.
export async function moverFase(id: string, fase: Fase): Promise<boolean> {
  const sug = sugerirProximo(fase);
  const { error } = await supabase
    .from("prospectos")
    .update({ fase, proximo_paso: sug.nota, fecha_proximo: sug.fecha })
    .eq("id", id);
  return !error;
}

export async function borrarProspecto(id: string): Promise<boolean> {
  const { error } = await supabase.from("prospectos").delete().eq("id", id);
  return !error;
}

// ----- Toques (llamadas de calidad) -----
export async function fetchToques(prospectoId: string): Promise<Toque[]> {
  const { data, error } = await supabase
    .from("prospecto_toques")
    .select("*")
    .eq("prospecto_id", prospectoId)
    .order("fecha", { ascending: false });
  if (error || !data) return [];
  return data.map(mapT);
}

// Todos los toques (para KPIs por periodo/asesor).
export async function fetchTodosToques(): Promise<Toque[]> {
  const { data, error } = await supabase
    .from("prospecto_toques")
    .select("*")
    .order("fecha", { ascending: false })
    .limit(10000);
  if (error || !data) return [];
  return data.map(mapT);
}

export async function agregarToque(t: {
  prospectoId: string; tipo?: TipoToque; resultado?: string; calidad?: boolean;
  perfilado?: string; siguientePaso?: string; fechaSiguiente?: string | null; autor?: string | null;
}): Promise<Toque | null> {
  const { data, error } = await supabase
    .from("prospecto_toques")
    .insert({
      prospecto_id: t.prospectoId,
      tipo: t.tipo || "llamada",
      resultado: t.resultado || null,
      calidad: t.calidad ?? false,
      perfilado: t.perfilado || null,
      siguiente_paso: t.siguientePaso || null,
      fecha_siguiente: t.fechaSiguiente || null,
      autor: t.autor || null,
    })
    .select("*")
    .single();
  if (error || !data) return null;
  // Si el toque dejó un siguiente paso con fecha, lo reflejamos en el prospecto.
  if (t.siguientePaso || t.fechaSiguiente) {
    await supabase.from("prospectos")
      .update({ proximo_paso: t.siguientePaso || null, fecha_proximo: t.fechaSiguiente || null })
      .eq("id", t.prospectoId);
  }
  return mapT(data);
}

// ----- Apartado + conversión a Cliente (CRM Clientes UAC) -----
import { registrarCliente, actualizarCliente, type Cliente } from "./clientes";

// Guarda los datos del apartado (sin convertir todavía).
export async function guardarApartado(id: string, d: {
  fechaFirma?: string | null; montoContrato?: string; montoApartado?: string;
  recibo?: { nombre: string; link: string } | null;
}): Promise<boolean> {
  const fila: any = {};
  if (d.fechaFirma !== undefined) fila.fecha_firma = d.fechaFirma || null;
  if (d.montoContrato !== undefined) fila.monto_contrato = d.montoContrato;
  if (d.montoApartado !== undefined) fila.monto_apartado = d.montoApartado;
  if (d.recibo !== undefined) fila.recibo = d.recibo;
  if (Object.keys(fila).length === 0) return true;
  const { error } = await supabase.from("prospectos").update(fila).eq("id", id);
  return !error;
}

// Convierte el prospecto en CLIENTE: lo crea en CRM Clientes (UAC) y marca el prospecto.
export async function convertirProspectoACliente(p: Prospecto, d: {
  fechaFirma?: string | null; montoContrato?: string; montoApartado?: string;
}): Promise<{ ok: boolean; cliente?: Cliente; error?: string }> {
  if (p.convertido && p.clienteId) return { ok: false, error: "Este prospecto ya fue convertido." };
  try {
    const cliente = await registrarCliente({
      nombre: p.nombre,
      telefono: p.telefono || "",
      whatsapp: p.telefono || "",
      comoConocio: p.origen,
      garantia: p.activoInteres || "",
      direccionGarantia: p.activoInteres || "",
      sucursal: p.sucursal || "",
      fechaFirma: d.fechaFirma || undefined,
      estatus: "apartado",
      codigo: "SVT",
      area: "Comercial",
      tipo: "cliente",
      expediente: "",
    });
    // Pasa los montos del apartado/contrato a la ficha del cliente.
    await actualizarCliente(String(cliente.id), {
      montoApartado: d.montoApartado || "",
      valorFirma: d.montoContrato || "",
      fechaFirma: d.fechaFirma || "",
    });
    // Marca el prospecto como convertido y lo deja ligado al cliente.
    await supabase.from("prospectos").update({
      convertido: true,
      cliente_id: String(cliente.id),
      fase: "Cliente",
      fecha_firma: d.fechaFirma || null,
      monto_contrato: d.montoContrato || null,
      monto_apartado: d.montoApartado || null,
    }).eq("id", p.id);
    return { ok: true, cliente };
  } catch (e: any) {
    return { ok: false, error: e?.message || "No se pudo convertir." };
  }
}
