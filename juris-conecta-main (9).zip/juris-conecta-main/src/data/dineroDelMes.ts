// Dinero del mes — capa de datos.
//
// Aquí se registra el dinero REAL disponible para devoluciones cada mes, se
// reparte entre las dos modalidades, y se arma la cola de a quién le toca.
// Antes la bolsa se ADIVINABA: se tomaba el 15% de las ventas del mes. Eso se
// conserva como estimado para sugerir, pero manda el monto que registra la DGE.
//
// Todo lo que aquí se calcula sale de `parametros_devolucion`. Ningún número
// está escrito en este archivo.
import { supabase } from "../lib/supabase";
import { P } from "./parametrosDevolucion";

export interface BolsaMes {
  id: string | null;
  anioMes: string;
  montoRegistrado: number;
  origen: string;
  nota: string | null;
  registradoPor: string | null;
  cerrado: boolean;
  cerradoPor: string | null;
}

export interface RenglonCola {
  clienteId: string;
  nombre: string;
  modalidad: "rdc" | "convenio_simple";
  turno: number;
  montoAsignado: number;
  concepto: string;
  fechaMaxima: string | null;
  porPrioridad: boolean;
  motivoPrioridad?: string;
}

export interface RepartoMes {
  disponibleM1: number;
  disponibleM2: number;
  asignadosM1: RenglonCola[];
  asignadosM2: RenglonCola[];
  sobranteM1: number;
  sobranteM2: number;
  fuera: RenglonCola[];
  topePrioridad: number;
  /** Convenios cuya fecha máxima cae este mes y NO alcanzan a pagarse. */
  enRiesgo: RenglonCola[];
  faltanteParaRiesgo: number;
}

/** El mes en formato "2026-09", que es como se guarda. */
export function mesActual(): string {
  return new Date().toISOString().slice(0, 7);
}

/** Estimado por ventas — solo para sugerir un monto al registrar. */
export async function estimadoPorVentas(anioMes: string): Promise<number> {
  const inicio = `${anioMes}-01`;
  const [a, m] = anioMes.split("-").map(Number);
  const sig = new Date(a, m, 1).toISOString().slice(0, 10);
  const { data } = await supabase
    .from("clientes").select("valor_firma")
    .gte("fecha_conversion", inicio).lt("fecha_conversion", sig);
  const ventas = (data || []).reduce((s, c) => {
    const n = Number(String((c as { valor_firma: unknown }).valor_firma || "0").replace(/[^0-9.]/g, ""));
    return s + (Number.isFinite(n) ? n : 0);
  }, 0);
  return Math.round(ventas * P().pctBolsaVentas);
}

export async function obtenerBolsaMes(anioMes: string): Promise<BolsaMes | null> {
  const { data } = await supabase
    .from("bolsa_devolucion_mes").select("*").eq("anio_mes", anioMes).maybeSingle();
  if (!data) return null;
  return {
    id: String(data.id),
    anioMes: String(data.anio_mes),
    montoRegistrado: Number(data.monto_registrado) || 0,
    origen: String(data.origen || "ventas"),
    nota: (data.nota as string) ?? null,
    registradoPor: (data.registrado_por as string) ?? null,
    cerrado: !!data.cerrado,
    cerradoPor: (data.cerrado_por as string) ?? null,
  };
}

export async function guardarBolsaMes(
  anioMes: string, monto: number, origen: string, nota: string, quien: string,
): Promise<boolean> {
  const { error } = await supabase.from("bolsa_devolucion_mes").upsert({
    anio_mes: anioMes, monto_registrado: monto, origen, nota: nota || null,
    registrado_por: quien, registrado_en: new Date().toISOString(),
  }, { onConflict: "anio_mes" });
  return !error;
}

/**
 * Arma el reparto del mes. NO guarda nada: es la propuesta que se le muestra
 * a la DGE para que la revise y decida antes de confirmar.
 *
 * El orden es FIFO por fecha de solicitud — el más antiguo primero — y se
 * reparte hasta que se acaba el dinero de cada mitad.
 */
export async function calcularRepartoMes(anioMes: string, montoRegistrado: number): Promise<RepartoMes> {
  const p = P();
  const disponibleM1 = Math.round(montoRegistrado * p.pctRepartoM1);
  const disponibleM2 = montoRegistrado - disponibleM1;
  const topePrioridad = Math.round(montoRegistrado * p.pctTopePrioridad);

  const { data } = await supabase
    .from("compensacion_devolucion")
    .select("cliente_id, modalidad, capital, fecha_solicitud_dev, fecha_maxima_liquidacion, estado")
    .not("folio", "is", null)
    .order("fecha_solicitud_dev", { ascending: true });

  const filas = (data || []) as Record<string, unknown>[];
  const ids = filas.map((f) => String(f.cliente_id));
  const { data: cls } = await supabase.from("clientes").select("id, nombre").in("id", ids);
  const nombrePorId = new Map((cls || []).map((c) => [String((c as { id: unknown }).id), String((c as { nombre: unknown }).nombre || "")]));

  // Lo ya abonado, para saber cuánto le falta a cada quien.
  const { data: abs } = await supabase.from("abonos_devolucion").select("cliente_id, monto").in("cliente_id", ids);
  const abonadoPorId = new Map<string, number>();
  for (const a of (abs || []) as Record<string, unknown>[]) {
    const k = String(a.cliente_id);
    abonadoPorId.set(k, (abonadoPorId.get(k) || 0) + (Number(a.monto) || 0));
  }

  const cola: RenglonCola[] = filas.map((f, i) => {
    const id = String(f.cliente_id);
    const capital = Number(f.capital) || 0;
    const restante = Math.max(0, capital - (abonadoPorId.get(id) || 0));
    // 👇 Modalidad 1 es ÚNICAMENTE "rdc". Todo lo demás —"convenio_simple" y
    // también "rd", que es el código de devolución sin compensación— va a
    // Modalidad 2. Antes cualquier valor distinto de "convenio_simple" caía
    // en Modalidad 1, y los 6 registros con "rd" se contaban del lado
    // equivocado.
    const modalidad = (f.modalidad === "rdc" ? "rdc" : "convenio_simple") as RenglonCola["modalidad"];
    return {
      clienteId: id,
      nombre: nombrePorId.get(id) || `Cliente ${id}`,
      modalidad,
      turno: i + 1,
      montoAsignado: restante,
      concepto: modalidad === "rdc" ? "capital / compensación" : "capital",
      fechaMaxima: (f.fecha_maxima_liquidacion as string) ?? null,
      porPrioridad: false,
    };
  }).filter((r) => r.montoAsignado > 0);

  // Se sirve por turno hasta agotar cada mitad. Al que no le alcanza completo
  // se le da lo que queda — un abono parcial es mejor que ninguno.
  function servir(lista: RenglonCola[], disponible: number) {
    const dentro: RenglonCola[] = [];
    const fuera: RenglonCola[] = [];
    let resto = disponible;
    for (const r of lista) {
      if (resto <= 0) { fuera.push(r); continue; }
      const da = Math.min(resto, r.montoAsignado);
      dentro.push({ ...r, montoAsignado: da });
      resto -= da;
    }
    return { dentro, fuera, resto };
  }

  const colaM1 = cola.filter((r) => r.modalidad === "rdc");
  const colaM2 = cola.filter((r) => r.modalidad === "convenio_simple");

  let m1 = servir(colaM1, disponibleM1);
  let m2 = servir(colaM2, disponibleM2);

  // 👇 El convenio dice que el dinero se reparte por mitad entre las dos
  // modalidades. Pero si de un lado YA NO QUEDA NADIE a quien pagarle, esa
  // mitad no se guarda: pasa a la otra. Hoy nadie ha elegido Modalidad 1, así
  // que sin esto la mitad del dinero se quedaría parada cada mes.
  //
  // Ojo: el traspaso solo ocurre cuando el lado que cede quedó COMPLETAMENTE
  // servido, sin nadie esperando. Mientras haya fila de ese lado, su mitad se
  // respeta — que es justo lo que promete el convenio.
  if (m1.resto > 0 && m1.fuera.length === 0 && m2.fuera.length > 0) {
    m2 = servir(colaM2, disponibleM2 + m1.resto);
    m1 = { ...m1, resto: 0 };
  } else if (m2.resto > 0 && m2.fuera.length === 0 && m1.fuera.length > 0) {
    m1 = servir(colaM1, disponibleM1 + m2.resto);
    m2 = { ...m2, resto: 0 };
  }

  const fuera = [...m1.fuera, ...m2.fuera].sort((a, b) => a.turno - b.turno);

  // Aviso: de los que quedaron fuera, quiénes ya tienen fecha máxima vencida
  // o que vence este mes. Esos son incumplimiento, no espera.
  const finDeMes = `${anioMes}-31`;
  const enRiesgo = fuera.filter((r) => r.fechaMaxima && r.fechaMaxima <= finDeMes);
  const faltanteParaRiesgo = enRiesgo.reduce((s, r) => s + r.montoAsignado, 0);

  return {
    disponibleM1, disponibleM2,
    asignadosM1: m1.dentro, asignadosM2: m2.dentro,
    sobranteM1: m1.resto, sobranteM2: m2.resto,
    fuera, topePrioridad, enRiesgo, faltanteParaRiesgo,
  };
}

export async function obtenerColaMes(anioMes: string): Promise<RenglonCola[]> {
  const { data } = await supabase.from("cola_pago_mes").select("*").eq("anio_mes", anioMes).order("turno");
  return ((data || []) as Record<string, unknown>[]).map((f) => ({
    clienteId: String(f.cliente_id),
    nombre: "",
    modalidad: (f.modalidad === "convenio_simple" ? "convenio_simple" : "rdc") as RenglonCola["modalidad"],
    turno: Number(f.turno) || 0,
    montoAsignado: Number(f.monto_asignado) || 0,
    concepto: String(f.concepto || ""),
    fechaMaxima: (f.fecha_maxima as string) ?? null,
    porPrioridad: !!f.por_prioridad,
    motivoPrioridad: (f.motivo_prioridad as string) ?? undefined,
  }));
}

/** Congela la cola del mes. A partir de aquí ya no se recalcula. */
export async function confirmarColaMes(
  anioMes: string, renglones: RenglonCola[], quien: string,
): Promise<boolean> {
  await supabase.from("cola_pago_mes").delete().eq("anio_mes", anioMes);
  const filas = renglones.map((r) => ({
    anio_mes: anioMes, cliente_id: r.clienteId, modalidad: r.modalidad,
    turno: r.turno, monto_asignado: r.montoAsignado, concepto: r.concepto,
    por_prioridad: r.porPrioridad, motivo_prioridad: r.motivoPrioridad || null,
    autorizado_por: r.porPrioridad ? quien : null, fecha_maxima: r.fechaMaxima,
  }));
  const { error } = await supabase.from("cola_pago_mes").insert(filas);
  if (error) return false;
  await supabase.from("bolsa_devolucion_mes").update({
    cerrado: true, cerrado_por: quien, cerrado_en: new Date().toISOString(),
  }).eq("anio_mes", anioMes);
  return true;
}

/** Reabrir la cola — solo RAC y DGE, y queda registrado. */
export async function reabrirColaMes(anioMes: string, quien: string): Promise<boolean> {
  const { error } = await supabase.from("bolsa_devolucion_mes").update({
    cerrado: false, reabierto_por: quien, reabierto_en: new Date().toISOString(),
  }).eq("anio_mes", anioMes);
  return !error;
}

// ── Colas ya selladas (lo que la DGE congeló mes a mes) ────────────────────
// La pestaña de Calendario mostraba una proyección que se recalculaba cada vez
// y no coincidía con lo que se había autorizado. Esto lee lo REAL: la cola
// firmada que vive en cola_pago_mes, con la bolsa registrada de cada mes.

export interface RenglonColaSellada {
  anioMes: string;
  turno: number;
  clienteId: string;
  nombre: string;
  sucursal: string | null;
  concepto: string;
  monto: number;
  autorizadoPor: string | null;
  fechaMaxima: string | null;
  pagado: boolean;
  contingencia: string | null;
}

export interface MesSellado {
  anioMes: string;
  bolsaRegistrada: number;
  repartido: number;
  sobrante: number;
  cerrado: boolean;
  renglones: RenglonColaSellada[];
}

/** Devuelve las colas ya generadas, de la más reciente hacia adelante. */
export async function listarColasSelladas(): Promise<MesSellado[]> {
  const [{ data: colas }, { data: bolsas }] = await Promise.all([
    supabase.from("cola_pago_mes").select("*").order("anio_mes").order("turno"),
    supabase.from("bolsa_devolucion_mes").select("*"),
  ]);
  const filas = (colas || []) as Record<string, unknown>[];
  if (filas.length === 0) return [];

  const ids = Array.from(new Set(filas.map((f) => String(f.cliente_id))));
  const [{ data: cls }, { data: comps }] = await Promise.all([
    supabase.from("clientes").select("id, nombre, sucursal").in("id", ids),
    supabase.from("compensacion_devolucion").select("cliente_id, tipo_demanda").in("cliente_id", ids),
  ]);
  const infoCliente = new Map(
    (cls || []).map((c) => {
      const r = c as { id: unknown; nombre: unknown; sucursal: unknown };
      return [String(r.id), { nombre: String(r.nombre || ""), sucursal: (r.sucursal as string) ?? null }];
    })
  );
  const contingenciaPorId = new Map(
    (comps || []).map((c) => {
      const r = c as { cliente_id: unknown; tipo_demanda: unknown };
      return [String(r.cliente_id), (r.tipo_demanda as string) ?? null];
    })
  );
  const bolsaPorMes = new Map(
    (bolsas || []).map((b) => {
      const r = b as { anio_mes: unknown; monto_registrado: unknown; cerrado: unknown };
      return [String(r.anio_mes), { monto: Number(r.monto_registrado) || 0, cerrado: Boolean(r.cerrado) }];
    })
  );

  const porMes = new Map<string, MesSellado>();
  for (const f of filas) {
    const anioMes = String(f.anio_mes);
    const id = String(f.cliente_id);
    const info = infoCliente.get(id);
    if (!porMes.has(anioMes)) {
      const b = bolsaPorMes.get(anioMes);
      porMes.set(anioMes, {
        anioMes,
        bolsaRegistrada: b?.monto ?? 0,
        repartido: 0,
        sobrante: 0,
        cerrado: b?.cerrado ?? false,
        renglones: [],
      });
    }
    const mes = porMes.get(anioMes)!;
    const monto = Number(f.monto_asignado) || 0;
    mes.repartido += monto;
    mes.renglones.push({
      anioMes,
      turno: Number(f.turno) || 0,
      clienteId: id,
      nombre: info?.nombre || `Cliente ${id}`,
      sucursal: info?.sucursal ?? null,
      concepto: String(f.concepto || ""),
      monto,
      autorizadoPor: (f.autorizado_por as string) ?? null,
      fechaMaxima: (f.fecha_maxima as string) ?? null,
      pagado: Boolean(f.pagado),
      contingencia: contingenciaPorId.get(id) ?? null,
    });
  }
  for (const m of porMes.values()) m.sobrante = Math.max(0, m.bolsaRegistrada - m.repartido);
  return Array.from(porMes.values()).sort((a, b) => a.anioMes.localeCompare(b.anioMes));
}
