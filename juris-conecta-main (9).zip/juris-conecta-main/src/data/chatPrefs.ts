import { supabase } from "../lib/supabase";

export type PrefMapa = Record<string, { favorito: boolean; archivado: boolean }>;

// Trae las marcas (favorito/archivado) de esta persona
export async function fetchPreferencias(usuario: string): Promise<PrefMapa> {
  if (!usuario) return {};
  const { data, error } = await supabase
    .from("chat_preferencias")
    .select("canal_id, favorito, archivado")
    .eq("usuario", usuario);
  if (error) { console.error("No se pudieron traer las preferencias:", error.message); return {}; }
  const mapa: PrefMapa = {};
  for (const r of data || []) mapa[r.canal_id] = { favorito: !!r.favorito, archivado: !!r.archivado };
  return mapa;
}

// Guarda una marca (favorito o archivado) sin borrar la otra
export async function setPreferencia(
  usuario: string,
  canalId: string,
  cambios: { favorito?: boolean; archivado?: boolean }
): Promise<boolean> {
  if (!usuario) return false;
  const { data: actual } = await supabase
    .from("chat_preferencias")
    .select("favorito, archivado")
    .eq("usuario", usuario).eq("canal_id", canalId).maybeSingle();
  const fila = {
    usuario,
    canal_id: canalId,
    favorito: cambios.favorito ?? actual?.favorito ?? false,
    archivado: cambios.archivado ?? actual?.archivado ?? false,
    updated_at: new Date().toISOString(),
  };
  const { error } = await supabase.from("chat_preferencias").upsert(fila, { onConflict: "usuario,canal_id" });
  if (error) { console.error("No se pudo guardar la preferencia:", error.message); return false; }
  return true;
}
