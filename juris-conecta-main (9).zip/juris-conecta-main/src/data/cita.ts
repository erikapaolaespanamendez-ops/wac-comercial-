// ============================================================================
// CITA DE VALIDACIÓN PRESENCIAL
// ============================================================================
// Es la ÚNICA puerta por la que se puede escribir en una ficha bloqueada.
// No hay "desbloquear la ficha": lo que se abre es una VENTANA, y solo se abre
// con el cliente parado en la sucursal, con sus documentos.
//
// El flujo son tres momentos:
//   1. ABRIR   → la sucursal registra que el cliente está presente.
//   2. CERRAR  → la sucursal terminó de cotejar. La ventana se cierra.
//   3. VALIDAR → el RAC revisa y confirma. Ahí vuelve el candado.
//
// Mientras la ventana está abierta, el disparador fn_bloqueo_clientes de la
// base deja pasar los cambios en esa ficha. En cuanto se cierra, vuelve a
// rechazarlos. Eso NO se controla desde aquí: lo hace la base, para que
// ninguna pantalla lo pueda saltar.
// ============================================================================
import { supabase } from "../lib/supabase";
import { invalidarClientes } from "./clientes";

export type CitaValidacion = {
  id: string;
  clienteId: number;
  origen: string;              // 'validacion_datos' | 'control_devoluciones'
  abiertaPor: string;
  abiertaEn: string;
  cerradaPor: string | null;
  cerradaEn: string | null;
  validadaPor: string | null;
  validadaEn: string | null;
  documentosOk: boolean;
  observaciones: string | null;
};

export type CitaAgendada = {
  id: string;
  clienteId: number;
  fechaHora: string;
  sucursal: string;
  estado: "agendada" | "atendida" | "no_se_presento" | "cancelada";
  agendadaPor: string;
  documentosDictados: string | null;
  notas: string | null;
};

export type CampoCotejo = {
  clave: string;
  etiqueta: string;
  grupo: string;               // 'identidad' | 'dinero'
  obligatorio: boolean;
  orden: number;
};

export type DocumentoRequerido = {
  clave: string;
  etiqueta: string;
  mesesVigencia: number | null; // null = no caduca
  obligatorio: boolean;
  orden: number;
};

function aCita(f: any): CitaValidacion {
  return {
    id: String(f.id),
    clienteId: Number(f.cliente_id),
    origen: f.origen || "validacion_datos",
    abiertaPor: f.abierta_por || "",
    abiertaEn: f.abierta_en,
    cerradaPor: f.cerrada_por ?? null,
    cerradaEn: f.cerrada_en ?? null,
    validadaPor: f.validada_por ?? null,
    validadaEn: f.validada_en ?? null,
    documentosOk: Boolean(f.documentos_ok),
    observaciones: f.observaciones ?? null,
  };
}

function aAgenda(f: any): CitaAgendada {
  return {
    id: String(f.id),
    clienteId: Number(f.cliente_id),
    fechaHora: f.fecha_hora,
    sucursal: f.sucursal || "",
    estado: f.estado,
    agendadaPor: f.agendada_por || "",
    documentosDictados: f.documentos_dictados ?? null,
    notas: f.notas ?? null,
  };
}

// ---------------------------------------------------------------------------
// AGENDA. Tope de 3 citas de validación al mes, y lo cuida la base: si alguien
// intenta la cuarta, el insert se rechaza con el mensaje de por qué. Solo
// cuentan las agendadas y las atendidas — si el cliente no llega o cancela, el
// cupo se libera y su turno en la fila NO se pierde.
// ---------------------------------------------------------------------------
export const TOPE_CITAS_MES = 3;

export type Sucursal = { clave: string; nombre: string; atiendeClientes: boolean };

// Catálogo de sucursales. Vive en la base para que la Dirección lo edite sin
// compilar: si abre una plaza nueva, se agrega un renglón y ya aparece aquí.
export async function fetchSucursales(): Promise<Sucursal[]> {
  const { data, error } = await supabase
    .from("sucursal")
    .select("clave, nombre, atiende_clientes")
    .eq("activo", true)
    .eq("atiende_clientes", true)
    .order("orden");
  if (error) { console.error("No se pudo traer el catálogo de sucursales:", error.message); return []; }
  return (data || []).map((f: any) => ({
    clave: f.clave, nombre: f.nombre, atiendeClientes: Boolean(f.atiende_clientes),
  }));
}

// Cuántos cupos quedan en el mes de esa fecha.
export async function cuposDelMes(fechaISO: string): Promise<{ usados: number; libres: number }> {
  const d = new Date(fechaISO);
  const ini = new Date(d.getFullYear(), d.getMonth(), 1).toISOString();
  const fin = new Date(d.getFullYear(), d.getMonth() + 1, 1).toISOString();
  const { data, error } = await supabase
    .from("cita_agenda")
    .select("id, estado")
    .gte("fecha_hora", ini)
    .lt("fecha_hora", fin)
    .in("estado", ["agendada", "atendida"]);
  if (error) return { usados: 0, libres: TOPE_CITAS_MES };
  const usados = (data || []).length;
  return { usados, libres: Math.max(0, TOPE_CITAS_MES - usados) };
}

// La cita pendiente del cliente (solo puede tener una).
export async function fetchCitaAgendada(clienteId: string | number): Promise<CitaAgendada | null> {
  const { data, error } = await supabase
    .from("cita_agenda")
    .select("*")
    .eq("cliente_id", Number(clienteId))
    .eq("estado", "agendada")
    .maybeSingle();
  if (error || !data) return null;
  return aAgenda(data);
}

export async function fetchAgendaCliente(clienteId: string | number): Promise<CitaAgendada[]> {
  const { data, error } = await supabase
    .from("cita_agenda")
    .select("*")
    .eq("cliente_id", Number(clienteId))
    .order("fecha_hora", { ascending: false });
  if (error) return [];
  return (data || []).map(aAgenda);
}

// Agendar. Aquí se consume el cupo del mes.
export async function agendarCita(p: {
  clienteId: string | number;
  fechaHora: string;
  sucursal: string;
  quien: string;
  documentosDictados?: string;
  notas?: string;
}): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("cita_agenda").insert({
    cliente_id: Number(p.clienteId),
    fecha_hora: p.fechaHora,
    sucursal: p.sucursal,
    agendada_por: p.quien,
    documentos_dictados: p.documentosDictados ?? null,
    notas: p.notas ?? null,
  });
  if (error) {
    if (error.message.includes("ux_cita_agenda_pendiente")) return { ok: false, error: "Este cliente ya tiene una cita agendada." };
    return { ok: false, error: error.message };
  }
  return { ok: true };
}

// El cliente no llegó: se asienta y el cupo se libera. Su turno no se pierde.
export async function marcarNoSePresento(citaId: string, quien: string): Promise<boolean> {
  const { error } = await supabase.from("cita_agenda").update({
    estado: "no_se_presento", cerrada_por: quien, cerrada_en: new Date().toISOString(),
  }).eq("id", citaId);
  return !error;
}

export async function cancelarCitaAgendada(citaId: string, quien: string, motivo?: string): Promise<boolean> {
  const { error } = await supabase.from("cita_agenda").update({
    estado: "cancelada", cerrada_por: quien, cerrada_en: new Date().toISOString(), notas: motivo ?? null,
  }).eq("id", citaId);
  return !error;
}

// ---------------------------------------------------------------------------
// Catálogos. Viven en la base para que la Dirección los edite sin compilar.
// ---------------------------------------------------------------------------
export async function fetchCamposCotejo(): Promise<CampoCotejo[]> {
  const { data, error } = await supabase
    .from("cita_campo_cotejo")
    .select("*")
    .eq("activo", true)
    .order("orden");
  if (error) { console.error("No se pudo traer el catálogo de campos:", error.message); return []; }
  return (data || []).map((f: any) => ({
    clave: f.clave, etiqueta: f.etiqueta, grupo: f.grupo,
    obligatorio: Boolean(f.obligatorio), orden: Number(f.orden),
  }));
}

export async function fetchDocumentosRequeridos(): Promise<DocumentoRequerido[]> {
  const { data, error } = await supabase
    .from("cita_documento_requerido")
    .select("*")
    .eq("activo", true)
    .order("orden");
  if (error) { console.error("No se pudo traer el catálogo de documentos:", error.message); return []; }
  return (data || []).map((f: any) => ({
    clave: f.clave, etiqueta: f.etiqueta,
    mesesVigencia: f.meses_vigencia == null ? null : Number(f.meses_vigencia),
    obligatorio: Boolean(f.obligatorio), orden: Number(f.orden),
  }));
}

// ---------------------------------------------------------------------------
// La cita abierta del cliente (si tiene). La base solo permite una a la vez.
// ---------------------------------------------------------------------------
export async function fetchCitaAbierta(clienteId: string | number): Promise<CitaValidacion | null> {
  const { data, error } = await supabase
    .from("cita_validacion")
    .select("*")
    .eq("cliente_id", Number(clienteId))
    .is("cerrada_en", null)
    .maybeSingle();
  if (error || !data) return null;
  return aCita(data);
}

export async function fetchHistorialCitas(clienteId: string | number): Promise<CitaValidacion[]> {
  const { data, error } = await supabase
    .from("cita_validacion")
    .select("*")
    .eq("cliente_id", Number(clienteId))
    .order("abierta_en", { ascending: false });
  if (error) return [];
  return (data || []).map(aCita);
}

// ---------------------------------------------------------------------------
// Abrir. Solo con el cliente presente. Si ya hay una abierta, la base la rechaza.
// ---------------------------------------------------------------------------
export async function abrirCita(p: {
  clienteId: string | number;
  quien: string;
  origen?: "validacion_datos" | "control_devoluciones";
  observaciones?: string;
  agendaId?: string | null;
}): Promise<{ ok: boolean; cita: CitaValidacion | null; error?: string }> {
  const { data, error } = await supabase.from("cita_validacion").insert({
    cliente_id: Number(p.clienteId),
    origen: p.origen || "validacion_datos",
    abierta_por: p.quien,
    observaciones: p.observaciones ?? null,
    agenda_id: p.agendaId ?? null,
  }).select().single();
  if (error) {
    const dup = error.message.includes("ux_cita_validacion_abierta");
    return { ok: false, cita: null, error: dup ? "Este cliente ya tiene una cita abierta." : error.message };
  }
  // El cliente llegó: su cita agendada queda atendida y se enlaza con la ventana.
  if (p.agendaId) {
    await supabase.from("cita_agenda").update({
      estado: "atendida", cita_validacion_id: String(data.id),
    }).eq("id", p.agendaId);
  }
  return { ok: true, cita: aCita(data) };
}

// ---------------------------------------------------------------------------
// Cerrar. La sucursal terminó de cotejar; la ficha se vuelve a cerrar sola.
// ---------------------------------------------------------------------------
export async function cerrarCita(p: {
  citaId: string;
  clienteId: string | number;
  quien: string;
  documentosOk: boolean;
  observaciones?: string;
}): Promise<boolean> {
  const { error } = await supabase.from("cita_validacion").update({
    cerrada_por: p.quien,
    cerrada_en: new Date().toISOString(),
    documentos_ok: p.documentosOk,
    observaciones: p.observaciones ?? null,
  }).eq("id", p.citaId);
  if (error) { console.error("No se pudo cerrar la cita:", error.message); return false; }

  // Queda asentado en la ficha que el cliente SÍ se presentó. Este es el dato
  // que acredita la validación presencial; las banderas viejas no valían.
  await supabase.from("clientes").update({
    validacion_presencial_por: p.quien,
    validacion_presencial_en: new Date().toISOString(),
    datos_llenados_sucursal_por: p.quien,
    datos_llenados_sucursal_en: new Date().toISOString(),
  }).eq("id", String(p.clienteId));
  invalidarClientes();
  return true;
}

// ---------------------------------------------------------------------------
// Validar. Solo el RAC. Aquí vuelve el candado sobre datos ya verificados.
// ---------------------------------------------------------------------------
export async function validarCita(p: {
  citaId: string;
  clienteId: string | number;
  quien: string;
}): Promise<boolean> {
  const ahora = new Date().toISOString();
  const { error } = await supabase.from("cita_validacion").update({
    validada_por: p.quien,
    validada_en: ahora,
  }).eq("id", p.citaId);
  if (error) { console.error("No se pudo validar la cita:", error.message); return false; }

  const { error: e2 } = await supabase.from("clientes").update({
    datos_validados_sucursal: true,
    validado_sucursal_por: p.quien,
    fecha_validado_sucursal: ahora,
    requiere_cita_sucursal: false,
    bloqueado: true,
    bloqueado_por: p.quien,
    bloqueado_en: ahora,
    motivo_bloqueo: "Datos cotejados en cita presencial y validados por el RAC el " +
      new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" }) + ".",
  }).eq("id", String(p.clienteId));
  invalidarClientes();
  if (e2) { console.error("No se pudo cerrar el candado:", e2.message); return false; }
  return true;
}

// ---------------------------------------------------------------------------
// Vigencia de un documento contra su catálogo.
// ---------------------------------------------------------------------------
export function documentoVigente(fechaExpedicion: string | null, mesesVigencia: number | null): boolean | null {
  if (mesesVigencia == null) return true;          // no caduca
  if (!fechaExpedicion) return null;               // sin fecha: no se puede saber
  const limite = new Date();
  limite.setMonth(limite.getMonth() - mesesVigencia);
  return new Date(fechaExpedicion) >= limite;
}
