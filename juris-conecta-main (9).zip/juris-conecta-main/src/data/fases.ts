import { supabase } from "../lib/supabase";

// =====================================================================
//  FASES DEL SISTEMA  —  puente con la tabla 'fases_sistema' de Supabase.
//  Cada fase: qué se resuelve, quién responde, términos y validaciones.
// =====================================================================

export type Fase = {
  id: string;
  nombre: string;
  resuelve: string;
  responsable: string;
  terminos: string;
  validaciones: string;
  orden: number;
  activo: boolean;
};

// Trae todas las fases, ordenadas.
export async function fetchFases(): Promise<Fase[]> {
  const { data, error } = await supabase
    .from("fases_sistema")
    .select("*")
    .order("orden", { ascending: true });
  if (error || !data) return [];
  return data as Fase[];
}

// Crea una fase nueva.
export async function crearFase(f: {
  nombre: string; resuelve: string; responsable: string; terminos: string; validaciones: string; orden: number;
}): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("fases_sistema").insert(f);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

// Guarda (edita) una fase existente.
export async function guardarFase(f: Fase): Promise<{ ok: boolean; error?: string }> {
  const { id, ...campos } = f;
  const { error } = await supabase.from("fases_sistema").update(campos).eq("id", id);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

// Archiva / desarchiva una fase (la apaga sin borrarla).
export async function archivarFase(id: string, activo: boolean): Promise<boolean> {
  const { error } = await supabase.from("fases_sistema").update({ activo }).eq("id", id);
  return !error;
}
