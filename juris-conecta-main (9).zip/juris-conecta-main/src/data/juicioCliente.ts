// Datos jurídicos del juicio de cada cliente (uno por cliente).
// La dirección de la garantía y el número de crédito NO se guardan aquí:
// se reflejan en pantalla desde la ficha del cliente.
import { supabase } from "../lib/supabase";

export type JuicioCliente = {
  numExpediente: string;
  juzgado: string;
  jurisdiccion: string;
  tipoJuicio: string;
  ciudad: string;
  exhorto: boolean;
  exhortoNumero: string;
  exhortoJuzgado: string;
  amparo: boolean;
  amparoNumero: string;   // número de toca o radicado
};

export const JUICIO_VACIO: JuicioCliente = {
  numExpediente: "", juzgado: "", jurisdiccion: "", tipoJuicio: "", ciudad: "",
  exhorto: false, exhortoNumero: "", exhortoJuzgado: "",
  amparo: false, amparoNumero: "",
};

// Tipos de juicio (todos ligados a una garantía inmueble/terreno).
export const TIPOS_JUICIO = [
  "Civil",
  "Mercantil",
  "Sucesorio",
  "Jurisdicción voluntaria",
  "Usucapión",
  "Prescripción positiva",
  "Restitución de bienes",
  "Otro",
];

export async function fetchJuicio(clienteId: string): Promise<JuicioCliente | null> {
  const { data, error } = await supabase
    .from("juicio_cliente")
    .select("*")
    .eq("cliente_id", clienteId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    numExpediente: data.num_expediente || "",
    juzgado: data.juzgado || "",
    jurisdiccion: data.jurisdiccion || "",
    tipoJuicio: data.tipo_juicio || "",
    ciudad: data.ciudad || "",
    exhorto: !!data.exhorto,
    exhortoNumero: data.exhorto_numero || "",
    exhortoJuzgado: data.exhorto_juzgado || "",
    amparo: !!data.amparo,
    amparoNumero: data.amparo_numero || "",
  };
}

export async function guardarJuicio(clienteId: string, j: JuicioCliente): Promise<boolean> {
  const { error } = await supabase.from("juicio_cliente").upsert(
    {
      cliente_id: clienteId,
      num_expediente: j.numExpediente || null,
      juzgado: j.juzgado || null,
      jurisdiccion: j.jurisdiccion || null,
      tipo_juicio: j.tipoJuicio || null,
      ciudad: j.ciudad || null,
      exhorto: j.exhorto,
      exhorto_numero: j.exhorto ? (j.exhortoNumero || null) : null,
      exhorto_juzgado: j.exhorto ? (j.exhortoJuzgado || null) : null,
      amparo: j.amparo,
      amparo_numero: j.amparo ? (j.amparoNumero || null) : null,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "cliente_id" },
  );
  return !error;
}
