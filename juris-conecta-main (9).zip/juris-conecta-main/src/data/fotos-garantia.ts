// =====================================================================
//  MÓDULO COMERCIAL · Fotos de la garantía
//  →  src/data/fotos-garantia.ts
//
//  QUÉ RESUELVE ESTE ARCHIVO:
//  Antes la galería guardaba nada más las ligas de las fotos, sin decir
//  qué era cada una. Por eso la ficha técnica no tenía cómo saber cuál
//  poner de portada y cuál va en la hoja del mapa. Ahora cada foto lleva
//  su ETIQUETA: fachada, lateral, entre calles, interior, calle, patio.
//
//  Y ADEMÁS:
//  La misma lógica de fotos estaba escrita dos veces —en Editar garantía
//  y en Mandar a pre-dictamen—, así que una podía guardar de un modo y
//  la otra de otro. Aquí queda en un solo lugar y las dos pantallas lo
//  usan. Ninguna función de este archivo habla con la base: solo arman
//  la lista; guardar sigue siendo trabajo de cada pantalla.
//
//  CÓMO CONVIVE CON LO VIEJO:
//  Las fotos que ya estaban subidas se guardaron como texto suelto. Al
//  leerlas se convierten en {url, tipo: null} y aparecen como "Sin
//  clasificar". No se pierde ninguna y no hay que migrar nada a la
//  fuerza: en cuanto alguien entre a la galería, les pone su etiqueta.
// =====================================================================

/** Las etiquetas que puede llevar una foto. El orden de esta lista ES el
 *  orden en que se ofrecen en la pantalla, de la más común a la menos. */
export const TIPOS_FOTO = [
  "Fachada",
  "Lateral",
  "Entre calles",
  "Interior",
  "Calle",
  "Patio",
  "Documento",
  "Otro",
] as const;

export type TipoFoto = (typeof TIPOS_FOTO)[number];

/** Las que SÍ son retratos del inmueble y por lo tanto se le pueden
 *  enseñar a un cliente.
 *
 *  POR QUÉ EXISTE ESTA LISTA (08-09-2026):
 *  En la galería de una garantía se subió el oficio del banco escaneado
 *  —con el número de crédito, el nombre del deudor y la cuenta bancaria
 *  de DIIPA— etiquetado como "Otro". La ficha técnica rellena sus dos
 *  fotos chicas con lo que haya, así que ese oficio se iba a imprimir en
 *  la hoja 1 del papel que se le entrega al cliente.
 *
 *  Desde aquí, la ficha SOLO usa las de esta lista. Un documento o una
 *  foto sin clasificar se queda para adentro: se ve en la galería del
 *  sistema, nunca en lo que sale a la calle. */
export const TIPOS_DEL_INMUEBLE: readonly TipoFoto[] = [
  "Fachada",
  "Lateral",
  "Entre calles",
  "Interior",
  "Calle",
  "Patio",
];

/** ¿Esta foto se le puede enseñar a un cliente? Sin etiqueta la respuesta
 *  es NO: mientras nadie diga qué es, no sale del sistema. */
export function esDelInmueble(f: FotoGarantia): boolean {
  return f.tipo != null && TIPOS_DEL_INMUEBLE.includes(f.tipo);
}

/** Una foto: su liga y qué es. `tipo` en nulo = todavía sin clasificar. */
export type FotoGarantia = {
  url: string;
  tipo: TipoFoto | null;
};

/** ¿Ese texto es una de las etiquetas válidas? Sirve para no tragarse
 *  cualquier cosa que venga en la base. */
function tipoValido(x: unknown): TipoFoto | null {
  return typeof x === "string" && (TIPOS_FOTO as readonly string[]).includes(x)
    ? (x as TipoFoto)
    : null;
}

/** Convierte lo que venga de la columna `galeria_fotos` en una lista
 *  pareja. Aguanta las tres formas que existen hoy en la base:
 *    · texto suelto            → "https://…"            (lo viejo)
 *    · objeto con url          → { url: "https://…" }
 *    · objeto con url y tipo   → { url: "https://…", tipo: "Lateral" }
 *  Lo que no traiga liga se descarta, para que no salgan huecos. */
export function leerGaleria(bruto: unknown): FotoGarantia[] {
  if (!Array.isArray(bruto)) return [];
  return bruto
    .map((x): FotoGarantia | null => {
      if (typeof x === "string") return x ? { url: x, tipo: null } : null;
      if (x && typeof x === "object") {
        const o = x as { url?: unknown; tipo?: unknown };
        const url = typeof o.url === "string" ? o.url : "";
        return url ? { url, tipo: tipoValido(o.tipo) } : null;
      }
      return null;
    })
    .filter(Boolean) as FotoGarantia[];
}

/** Cómo se guarda en la base: siempre objetos, nunca texto suelto. */
export function galeriaParaGuardar(fotos: FotoGarantia[]): { url: string; tipo: string | null }[] {
  return fotos.map((f) => ({ url: f.url, tipo: f.tipo }));
}

/** La lista COMPLETA para pintar en pantalla: la portada primero —que
 *  por definición es la fachada— y luego las demás. */
export function todasLasFotos(
  fotoFachada: string | null,
  galeria: FotoGarantia[],
): FotoGarantia[] {
  const resto = galeria.filter((f) => f.url !== fotoFachada);
  return fotoFachada ? [{ url: fotoFachada, tipo: "Fachada" }, ...resto] : resto;
}

/** Cambiar la etiqueta de una foto.
 *
 *  Regla: marcar una foto como FACHADA es lo mismo que hacerla portada.
 *  Antes eran dos cosas separadas —un botón "Hacer principal" y ningún
 *  tipo—, y se podía terminar con una portada que era del patio. Ahora
 *  es una sola decisión: la que diga Fachada es la que sale en el
 *  catálogo, en el mapa y arriba de la ficha.
 *
 *  Regresa cómo quedan los dos campos que se guardan en la base. */
export function cambiarTipo(
  fotoFachada: string | null,
  galeria: FotoGarantia[],
  url: string,
  nuevoTipo: TipoFoto | null,
): { fotoFachada: string | null; galeria: FotoGarantia[] } {
  // Ponerle Fachada a una foto: se vuelve la portada y la que estaba de
  // portada se baja a la galería sin etiqueta, para que se le ponga la
  // suya. No se borra: sigue ahí.
  if (nuevoTipo === "Fachada") {
    const resto = galeria.filter((f) => f.url !== url);
    if (fotoFachada && fotoFachada !== url) resto.unshift({ url: fotoFachada, tipo: null });
    return { fotoFachada: url, galeria: resto };
  }

  // Quitarle Fachada a la portada: baja a la galería con su etiqueta
  // nueva y la garantía se queda SIN portada, a propósito. Es mejor que
  // el catálogo enseñe "Sin foto" a que enseñe la foto del patio como
  // si fuera la casa.
  if (fotoFachada === url) {
    return { fotoFachada: null, galeria: [{ url, tipo: nuevoTipo }, ...galeria] };
  }

  return {
    fotoFachada,
    galeria: galeria.map((f) => (f.url === url ? { ...f, tipo: nuevoTipo } : f)),
  };
}

/** Quitar una foto. Si se quita la portada, la garantía queda sin
 *  portada hasta que alguien marque otra como fachada. */
export function quitarFoto(
  fotoFachada: string | null,
  galeria: FotoGarantia[],
  url: string,
): { fotoFachada: string | null; galeria: FotoGarantia[] } {
  return {
    fotoFachada: fotoFachada === url ? null : fotoFachada,
    galeria: galeria.filter((f) => f.url !== url),
  };
}

/** Agregar las recién subidas. Llegan SIN etiqueta a propósito: quien
 *  sube es quien sabe qué son, y el aviso de "sin clasificar" en la
 *  pantalla es lo que le recuerda ponerles la suya.
 *
 *  Única excepción: si la garantía no tiene ninguna foto todavía, la
 *  primera se toma como fachada para que el catálogo no se quede en
 *  blanco. Se puede cambiar después. */
export function agregarFotos(
  fotoFachada: string | null,
  galeria: FotoGarantia[],
  urls: string[],
): { fotoFachada: string | null; galeria: FotoGarantia[] } {
  if (!urls.length) return { fotoFachada, galeria };
  if (!fotoFachada) {
    const [primera, ...resto] = urls;
    return { fotoFachada: primera, galeria: [...galeria, ...resto.map((u) => ({ url: u, tipo: null }))] };
  }
  return { fotoFachada, galeria: [...galeria, ...urls.map((u) => ({ url: u, tipo: null }))] };
}

/** Cuántas fotos les falta etiqueta. Es lo que pinta el aviso. */
export function sinClasificar(galeria: FotoGarantia[]): number {
  return galeria.filter((f) => f.tipo === null).length;
}

/** Las fotos que va a usar la FICHA TÉCNICA, ya acomodadas:
 *    · principal   → la fachada
 *    · secundarias → primero la de entre calles y la lateral, que son
 *                    las que ayudan a reconocer el lugar; si no hay,
 *                    se rellena con lo que exista.
 *    · deUbicacion → la de entre calles, para la hoja del mapa.
 *  Se deja aquí y no en el generador del PDF para que la ficha y la
 *  pantalla siempre escojan igual. */
export function fotosParaFicha(
  fotoFachada: string | null,
  galeria: FotoGarantia[],
): { principal: string | null; secundarias: string[]; deUbicacion: string | null } {
  // Se filtra ANTES de escoger: a la ficha solo entran retratos del
  // inmueble. Un documento escaneado o una foto sin etiqueta no llega
  // aquí ni de relleno.
  const soloFotos = galeria.filter(esDelInmueble);

  const de = (t: TipoFoto) => soloFotos.filter((f) => f.tipo === t).map((f) => f.url);

  const entreCalles = de("Entre calles");
  const laterales = de("Lateral");
  const otras = soloFotos
    .filter((f) => f.tipo !== "Entre calles" && f.tipo !== "Lateral")
    .map((f) => f.url);

  const orden = [...entreCalles, ...laterales, ...otras].filter((u) => u !== fotoFachada);

  return {
    principal: fotoFachada,
    secundarias: orden.slice(0, 2),
    deUbicacion: entreCalles[0] ?? null,
  };
}
