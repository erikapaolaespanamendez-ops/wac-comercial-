import { supabase } from "../lib/supabase";

export type LlamadaConmutador = {
  id: string;
  deNumero: string;
  paraExtension: string;
  paraArea: string;
  ts: number;
};

const canal = supabase.channel("conmutador_v1", { config: { broadcast: { self: true } } });
let suscrito = false;
function asegurarSuscrito() {
  if (!suscrito) { canal.subscribe(); suscrito = true; }
}

export function emitirLlamada(l: { deNumero: string; paraExtension?: string; paraArea?: string }) {
  asegurarSuscrito();
  const full: LlamadaConmutador = {
    id: crypto.randomUUID(),
    deNumero: l.deNumero || "Desconocido",
    paraExtension: l.paraExtension || "",
    paraArea: l.paraArea || "",
    ts: Date.now(),
  };
  canal.send({ type: "broadcast", event: "entrante", payload: full });
}

export function suscribirLlamadas(cb: (l: LlamadaConmutador) => void): () => void {
  const handler = ({ payload }: { payload: LlamadaConmutador }) => cb(payload);
  canal.on("broadcast", { event: "entrante" }, handler);
  asegurarSuscrito();
  return () => {};
}

// Trae la extensión/área del usuario actual para saber a quién le toca sonar.
// Busca primero por CORREO (lo más confiable: es el login) y luego por nombre.
export async function miPuestoConmutador(correo: string, nombre: string): Promise<{ extension: string; area: string; activo: boolean }> {
  type Fila = { extension: string | null; area: string | null; activo: boolean | null };
  let data: Fila | null = null;

  if (correo) {
    const r = await supabase.from("colaboradores").select("extension,area,activo").ilike("correo", correo).maybeSingle();
    data = (r.data as Fila | null) ?? null;
  }
  if (!data && nombre) {
    const r = await supabase.from("colaboradores").select("extension,area,activo").eq("nombre", nombre).maybeSingle();
    data = (r.data as Fila | null) ?? null;
  }

  return {
    extension: String(data?.extension ?? ""),
    area: String(data?.area ?? ""),
    activo: data?.activo == null ? true : Boolean(data.activo),
  };
}
