// ===================================================================
// Solicitudes de cliente venidas de JusticiaFácil
// →  src/data/solicitudesJF.ts
// Cuando en JusticiaFácil crean una tarea/cita para un cliente que no
// encontraron aquí, queda pendiente en solicitud_cliente_jf. Desde
// aquí se resuelve: Vincular con otro / Conservar (crear nuevo) /
// Eliminar.
// ===================================================================
import { supabase } from "../lib/supabase";
import { registrarCliente, type Cliente } from "./clientes";
import { agregarTarea } from "./tareas";
import { avisarEventoA } from "./avisarEvento";

// Solo lo mínimo que necesitamos del cliente (id + nombre) — así el
// picker de "vincular con otro" no tiene que traer el objeto Cliente completo.
export type ClienteMinimo = { id: string; nombre: string };

export type EstadoSolicitudJF = "pendiente" | "vinculada" | "creada" | "descartada";

export type SolicitudJF = {
  id: string;
  origen: string;
  nombreCliente: string;
  titulo: string | null;
  detalle: string | null;
  tipo: string | null;
  fecha: string | null;
  asignadoCorreo: string | null;
  asignadoNombre: string | null;
  estado: EstadoSolicitudJF;
  clienteId: string | null;
  jfEventoId: string | null;
  createdAt: string;
};

function mapSolicitud(r: any): SolicitudJF {
  return {
    id: String(r.id),
    origen: r.origen ?? "justiciafacil",
    nombreCliente: r.nombre_cliente ?? "",
    titulo: r.titulo ?? null,
    detalle: r.detalle ?? null,
    tipo: r.tipo ?? null,
    fecha: r.fecha ?? null,
    asignadoCorreo: r.asignado_correo ?? null,
    asignadoNombre: r.asignado_nombre ?? null,
    estado: (r.estado as EstadoSolicitudJF) ?? "pendiente",
    clienteId: r.cliente_id ?? null,
    jfEventoId: r.jf_evento_id ?? null,
    createdAt: r.created_at ?? "",
  };
}

/** Solicitudes pendientes de resolver (para el indicador y el badge de la pestaña). */
export async function fetchSolicitudesPendientesJF(): Promise<SolicitudJF[]> {
  try {
    const { data, error } = await supabase
      .from("solicitud_cliente_jf")
      .select("*")
      .eq("estado", "pendiente")
      .order("created_at", { ascending: false });
    if (error || !data) return [];
    return (data as any[]).map(mapSolicitud);
  } catch {
    return [];
  }
}

async function crearTareaDeSolicitud(s: SolicitudJF, cliente: ClienteMinimo) {
  if (!s.asignadoCorreo) return;
  const r = await agregarTarea({
    autorEmail: s.asignadoCorreo,
    autorNombre: s.asignadoNombre || undefined,
    tipo: (s.tipo as any) || "tarea",
    titulo: s.titulo || "Tarea desde JusticiaFácil",
    detalle: s.detalle || undefined,
    fecha: s.fecha || null,
    aQuien: s.asignadoNombre || undefined,
    clienteId: cliente.id,
    clienteNombre: cliente.nombre,
    jfEventoId: s.jfEventoId || undefined, // ya existe el evento allá: se actualiza, no se duplica
  });
  if (r.ok) {
    avisarEventoA(s.asignadoCorreo, {
      tipo: "tarea",
      titulo: `Nueva tarea: ${s.titulo || ""}`,
      detalle: `Cliente: ${cliente.nombre} · desde JusticiaFácil`,
      modulo: "clientes",
      refId: cliente.id,
      icono: "✅",
    });
  }
}

/** Vincular la solicitud con un cliente YA existente (mismo cliente, error de nombre/acentos, etc). */
export async function vincularSolicitudConCliente(s: SolicitudJF, cliente: ClienteMinimo, quien: string): Promise<{ ok: boolean; error?: string }> {
  await crearTareaDeSolicitud(s, cliente);
  const { error } = await supabase.from("solicitud_cliente_jf")
    .update({ estado: "vinculada", cliente_id: cliente.id, resuelto_por: quien, resuelto_en: new Date().toISOString() })
    .eq("id", s.id);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

/** Conservar la solicitud: es un cliente nuevo de verdad → se da de alta en JurisConecta. */
export async function conservarSolicitudComoClienteNuevo(s: SolicitudJF, quien: string): Promise<{ ok: boolean; cliente?: Cliente; error?: string }> {
  try {
    const cliente = await registrarCliente({
      nombre: s.nombreCliente,
      telefono: "",
      expediente: "",
      tipo: "prospecto",
      area: "Jurídico",
      codigo: "SVT",
    });
    await crearTareaDeSolicitud(s, cliente);
    const { error } = await supabase.from("solicitud_cliente_jf")
      .update({ estado: "creada", cliente_id: cliente.id, resuelto_por: quien, resuelto_en: new Date().toISOString() })
      .eq("id", s.id);
    if (error) return { ok: false, error: error.message };
    return { ok: true, cliente };
  } catch (e: any) {
    return { ok: false, error: String(e?.message || e) };
  }
}

/** Eliminar/descartar la solicitud (duplicado, error de captura, ya no aplica, etc). */
export async function descartarSolicitudJF(s: SolicitudJF, quien: string): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.from("solicitud_cliente_jf")
    .update({ estado: "descartada", resuelto_por: quien, resuelto_en: new Date().toISOString() })
    .eq("id", s.id);
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}
