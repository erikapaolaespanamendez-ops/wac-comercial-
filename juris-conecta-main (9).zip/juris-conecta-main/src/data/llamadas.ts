import { supabase } from "../lib/supabase";
import { avisarEvento } from "./avisarEvento"; // 👈 NUEVO

// =====================================================================
//  BITÁCORA DE LLAMADAS
//  Registro inteligente: identifica el número, cuenta cuántas veces ha
//  llamado, liga al cliente, y pone folio por área (JUR-0001, COM-0001).
// =====================================================================

export type TipoLlamada = "saliente" | "entrante";

// Áreas (la clave manda el prefijo del folio)
export const AREAS: { clave: string; nombre: string; prefijo: string }[] = [
  { clave: "juridico", nombre: "Jurídico", prefijo: "JUR" },
  { clave: "comercial", nombre: "Comercial", prefijo: "COM" },
  { clave: "atencion", nombre: "Atención al Cliente", prefijo: "ATC" },
  { clave: "administracion", nombre: "Administración", prefijo: "ADM" },
  { clave: "tecnologia", nombre: "Tecnología", prefijo: "TEC" },
  { clave: "direccion", nombre: "Dirección", prefijo: "DG" },
];

// Motivos sugeridos (por qué llamó)
export const MOTIVOS: string[] = [
  "Consulta general",
  "Devolución (DV)",
  "RDC (RD)",
  "Cobranza",
  "Estatus de su caso",
  "Documentos",
  "Queja",
  "Agendar cita",
  "Otro",
];

// Resultados posibles
export const RESULTADOS: string[] = [
  "Resuelta al 1er contacto",
  "Pendiente (devolver llamada)",
  "Transferida",
  "Dejó mensaje",
  "No contestó",
];

export type Llamada = {
  id: string;
  folio: string;
  fecha: string;
  tipo: TipoLlamada;
  telefono: string;
  area: string;
  motivo: string;
  clienteNombre: string;
  garantia: string;
  expediente: string;
  resultado: string;
  devolver: boolean;
  devuelta: boolean;
  responsable: string;
  fase: string;
  grabacionUrl: string;
  fechaCompromiso: string;
  duracion: number | null;
  urgente: boolean;
  registradoPor: string;
  nombre: string; // genérico (compatibilidad)
  ext: string;
  nota: string;
  eliminado: boolean;
  archivada: boolean;
};

function soloDigitos(s: string): string {
  return (s || "").replace(/\D/g, "");
}
function ultimos10(s: string): string {
  return soloDigitos(s).slice(-10);
}

// 👇 NUEVO: quién está usando la app (usa el dato explícito si llega, si no, el de la sesión).
function quienSoy(explicito?: string | null): string {
  if (explicito && explicito.trim()) return explicito.trim();
  try {
    const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
    return y?.nombre || "Alguien";
  } catch { return "Alguien"; }
}

function mapLlamada(r: any): Llamada {
  return {
    id: r.id,
    folio: r.folio || "",
    fecha: r.fecha,
    tipo: (r.tipo as TipoLlamada) || "entrante",
    telefono: r.telefono || "",
    area: r.area || "",
    motivo: r.motivo || "",
    clienteNombre: r.cliente_nombre || "",
    garantia: r.garantia || "",
    expediente: r.expediente || "",
    resultado: r.resultado || "",
    devolver: !!r.devolver,
    devuelta: !!r.devuelta,
    responsable: r.responsable || "",
    fase: r.fase || "",
    grabacionUrl: r.grabacion_url || "",
    fechaCompromiso: r.fecha_compromiso || "",
    duracion: r.duracion ?? null,
    urgente: !!r.urgente,
    registradoPor: r.registrado_por || "",
    nombre: r.nombre || "",
    ext: r.ext || "",
    nota: r.nota || "",
    eliminado: !!r.eliminado,
    archivada: !!r.archivada,
  };
}

// Trae todo el registro (más reciente primero)
export async function fetchLlamadas(): Promise<Llamada[]> {
  const { data, error } = await supabase
    .from("llamadas")
    .select("*")
    .order("fecha", { ascending: false });
  if (error) throw error;
  // Esconde las que están en la papelera (eliminado = true) o archivadas.
  return (data || []).map(mapLlamada).filter((l) => !l.eliminado && !l.archivada);
}

// Archiva la llamada (valor=true) o la desarchiva (valor=false). NO borra de la base.
export async function archivarLlamada(id: string, valor: boolean): Promise<boolean> {
  const { error } = await supabase.from("llamadas").update({ archivada: valor }).eq("id", id);
  return !error;
}

// Manda la llamada a la papelera (valor=true) o la restaura (valor=false). NO borra de la base.
export async function eliminarLlamada(id: string, valor: boolean): Promise<boolean> {
  const { error } = await supabase.from("llamadas").update({ eliminado: valor }).eq("id", id);
  return !error;
}

// Borrado DEFINITIVO de la llamada: sí la saca de la base. No se puede deshacer.
export async function borrarLlamadaDefinitivo(id: string): Promise<boolean> {
  const { error } = await supabase.from("llamadas").delete().eq("id", id);
  return !error;
}

// Trae las llamadas que están en la papelera (para la pantalla de Papelera).
export async function fetchLlamadasEliminadas(): Promise<Llamada[]> {
  const { data, error } = await supabase.from("llamadas").select("*").eq("eliminado", true).order("fecha", { ascending: false }).limit(200);
  if (error) { console.error("No se pudieron traer las llamadas eliminadas:", error.message); return []; }
  return (data || []).map(mapLlamada);
}

// Registra una llamada (el folio por área lo pone Supabase solo)
export async function registrarLlamada(p: {
  tipo: TipoLlamada;
  telefono?: string;
  area?: string;
  motivo?: string;
  clienteNombre?: string;
  garantia?: string;
  expediente?: string;
  resultado?: string;
  devolver?: boolean;
  responsable?: string;
  fechaCompromiso?: string;
  duracion?: number | null;
  urgente?: boolean;
  registradoPor?: string;
  nombre?: string;
  ext?: string;
  nota?: string;
}): Promise<Llamada | null> {
  const fila: any = {
    tipo: p.tipo,
    telefono: p.telefono ? soloDigitos(p.telefono) : null,
    area: p.area || null,
    motivo: p.motivo || null,
    cliente_nombre: p.clienteNombre || null,
    garantia: p.garantia || null,
    expediente: p.expediente || null,
    resultado: p.resultado || null,
    devolver: p.devolver ?? false,
    responsable: p.responsable || null,
    fecha_compromiso: p.fechaCompromiso || null,
    duracion: p.duracion ?? null,
    urgente: p.urgente ?? false,
    registrado_por: p.registradoPor || null,
    nombre: p.nombre || null,
    ext: p.ext || null,
    nota: p.nota || null,
  };
  const { data, error } = await supabase.from("llamadas").insert(fila).select().single();
  if (error) {
    console.error("No se pudo registrar la llamada:", error.message);
    return null;
  }
  const creada = mapLlamada(data); // 👈 NUEVO

  // 👇 NUEVO: avisa a TODOS que se registró una llamada.
  const yo = quienSoy(creada.registradoPor);
  const quien = creada.clienteNombre || creada.telefono || "número desconocido";
  avisarEvento({
    tipo: "llamada",
    accion: "registrada",
    titulo: `Llamada ${creada.tipo === "saliente" ? "saliente" : "entrante"}: ${quien}`,
    detalle: [creada.folio, creada.motivo, creada.area].filter(Boolean).join(" · ") || "Llamada registrada",
    autor: yo,
    modulo: "llamadas",
    refId: String(creada.id),
  });

  return creada;
}

// Prende o apaga la marca de "urgente/favorita" de una llamada
export async function marcarUrgente(id: string, valor: boolean): Promise<boolean> {
  const { error } = await supabase
    .from("llamadas")
    .update({ urgente: valor })
    .eq("id", id);
  if (error) {
    console.error("No se pudo cambiar la marca de urgente:", error.message);
    return false;
  }

  // 👇 NUEVO: solo avisa cuando se PRENDE urgente (para no llenar de avisos al apagarlo).
  if (valor) {
    const { data: row } = await supabase
      .from("llamadas").select("folio, telefono, cliente_nombre").eq("id", id).maybeSingle();
    const quien = row?.cliente_nombre || row?.telefono || "una llamada";
    avisarEvento({
      tipo: "llamada",
      accion: "urgente",
      titulo: `⚠️ Llamada URGENTE: ${quien}`,
      detalle: row?.folio ? `Folio ${row.folio} · requiere atención` : "Requiere atención",
      autor: quienSoy(),
      modulo: "llamadas",
      refId: id,
    });
  }

  return true;
}

// Marca una devolución como HECHA (o la reabre). Es lo que mueve la tarea
// de "Pendiente" a "Devuelta" cuando el responsable ya devolvió la llamada.
export async function marcarDevuelta(id: string, valor: boolean): Promise<boolean> {
  const { error } = await supabase
    .from("llamadas")
    .update({ devuelta: valor })
    .eq("id", id);
  if (error) {
    console.error("No se pudo cambiar la marca de devuelta:", error.message);
    return false;
  }

  // 👇 NUEVO: solo avisa cuando se marca como DEVUELTA (no al reabrir).
  if (valor) {
    const { data: row } = await supabase
      .from("llamadas").select("folio, telefono, cliente_nombre").eq("id", id).maybeSingle();
    const quien = row?.cliente_nombre || row?.telefono || "una llamada";
    avisarEvento({
      tipo: "llamada",
      accion: "devuelta",
      titulo: `✅ Llamada devuelta: ${quien}`,
      detalle: row?.folio ? `Folio ${row.folio} · atendida` : "Devolución hecha",
      autor: quienSoy(),
      modulo: "llamadas",
      refId: id,
    });
  }

  return true;
}

// Cuenta cuántas veces ha llamado ese número y trae las últimas
export async function historialPorTelefono(
  telefono: string
): Promise<{ veces: number; ultimas: Llamada[] }> {
  const tel = soloDigitos(telefono);
  if (tel.length < 7) return { veces: 0, ultimas: [] };
  const { data, error } = await supabase
    .from("llamadas")
    .select("*")
    .eq("telefono", tel)
    .order("fecha", { ascending: false });
  if (error) return { veces: 0, ultimas: [] };
  const lista = (data || []).map(mapLlamada);
  return { veces: lista.length, ultimas: lista.slice(0, 5) };
}

// Busca un cliente por su teléfono o WhatsApp (compara últimos 10 dígitos)
export async function clientePorTelefono(
  telefono: string
): Promise<{ nombre: string; garantia: string; expediente: string } | null> {
  const tel = ultimos10(telefono);
  if (tel.length < 10) return null;
  const { data, error } = await supabase
    .from("clientes")
    .select("nombre, garantia, expediente, telefono, whatsapp");
  if (error || !data) return null;
  const m = data.find(
    (c: any) => ultimos10(c.telefono) === tel || ultimos10(c.whatsapp) === tel
  );
  if (!m) return null;
  return {
    nombre: (m as any).nombre || "",
    garantia: (m as any).garantia || "",
    expediente: (m as any).expediente || "",
  };
}
