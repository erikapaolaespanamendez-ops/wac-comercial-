// =====================================================================
//  PERMISOS VIVOS  →  va en: src/data/permisos.ts
//
//  Este archivo es el "puente" entre la pantalla de Roles y Permisos
//  (donde Paola edita con switches) y la base de datos (Supabase).
//
//  Guarda TODO en una sola tabla `nivel_modulo`: un renglón por rol y por
//  llave, con el mismo formato para módulos, pantallas, acciones, clientes
//  y seguimiento. Ya no hay JSONB ni fila única.
//
//  SI LA TABLA TODAVÍA NO EXISTE: el módulo no truena. Carga la "semilla"
//  (los permisos actuales que ya están en el código roles.ts) en modo
//  SOLO LECTURA y te muestra el SQL para crearla.
//
//  ⚠️ FASE 1: esto SOLO guarda el reglamento. Que la app OBEDEZCA lo que
//     guardes aquí es la FASE 2 (conectar roles.ts + App.tsx + módulos).
// =====================================================================
import { supabase } from "../lib/supabase";
import { useEffect, useState } from "react";
import { avisarEvento } from "./avisarEvento";
import {
  getPermisosCache,
  getPermisosVersion,
  setPermisosCache,
  suscribirPermisos,
  type PermisosCache,
} from "./permisosCache";
import {
  ROLES,
  modulosDeRol,
  TODOS_MODULOS,
  puedeAccion,
  type ModuloClave,
  type AccionClave,
} from "./roles";

// Nivel de acceso de un ROL a los clientes de un ÁREA que no es la suya.
//   ninguno      → no los ve
//   ver          → los ve pero no los toca
//   colaborador  → puede apoyar/registrar avances, pero el área dueña manda
//   editar       → control total (su propia área o dirección)
export type NivelCliente = "ninguno" | "ver" | "colaborador" | "editar";

// Actividades de seguimiento que se pueden permitir por separado.
//   asignar     → puede asignar/cambiar al asesor a cargo
//   editar      → puede editar los datos del registro
//   seguimiento → puede registrar avances/llamadas y mover su seguimiento
export type ActividadSeg = "asignar" | "editar" | "seguimiento";
export type PermisoTipo = Record<ActividadSeg, boolean>;

// Y todo eso, SEPARADO según sea PROSPECTO o ya CLIENTE.
export type SeguimientoRol = { prospecto: PermisoTipo; cliente: PermisoTipo };

export const ACTIVIDADES_SEG: ActividadSeg[] = ["asignar", "editar", "seguimiento"];

// Lo que guardamos en la columna `config` (JSONB).
export type PermisosConfig = {
  modulos: Record<string, ModuloClave[]>;                       // por código de rol
  acciones: Record<string, AccionClave[]>;                      // por código de rol
  clientes: Record<string, Record<string, NivelCliente>>;       // rol → área → nivel
  seguimiento: Record<string, SeguimientoRol>;                  // rol → (prospecto/cliente) → actividades
  actualizado_en?: string;
  actualizado_por?: string;
};

// Permiso de seguimiento "todo apagado" (para rellenar huecos sin que truene).
export function segVacio(): SeguimientoRol {
  const cero: PermisoTipo = { asignar: false, editar: false, seguimiento: false };
  return { prospecto: { ...cero }, cliente: { ...cero } };
}

// Catálogo completo de acciones (el mismo orden que queremos mostrar).
export const TODAS_ACCIONES: AccionClave[] = [
  "cartera_editar",
  "gar_editar_general",
  "gar_editar_caracteristicas",
  "gar_editar_ubicacion",
  "gar_editar_origen",
  "gar_editar_precios",
  "gar_capturar_avaluo",
  "gar_editar_legal",
  "gar_fotos_subir",
  "gar_fotos_organizar",
  "gar_descargar_ficha",
  "gar_ver_descuentos",
  "gar_pedir_apertura_promociones",
  "gar_mandar_predictamen",
  "precio_calcular",
  "precio_recalcular",
  "precio_definir_venta",
  "precio_validar",
  "promo_validar_apertura",
  "exportar_bitacora",
  "clientes_gestionar",
  "config_colaboradores",
  "aprobar_accesos",
  "generar_exp_colaborador",
  "generar_exp_cliente",
  "catalogo_editar",
  "asignar_asesor",
  "convertir_cliente",
  "editar_permisos",
  "ver_papelera",
  "borrar_definitivo",
  "borrar_colaborador",
  "enviar_papelera",
  "restaurar",
  "archivar",
  "cambiar_codigo",
  "compartir_cliente",
  "actualizar_vencido",
  "registrar_llamada",
  "gestionar_llamada",
  "crear_videollamada",
  "crear_grupo_chat",
  "administrar_grupo",
  "gestionar_actuaciones",
  "gestionar_convenio_contingencia",
  "gestionar_juicio",
  "registrar_abono",
  "borrar_abono",
  "editar_ficha",
  "subir_devolucion",
  "subir_documentos",
  "docs_criticos",
  "agregar_nota",
  "gestionar_tareas",
  "redactar_correo",
  "ver_exp_ficha", "ver_exp_expediente", "ver_exp_llamadas", "ver_exp_correos", "ver_exp_notas",
  "ver_exp_tareas", "ver_exp_actuaciones", "ver_exp_legal", "ver_exp_cronologia",
];

// Áreas de la empresa (las mismas del conmutador y de Configuración).
export const AREAS_PERMISOS: { clave: string; nombre: string; color: string }[] = [
  { clave: "direccion", nombre: "Dirección", color: "#C9A227" },
  { clave: "juridico", nombre: "Jurídico", color: "#7C3AED" },
  { clave: "comercial", nombre: "Comercial", color: "#16A34A" },
  { clave: "contabilidad", nombre: "Contabilidad", color: "#1E50A0" },
  { clave: "atencion", nombre: "Atención", color: "#EA580C" },
  { clave: "tecnologia", nombre: "Tecnología", color: "#64748B" },
];

// Área "propia" de cada rol, deducida de su grupo.
const AREA_POR_GRUPO: Record<string, string> = {
  SIS: "direccion",
  DGE: "direccion",
  DGC: "comercial",
  MKT: "comercial",
  DIL: "juridico",
  GAD: "contabilidad",
  RAC: "atencion",
  DTR: "tecnologia",
};

// Roles que mandan en todo (control total en cualquier área).
const DIRECTORES_TOTAL = ["Super_Admin", "DGE", "DTR"];

// ───────────────────────────────────────────────────────────
//  SEMILLA: arma la configuración inicial LEYENDO el código actual.
//  Así la pantalla aparece ya llena con lo que hoy es verdad, no en blanco.
// ───────────────────────────────────────────────────────────
export function semillaDesdeCodigo(): PermisosConfig {
  const modulos: Record<string, ModuloClave[]> = {};
  const acciones: Record<string, AccionClave[]> = {};
  const clientes: Record<string, Record<string, NivelCliente>> = {};
  const seguimiento: Record<string, SeguimientoRol> = {};

  for (const r of ROLES) {
    modulos[r.codigo] = modulosDeRol(r.codigo);
    acciones[r.codigo] = TODAS_ACCIONES.filter((a) => puedeAccion(r.codigo, a));

    const propia = AREA_POR_GRUPO[r.grupo] || "direccion";
    const total = DIRECTORES_TOTAL.includes(r.codigo);
    const fila: Record<string, NivelCliente> = {};
    for (const ar of AREAS_PERMISOS) {
      // Tu regla: su área = editar; lo demás = colaborador; dirección = editar en todo.
      fila[ar.clave] = total ? "editar" : ar.clave === propia ? "editar" : "colaborador";
    }
    clientes[r.codigo] = fila;

    // Seguimiento (semilla): se deduce de las acciones/módulos actuales.
    //   asignar     ← acción "asignar_asesor"
    //   editar      ← acción "clientes_gestionar"
    //   seguimiento ← ve el módulo "seguimiento"
    // Arranca igual para prospecto y cliente; tú lo afinas por separado.
    const base: PermisoTipo = {
      asignar: puedeAccion(r.codigo, "asignar_asesor"),
      editar: puedeAccion(r.codigo, "clientes_gestionar"),
      seguimiento: modulosDeRol(r.codigo).includes("seguimiento"),
    };
    seguimiento[r.codigo] = { prospecto: { ...base }, cliente: { ...base } };
  }

  return { modulos, acciones, clientes, seguimiento };
}

// ───────────────────────────────────────────────────────────
//  LA TABLA ÚNICA
//
//  Todos los permisos viven en `nivel_modulo`, un renglón por
//  rol + llave, siempre con el mismo formato:
//
//    tipo         llave                        nivel
//    ──────────   ──────────────────────────   ────────────────────────────────
//    modulo       clientes, catalogo, …        sin_acceso · ver · capturar · validar
//    pantalla     carteras, administradoras…   sin_acceso · ver · capturar · validar
//    accion       convertir_cliente, …         permitida · sin_acceso
//    cliente      area_comercial, area_…       sin_acceso · ver · capturar · validar
//    seguimiento  prospecto_asignar, …         permitida · sin_acceso
//
//  Aquí se traduce esa tabla al objeto que ya usaban las pantallas, y de
//  regreso. Nada más arriba ni más abajo de este bloque cambió.
// ───────────────────────────────────────────────────────────

const TABLA = "nivel_modulo";

type Fila = { rol: string; tipo: string; llave: string; nivel: string };

// ───────────────────────────────────────────────────────────
//  LECTURA COMPLETA (en páginas)
//
//  ⚠️ Supabase/PostgREST devuelve máximo 1000 renglones por consulta.
//  La tabla trae más de 3,500 (33 roles × 112 llaves), así que un
//  select pelón sólo traía el primer tercio. Con eso la pantalla creía
//  que el resto NO tenía permisos y al guardar los borraba.
//  Por eso se lee por páginas hasta que se acaben.
// ───────────────────────────────────────────────────────────
const TAM_PAGINA = 1000;

async function leerTodasLasFilas(): Promise<{ filas: Fila[]; error: boolean }> {
  const todas: Fila[] = [];
  for (let desde = 0; ; desde += TAM_PAGINA) {
    const { data, error } = await supabase
      .from(TABLA)
      .select("rol,tipo,llave,nivel")
      .order("rol", { ascending: true })
      .order("llave", { ascending: true })
      .range(desde, desde + TAM_PAGINA - 1);

    if (error) return { filas: [], error: true };

    const lote = ((data ?? []) as unknown as Fila[]) || [];
    todas.push(...lote);
    if (lote.length < TAM_PAGINA) break;
  }
  return { filas: todas, error: false };
}

// Lo que REALMENTE dice la base, llave por llave: "rol|llave" → nivel.
// Sirve para dos cosas: guardar sólo lo que cambió, y no bajarle el nivel
// a un módulo que estaba en "validar" o "ver".
let CRUDO: Record<string, string> = {};
// Mientras esto sea false, guardar está PROHIBIDO: no tenemos la foto
// completa de la base y escribir borraría lo que no alcanzamos a leer.
let CRUDO_COMPLETO = false;

export function permisosListosParaGuardar(): boolean {
  return CRUDO_COMPLETO;
}

// Los clientes se guardan con los mismos cuatro niveles que todo lo demás.
// Aquí se traducen a las palabras que ya usaba la pantalla.
const NIVEL_A_CLIENTE: Record<string, NivelCliente> = {
  sin_acceso: "ninguno",
  ver: "ver",
  capturar: "colaborador",
  validar: "editar",
};
const CLIENTE_A_NIVEL: Record<NivelCliente, string> = {
  ninguno: "sin_acceso",
  ver: "ver",
  colaborador: "capturar",
  editar: "validar",
};

// ───────────────────────────────────────────────────────────
//  CARGAR: arma la configuración leyendo la tabla.
//  Si la tabla no responde → modo SOLO LECTURA con la semilla del código.
// ───────────────────────────────────────────────────────────
export async function cargarPermisos(): Promise<{ config: PermisosConfig; sinTabla: boolean }> {
  const semilla = semillaDesdeCodigo();

  const { filas, error } = await leerTodasLasFilas();

  if (error) {
    CRUDO = {};
    CRUDO_COMPLETO = false;
    setPermisosCache(semilla as unknown as PermisosCache);
    return { config: semilla, sinTabla: true };
  }

  if (filas.length === 0) {
    // Tabla vacía DE VERDAD (la lectura sí respondió). No hay nada que
    // borrar, así que sí se puede guardar: es la única forma de poblarla
    // por primera vez desde la pantalla.
    CRUDO = {};
    CRUDO_COMPLETO = true;
    setPermisosCache(semilla as unknown as PermisosCache);
    return { config: semilla, sinTabla: false };
  }

  // Foto fiel de la base, antes de traducir nada.
  CRUDO = {};
  for (const f of filas) CRUDO[f.rol + "|" + f.llave] = f.nivel;
  CRUDO_COMPLETO = true;

  const modulos: Record<string, ModuloClave[]> = {};
  const acciones: Record<string, AccionClave[]> = {};
  const clientes: Record<string, Record<string, NivelCliente>> = {};
  const seguimiento: Record<string, SeguimientoRol> = {};

  for (const f of filas) {
    const rol = f.rol;

    if (f.tipo === "modulo") {
      if (!modulos[rol]) modulos[rol] = [];
      if (f.nivel !== "sin_acceso") modulos[rol].push(f.llave as ModuloClave);
      continue;
    }

    if (f.tipo === "accion") {
      if (!acciones[rol]) acciones[rol] = [];
      if (f.nivel === "permitida") acciones[rol].push(f.llave as AccionClave);
      continue;
    }

    if (f.tipo === "cliente") {
      if (!clientes[rol]) clientes[rol] = {};
      const area = f.llave.replace(/^area_/, "");
      clientes[rol][area] = NIVEL_A_CLIENTE[f.nivel] || "ninguno";
      continue;
    }

    if (f.tipo === "seguimiento") {
      if (!seguimiento[rol]) seguimiento[rol] = segVacio();
      const corte = f.llave.indexOf("_");
      const cual = f.llave.slice(0, corte) as "prospecto" | "cliente";
      const act = f.llave.slice(corte + 1) as ActividadSeg;
      if ((cual === "prospecto" || cual === "cliente") && ACTIVIDADES_SEG.includes(act)) {
        seguimiento[rol][cual][act] = f.nivel === "permitida";
      }
    }
    // tipo "pantalla" no entra aquí: lo maneja src/data/niveles.ts
  }

  // Un rol que esté en el código pero todavía no tenga renglones se rellena
  // con la semilla, para que aparezca en la pantalla y no se vea vacío.
  const final: PermisosConfig = {
    modulos: { ...semilla.modulos, ...modulos },
    acciones: { ...semilla.acciones, ...acciones },
    clientes: { ...semilla.clientes, ...clientes },
    seguimiento: { ...semilla.seguimiento, ...seguimiento },
  };

  setPermisosCache(final as unknown as PermisosCache);
  return { config: final, sinTabla: false };
}

// ───────────────────────────────────────────────────────────
//  GUARDAR: convierte la configuración en renglones y los escribe.
//  Se manda por tandas de 500 para no atorar la conexión.
// ───────────────────────────────────────────────────────────
export async function guardarPermisos(config: PermisosConfig, quien: string): Promise<boolean> {
  // CANDADO: sin la foto completa de la base, no se escribe nada.
  // Es exactamente lo que faltaba el 11-sep-2026: se guardó con una
  // lectura incompleta y se aplanaron los 33 roles de un golpe.
  if (!CRUDO_COMPLETO) {
    console.error(
      "Permisos: no se guarda porque la lectura de la tabla vino incompleta. Recarga la pantalla.",
    );
    return false;
  }

  const cuando = new Date().toISOString();
  const filas: Record<string, unknown>[] = [];

  // Sólo se manda el renglón cuando el nivel nuevo es DISTINTO del que ya
  // tiene la base. Lo que no tocaste, ni se toca.
  const anotar = (rol: string, tipo: string, llave: string, nivel: string) => {
    if (CRUDO[rol + "|" + llave] === nivel) return;
    filas.push({ rol, tipo, llave, nivel, actualizado_por: quien, actualizado_en: cuando });
  };

  for (const rol of Object.keys(config.modulos || {})) {
    const suyos = config.modulos[rol] || [];
    for (const m of TODOS_MODULOS) {
      if (!suyos.includes(m)) {
        anotar(rol, "modulo", m, "sin_acceso");
        continue;
      }
      // El switch sólo dice "prendido". Si en la base ya estaba en "ver" o
      // "validar", se respeta ese nivel: prender no debe degradarlo a capturar.
      const actual = CRUDO[rol + "|" + m];
      anotar(rol, "modulo", m, actual && actual !== "sin_acceso" ? actual : "capturar");
    }
  }

  for (const rol of Object.keys(config.acciones || {})) {
    const suyas = config.acciones[rol] || [];
    for (const a of TODAS_ACCIONES) {
      anotar(rol, "accion", a, suyas.includes(a) ? "permitida" : "sin_acceso");
    }
  }

  for (const rol of Object.keys(config.clientes || {})) {
    const fila = config.clientes[rol] || {};
    for (const ar of AREAS_PERMISOS) {
      const nivel = CLIENTE_A_NIVEL[(fila[ar.clave] as NivelCliente) || "ninguno"];
      anotar(rol, "cliente", "area_" + ar.clave, nivel);
    }
  }

  for (const rol of Object.keys(config.seguimiento || {})) {
    const s = config.seguimiento[rol] || segVacio();
    for (const cual of ["prospecto", "cliente"] as const) {
      for (const act of ACTIVIDADES_SEG) {
        anotar(rol, "seguimiento", cual + "_" + act, s[cual][act] ? "permitida" : "sin_acceso");
      }
    }
  }

  if (filas.length === 0) return true; // nada cambió: no se molesta a la base

  for (let i = 0; i < filas.length; i += 500) {
    const tanda = filas.slice(i, i + 500);
    const { error } = await supabase.from(TABLA).upsert(tanda, { onConflict: "rol,llave" });
    if (error) {
      console.error("No se pudieron guardar los permisos:", error.message);
      return false;
    }
  }

  // La foto de la base se actualiza con lo que acabamos de escribir.
  for (const f of filas) {
    CRUDO[String(f.rol) + "|" + String(f.llave)] = String(f.nivel);
  }

  // Refresca el caché en memoria → los cambios aplican de inmediato sin recargar.
  const payload: PermisosConfig = { ...config, actualizado_en: cuando, actualizado_por: quien };
  setPermisosCache(payload as unknown as PermisosCache);

  // Aviso al equipo (si falla, no rompe el guardado).
  try {
    await avisarEvento({
      tipo: "sistema",
      accion: "actualizado",
      titulo: "🔐 Roles y permisos actualizados",
      detalle: `${quien} ajustó el reglamento de accesos.`,
      autor: quien,
      modulo: "configuracion",
      icono: "🔐",
    });
  } catch {
    /* sin ruido */
  }

  return true;
}

// ───────────────────────────────────────────────────────────
//  MOTOR EN VIVO (Fase 2): para que la app OBEDEZCA lo guardado.
// ───────────────────────────────────────────────────────────

// Carga los permisos UNA vez y los deja en el caché. Idempotente.
let _iniciado = false;
export async function iniciarPermisos(): Promise<void> {
  if (_iniciado) return;
  _iniciado = true;
  try {
    await cargarPermisos(); // ya deja todo en el caché
  } catch {
    /* si falla, los módulos siguen con los valores del código */
  }
}

// Hook para componentes: dispara la carga y re-renderiza cuando el caché cambia.
export function usePermisos(): number {
  const [v, setV] = useState(getPermisosVersion());
  useEffect(() => {
    iniciarPermisos();
    return suscribirPermisos(() => setV(getPermisosVersion()));
  }, []);
  return v;
}

// ¿Este rol puede esta ACCIÓN? (según lo guardado; null = todavía no hay caché)
export function accionPermitida(rol: string | null | undefined, accion: AccionClave): boolean | null {
  const c = getPermisosCache();
  if (!c || !rol) return null;
  const lista = c.acciones[rol];
  if (!lista) return null;
  return lista.includes(accion);
}

// Nivel del rol sobre los CLIENTES de un área. Si no hay caché, "editar"
// (permisivo = mismo comportamiento que hoy, para no romper nada).
export function nivelCliente(rol: string | null | undefined, area: string): NivelCliente {
  const c = getPermisosCache();
  if (!c || !rol) return "editar";
  const fila = c.clientes[rol];
  if (!fila) return "editar";
  return (fila[area] as NivelCliente) || "ninguno";
}

// ¿Puede esta actividad de seguimiento, según sea prospecto o cliente?
// Sin caché → true (permisivo).
export function puedeSeguimiento(
  rol: string | null | undefined,
  tipo: "prospecto" | "cliente",
  act: ActividadSeg
): boolean {
  const c = getPermisosCache();
  if (!c || !rol) return true;
  const s = c.seguimiento[rol];
  if (!s || !s[tipo]) return true;
  return !!s[tipo][act];
}
// Mapa: área de la columna `area` del CLIENTE → área de empresa (la de Roles y Permisos).
//   Comercial → comercial · Jurídico/UFC → juridico · RAC → atencion · Admin → contabilidad
const AREA_CLIENTE_A_EMPRESA: Record<string, string> = {
  Comercial: "comercial",
  "Jurídico": "juridico",
  UFC: "juridico",
  RAC: "atencion",
  Admin: "contabilidad",
};

// Nivel del rol sobre un cliente, recibiendo el área TAL CUAL viene del cliente
// (Comercial/Jurídico/RAC/Admin/UFC). Hace el mapeo por dentro.
export function nivelClienteArea(rol: string | null | undefined, areaCliente: string): NivelCliente {
  const empresa = AREA_CLIENTE_A_EMPRESA[areaCliente] || "comercial";
  return nivelCliente(rol, empresa);
}
// Fase 2B: qué MÓDULOS del menú ve este rol, según lo guardado en Roles y Permisos.
// Si todavía no hay caché (o el rol no está), usamos lo del código (modulosDeRol).
export function modulosVisibles(rol: string | null | undefined): ModuloClave[] {
  // La tabla manda, también para la Dirección. Antes había aquí una regla que
  // les daba TODOS los módulos a DGE, Super_Admin y DTR sin consultar nada, y
  // por eso la pantalla de Roles y Permisos decía 13 mientras de verdad veían 16.
  const c = getPermisosCache();
  if (c && rol && c.modulos[rol]) return c.modulos[rol] as ModuloClave[];
  // Todavía sin caché (primer segundo de la sesión): lo del código, para no
  // dejar la pantalla en blanco mientras carga.
  return modulosDeRol(rol);
}
// SQL de la tabla única, por si hay que rehacerla desde cero.
export const SQL_TABLA = `create table if not exists public.nivel_modulo (
  rol             text not null references public.catalogo_roles(codigo) on update cascade,
  tipo            text not null check (tipo in ('modulo','pantalla','accion','cliente','seguimiento')),
  llave           text not null,
  nivel           text not null check (nivel in ('sin_acceso','ver','capturar','validar','permitida')),
  actualizado_por text,
  actualizado_en  timestamptz default now(),
  primary key (rol, llave)
);

alter table public.nivel_modulo enable row level security;

create policy niveles_lectura on public.nivel_modulo
  for select to authenticated using (true);

create policy niveles_escritura on public.nivel_modulo
  for all to authenticated
  using (public.fn_mi_rol() in ('DGE','Super_Admin','DTR'))
  with check (public.fn_mi_rol() in ('DGE','Super_Admin','DTR'));`;
