// Documentos de la demanda (varios) → src/data/documentosDemanda.ts
import { supabase } from "../lib/supabase";

export type DocumentoDemanda = {
  id: string;
  clienteId: string;
  nombre: string;
  url: string;
  autor: string | null;
  createdAt: string;
};

export async function fetchDocumentosDemanda(clienteId: string): Promise<DocumentoDemanda[]> {
  const { data, error } = await supabase
    .from("documento_demanda")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data.map((r: any) => ({
    id: r.id, clienteId: r.cliente_id, nombre: r.nombre || "", url: r.url || "", autor: r.autor, createdAt: r.created_at,
  }));
}

export async function agregarDocumentoDemanda(a: { clienteId: string; nombre: string; url: string; autor?: string | null }): Promise<DocumentoDemanda | null> {
  const { data, error } = await supabase
    .from("documento_demanda")
    .insert({ cliente_id: a.clienteId, nombre: a.nombre, url: a.url, autor: a.autor || null })
    .select("*")
    .single();
  if (error || !data) return null;
  return { id: data.id, clienteId: data.cliente_id, nombre: data.nombre || "", url: data.url || "", autor: data.autor, createdAt: data.created_at };
}

export async function borrarDocumentoDemanda(id: string): Promise<boolean> {
  const { error } = await supabase.from("documento_demanda").delete().eq("id", id);
  return !error;
}
