import { supabase } from "../lib/supabase";

// El "perfil" es lo que sabemos de la persona que inició sesión.
export type Perfil = {
  email: string;
  nombre: string;
  rol: string;
  area: string | null;
};

// Busca en la tabla `usuarios` la fila cuyo correo coincide con el del login.
export async function fetchPerfil(email: string): Promise<Perfil | null> {
  const correo = (email || "").trim().toLowerCase();
  if (!correo) return null;

  const { data, error } = await supabase
    .from("usuarios")
    .select("email, nombre, rol, area, activo")
    .eq("email", correo)
    .maybeSingle();

  if (error || !data) return null;     // no hay fila para ese correo
  if (data.activo === false) return null;

  return {
    email: data.email,
    nombre: data.nombre,
    rol: data.rol,
    area: data.area ?? null,
  };
}

// Busca el correo de la primera persona ACTIVA con un rol dado (p. ej. "DIL").
export async function fetchCorreoPorRol(rol: string): Promise<{ email: string; nombre: string } | null> {
  const { data, error } = await supabase
    .from("usuarios")
    .select("email, nombre, activo")
    .eq("rol", rol)
    .maybeSingle();
  if (error || !data || data.activo === false || !data.email) return null;
  return { email: data.email, nombre: data.nombre || "" };
}

// Busca el correo de una persona por su nombre (para el abogado encargado, que se captura por nombre).
export async function fetchCorreoPorNombre(nombre: string): Promise<{ email: string; nombre: string } | null> {
  const n = (nombre || "").trim();
  if (!n) return null;
  const { data, error } = await supabase
    .from("usuarios")
    .select("email, nombre, activo")
    .ilike("nombre", n)
    .maybeSingle();
  if (error || !data || data.activo === false || !data.email) return null;
  return { email: data.email, nombre: data.nombre || "" };
}
