import { supabase } from "../lib/supabase";
import { avisarEvento } from "./avisarEvento"; // 👈 NUEVO

export type Reunion = {
  id: string;
  titulo: string | null;
  sala: string;
  url: string;
  tipo: string;        // 'interna' | 'cliente'
  creado_por: string | null;
  destino: string | null;
  created_at: string;
  archivado?: boolean;
  eliminado?: boolean;
  // 👇 NUEVO (Fase 2 · notas con IA)
  transcripcion?: string | null;  // lo que se fue hablando (texto crudo)
  notas?: string | null;          // el resumen que arma la IA
  notas_at?: string | null;       // cuándo se generaron las notas
};

function slug(s: string): string {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

// 👇 NUEVO: quién está usando la app (usa el dato explícito si llega, si no, el de la sesión).
function quienSoy(explicito?: string | null): string {
  if (explicito && explicito.trim()) return explicito.trim();
  try {
    const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
    return y?.nombre || "Alguien";
  } catch { return "Alguien"; }
}

// Crea el nombre de sala + el enlace PROPIO de JurisConecta (código al azar = secreto).
// El enlace abre la videollamada NATIVA: la página pública lee ?sala=… y monta el video.
// Usamos window.location.origin para que funcione en cualquier dominio (y al revender).
export function generarSala(base?: string): { sala: string; url: string } {
  const limpio = (base ? slug(base) : "sala").slice(0, 24) || "sala";
  const rnd = Math.random().toString(36).slice(2, 8);
  const sala = `JurisConecta-${limpio}-${rnd}`;
  const origin = typeof window !== "undefined" ? window.location.origin : "https://jurisconecta.netlify.app";
  return { sala, url: `${origin}/?sala=${encodeURIComponent(sala)}` };
}

// Crea la reunión y la guarda en el registro
export async function crearReunion(p: {
  titulo?: string;
  tipo: "interna" | "cliente";
  creadoPor?: string;
  destino?: string;
}): Promise<Reunion | null> {
  const { sala, url } = generarSala(p.destino || p.titulo || p.tipo);
  const { data, error } = await supabase
    .from("reuniones")
    .insert({
      titulo: p.titulo ?? null,
      sala,
      url,
      tipo: p.tipo,
      creado_por: p.creadoPor ?? null,
      destino: p.destino ?? null,
    })
    .select().single();
  if (error) { console.error("No se pudo crear la reunión:", error.message); return null; }
  const reunion = data as Reunion; // 👈 NUEVO

  // 👇 NUEVO: avisa a TODOS que se creó una videollamada.
  const yo = quienSoy(p.creadoPor);
  const nombre = p.titulo || p.destino || (p.tipo === "cliente" ? "con cliente" : "interna");
  avisarEvento({
    tipo: "reunion",
    accion: "creada",
    titulo: `🎥 Videollamada: ${nombre}`,
    detalle: yo === "Alguien" ? "Se creó una videollamada" : `La creó ${yo}`,
    autor: yo,
    modulo: "videollamadas",
    refId: String(reunion.id),
    meta: { url: reunion.url, sala: reunion.sala, tipo: reunion.tipo },
  });

  return reunion;
}

// Trae las reuniones recientes (para el historial)
export async function fetchReuniones(): Promise<Reunion[]> {
  const { data, error } = await supabase
    .from("reuniones")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(60);
  if (error) { console.error("No se pudieron traer las reuniones:", error.message); return []; }
  // Trae activas + archivadas (las archivadas se separan en la pantalla). Esconde solo las de papelera.
  return ((data || []) as Reunion[]).filter((r) => !r.eliminado);
}

// Archiva (valor=true) o desarchiva (valor=false) una videollamada.
// Pedimos .select() para CONFIRMAR que el cambio sí se guardó: si un permiso
// (RLS) lo bloquea en silencio, "data" llega vacío y devolvemos false (no
// fingimos éxito). Así la pantalla no engaña al usuario.
export async function archivarReunion(id: string, valor: boolean): Promise<boolean> {
  const { data, error } = await supabase.from("reuniones").update({ archivado: valor }).eq("id", id).select("id");
  if (error) { console.error("No se pudo archivar la reunión:", error.message); return false; }
  return Array.isArray(data) && data.length > 0;
}

// Manda la videollamada a la papelera (valor=true) o la restaura (valor=false). NO borra de la base.
// Mismo candado: solo decimos "ok" si DE VERDAD se guardó el cambio en la base.
export async function eliminarReunion(id: string, valor: boolean): Promise<boolean> {
  const { data, error } = await supabase.from("reuniones").update({ eliminado: valor }).eq("id", id).select("id");
  if (error) { console.error("No se pudo enviar a papelera la reunión:", error.message); return false; }
  return Array.isArray(data) && data.length > 0;
}

// Borrado DEFINITIVO de la videollamada: sí la saca de la base. No se puede deshacer.
export async function borrarReunionDefinitivo(id: string): Promise<boolean> {
  const { error } = await supabase.from("reuniones").delete().eq("id", id);
  return !error;
}

// Trae las videollamadas que están en la papelera (para la pantalla de Papelera).
export async function fetchReunionesEliminadas(): Promise<Reunion[]> {
  const { data, error } = await supabase.from("reuniones").select("*").eq("eliminado", true).order("created_at", { ascending: false }).limit(100);
  if (error) { console.error("No se pudieron traer las videollamadas eliminadas:", error.message); return []; }
  return (data || []) as Reunion[];
}

// =====================================================================
//  FASE 2 · NOTAS CON IA
// =====================================================================

// Le pide a TU Gemini (función gemini.mjs ya existente) que convierta la
// transcripción de la junta en notas ordenadas. La llave vive en Netlify,
// nunca en el navegador. Devuelve el texto de las notas.
export async function generarNotasIA(transcripcion: string): Promise<string> {
  const limpio = (transcripcion || "").trim();
  if (!limpio) return "";
  const prompt =
`Actúa como secretario(a) de la junta. A partir de la SIGUIENTE transcripción de una videollamada, redacta notas claras y ordenadas en español de México, con estas secciones:
1) Resumen breve
2) Temas tratados
3) Acuerdos
4) Pendientes / tareas (anota responsable y fecha si se mencionan)
5) Próximos pasos

Reglas: si un dato NO quedó claro en la transcripción, NO lo inventes; escríbelo como "(no quedó claro)". Sé conciso y útil.

TRANSCRIPCIÓN:
${limpio}`;

  const r = await fetch("/.netlify/functions/gemini", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mensajes: [{ rol: "user", texto: prompt }] }),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((data && data.error) || "No se pudo generar las notas.");
  return String((data && data.texto) || "").trim();
}

// Guarda la transcripción y/o las notas de una reunión (la ubica por su 'sala').
// Igual que el borrado: confirma con .select() que SÍ se guardó.
export async function guardarNotasReunion(
  sala: string,
  p: { transcripcion?: string; notas?: string }
): Promise<boolean> {
  const patch: Record<string, unknown> = { notas_at: new Date().toISOString() };
  if (p.transcripcion !== undefined) patch.transcripcion = p.transcripcion;
  if (p.notas !== undefined) patch.notas = p.notas;
  const { data, error } = await supabase.from("reuniones").update(patch).eq("sala", sala).select("id");
  if (error) { console.error("No se pudieron guardar las notas:", error.message); return false; }
  return Array.isArray(data) && data.length > 0;
}
