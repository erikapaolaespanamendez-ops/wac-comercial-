import { supabase } from "../lib/supabase";

// =====================================================================
//  EQUIPO (Directorio)  —  datos desde Supabase.
// =====================================================================

export type Presencia = "disponible" | "ocupado" | "ausente";

export interface Persona {
  ext: string;
  nombre: string;
  puesto: string;
  presencia: Presencia;
  telefono: string;
  email: string;
}

export interface Area {
  clave: string;
  nombre: string;
  personas: Persona[];
}

interface FilaEquipo {
  ext: string;
  nombre: string;
  puesto: string;
  area: string;
  presencia: string;
  orden: number;
  telefono: string | null;
  email: string | null;
}

// Trae el equipo de Supabase y lo agrupa por área (en orden).
export async function fetchEquipo(): Promise<Area[]> {
  const { data, error } = await supabase
    .from("equipo")
    .select("ext, nombre, puesto, area, presencia, orden, telefono, email")
    .order("orden", { ascending: true });

  if (error) throw error;

  const filas = (data ?? []) as FilaEquipo[];
  const areas: Area[] = [];

  for (const f of filas) {
    let grupo = areas.find((a) => a.nombre === f.area);
    if (!grupo) {
      grupo = { clave: f.area, nombre: f.area, personas: [] };
      areas.push(grupo);
    }
    grupo.personas.push({
      ext: f.ext,
      nombre: f.nombre,
      puesto: f.puesto,
      presencia: (["disponible", "ocupado", "ausente"].includes(f.presencia)
        ? f.presencia
        : "ausente") as Presencia,
      telefono: f.telefono ?? "",
      email: f.email ?? "",
    });
  }

  return areas;
}
