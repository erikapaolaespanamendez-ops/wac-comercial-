import { supabase } from "../lib/supabase";
import { avisarEvento } from "./avisarEvento"; // 👈 NUEVO

export type Colaborador = {
  id: string;
  nombre: string;
  puesto: string | null;
  area: string | null;
  extension: string | null;
  telefono: string | null;
  whatsapp: string | null;
  correo: string | null;
  foto_url: string | null;
  numero_oficial: string | null;
  rol_sistema: string | null;
  rol_telefonia: string | null;
  activo: boolean;
  orden: number;
  created_at: string;
  expediente_url?: string | null; // 👈 NUEVO: link de su carpeta/ficha en Drive
  alterno_id?: string | null;     // 👈 NUEVO (Fase 3): quién lo cubre (id de otro colaborador)
  // 👇 NUEVO (10-sep-2026): 'interno' = personal de DIIPA; 'abogado_externo' = despacho de fuera.
  //    Ya existía en la base; faltaba declararlo aquí para poder filtrarlo.
  tipo_personal?: string | null;
};

// 👇 NUEVO: quién está usando la app (para decir quién hizo el cambio).
function quienSoy(): string {
  try {
    const y = JSON.parse(localStorage.getItem("chat_yo") || "null");
    return y?.nombre || "Alguien";
  } catch { return "Alguien"; }
}

// Traer todos (ordenados)
export async function fetchColaboradores(): Promise<Colaborador[]> {
  const { data, error } = await supabase
    .from("colaboradores")
    .select("*")
    .order("orden", { ascending: true })
    .order("nombre", { ascending: true });
  if (error) {
    console.error("No se pudieron traer los colaboradores:", error.message);
    return [];
  }
  return (data || []) as Colaborador[];
}

// Crear uno nuevo
export async function crearColaborador(p: Partial<Colaborador>): Promise<Colaborador | null> {
  const { data, error } = await supabase
    .from("colaboradores")
    .insert({
      nombre: p.nombre,
      puesto: p.puesto ?? null,
      area: p.area ?? null,
      extension: p.extension ?? null,
      telefono: p.telefono ?? null,
      whatsapp: p.whatsapp ?? null,
      correo: p.correo ?? null,
      foto_url: p.foto_url ?? null,
      numero_oficial: p.numero_oficial ?? null,
      rol_sistema: p.rol_sistema ?? "colaborador",
      rol_telefonia: p.rol_telefonia ?? null,
      activo: p.activo ?? true,
      orden: p.orden ?? 100,
    })
    .select()
    .single();
  if (error) {
    console.error("No se pudo crear el colaborador:", error.message);
    return null;
  }
  const creado = data as Colaborador; // 👈 NUEVO

  // 👇 NUEVO: avisa a TODOS que se agregó un integrante al equipo.
  const yo = quienSoy();
  avisarEvento({
    tipo: "colaborador",
    accion: "creado",
    titulo: `👥 Nuevo integrante: ${creado.nombre}`,
    detalle: [creado.puesto, creado.area].filter(Boolean).join(" · ") || (yo === "Alguien" ? "Se agregó al equipo" : `Lo agregó ${yo}`),
    autor: yo,
    modulo: "directorio",
    refId: String(creado.id),
  });

  return creado;
}

// Editar uno
export async function editarColaborador(id: string, cambios: Partial<Colaborador>): Promise<boolean> {
  const { error } = await supabase.from("colaboradores").update(cambios).eq("id", id);
  if (error) {
    console.error("No se pudo editar el colaborador:", error.message);
    return false;
  }

  // 👇 NUEVO: avisa a TODOS que se actualizaron los datos de un integrante.
  const { data: row } = await supabase.from("colaboradores").select("nombre").eq("id", id).maybeSingle();
  const nombre = (cambios.nombre as string) || row?.nombre || "un integrante";
  const yo = quienSoy();
  avisarEvento({
    tipo: "colaborador",
    accion: "actualizado",
    titulo: `👥 Integrante actualizado: ${nombre}`,
    detalle: yo === "Alguien" ? "Se editaron sus datos" : `Lo editó ${yo}`,
    autor: yo,
    modulo: "directorio",
    refId: id,
  });

  return true;
}

// Borrar uno
export async function borrarColaborador(id: string): Promise<boolean> {
  // 👇 NUEVO: traemos el nombre ANTES de borrarlo (después ya no estará).
  const { data: row } = await supabase.from("colaboradores").select("nombre").eq("id", id).maybeSingle();
  const nombre = row?.nombre || "un integrante";

  const { error } = await supabase.from("colaboradores").delete().eq("id", id);
  if (error) {
    console.error("No se pudo borrar el colaborador:", error.message);
    return false;
  }

  // 👇 NUEVO: avisa a TODOS que se quitó un integrante.
  const yo = quienSoy();
  avisarEvento({
    tipo: "colaborador",
    accion: "borrado",
    titulo: `👥 Integrante eliminado: ${nombre}`,
    detalle: yo === "Alguien" ? "Se quitó del equipo" : `Lo quitó ${yo}`,
    autor: yo,
    modulo: "directorio",
    refId: id,
  });

  return true;
}

// Subir la foto oficial
export async function subirFotoColaborador(file: File): Promise<string | null> {
  const ext = file.name.split(".").pop() || "jpg";
  const ruta = `colaboradores/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage
    .from("chat-archivos")
    .upload(ruta, file, { cacheControl: "3600", upsert: false });
  if (error) {
    console.error("No se pudo subir la foto:", error.message);
    return null;
  }
  const { data } = supabase.storage.from("chat-archivos").getPublicUrl(ruta);
  return data.publicUrl;
}
