// Catálogo oficial de roles y permisos de DIIPA (editable, ninguno inmutable)

import { getPermisosCache } from "./permisosCache";

export type ModuloClave =
  | "asistente" | "chat" | "directorio" | "conmutador"
  | "videollamadas" | "llamadas" | "kpis" | "clientes" | "configuracion" | "catalogo" | "seguimiento" | "chatcliente" | "milista" | "prospectos" | "devoluciones" | "comercial";

export const TODOS_MODULOS: ModuloClave[] = [
  "asistente", "chat", "directorio", "conmutador",
  "videollamadas", "llamadas", "kpis", "clientes", "configuracion", "catalogo", "seguimiento", "chatcliente", "milista", "prospectos", "devoluciones", "comercial",
];

// SUCURSALES / ZONAS de DIIPA (para comercial y conmutador)
export const SUCURSALES = [
  { clave: "GDL", nombre: "Guadalajara" },
  { clave: "MAZ", nombre: "Mazatlán" },
  { clave: "CUL", nombre: "Culiacán" },
  { clave: "LAP", nombre: "La Paz" },
];

export const GRUPOS_ROLES = [
  { clave: "SIS", nombre: "Sistema", emoji: "🩶" },
  { clave: "DGE", nombre: "Dirección", emoji: "🟦" },
  { clave: "DGC", nombre: "Comercial", emoji: "🟩" },
  { clave: "MKT", nombre: "Marketing", emoji: "🟨" },
  { clave: "DIL", nombre: "Jurídico", emoji: "🟪" },
  { clave: "GAD", nombre: "Administración", emoji: "🟧" },
  { clave: "RAC", nombre: "Atención al Cliente", emoji: "🟥" },
  { clave: "DTR", nombre: "Tecnología", emoji: "🩷" },
];

export type DefinicionRol = {
  codigo: string;
  nombre: string;
  grupo: string;
  modulos: ModuloClave[] | "todos";
};

// Sets reutilizables (para ajustar fácil)
const COMERCIAL: ModuloClave[] = ["asistente", "chat", "directorio", "clientes", "conmutador", "llamadas", "videollamadas", "seguimiento", "chatcliente", "milista", "prospectos", "comercial"];
const GERENTE_COM: ModuloClave[] = [...COMERCIAL, "kpis"]; // gerentes: ven KPIs de su equipo
const LEGAL: ModuloClave[] = ["asistente", "chat", "directorio", "clientes", "llamadas", "seguimiento", "milista"];
// 👇 CONTROL DE DEVOLUCIONES (25/ago/2026). Regla de Paola: solo lo ven
//    Atención (RAC, Sub-RAC y telefonista), Administración con manejo de dinero
//    (GAD, Facturación, Cobros y Pagos), el Director Comercial y Dirección.
//    Por eso hay dos versiones de cada juego de módulos: con y sin "devoluciones".
const ADMIN: ModuloClave[] = ["asistente", "chat", "directorio", "clientes", "seguimiento", "milista", "devoluciones"];
const ADMIN_SIN_DEV: ModuloClave[] = ADMIN.filter((m) => m !== "devoluciones");
// Secretarías comerciales y de GAD: YA NO ven Control de Devoluciones.
const SECRETARIA: ModuloClave[] = ["asistente", "chat", "directorio", "conmutador", "llamadas", "seguimiento", "milista"];
// Secretarías de Atención (Sub-RAC y telefonista): estas SÍ lo ven.
const SECRETARIA_ATENCION: ModuloClave[] = [...SECRETARIA, "devoluciones"];
const ATENCION: ModuloClave[] = ["asistente", "chat", "directorio", "conmutador", "llamadas", "videollamadas", "clientes", "seguimiento", "chatcliente", "milista", "devoluciones"];
const MARKETING: ModuloClave[] = ["asistente", "chat", "directorio", "clientes"];

export const ROLES: DefinicionRol[] = [
  // 🩶 Sistema
  { codigo: "Super_Admin", nombre: "Super Admin (DGE + Tecnología)", grupo: "SIS", modulos: "todos" },
  { codigo: "Colaborador", nombre: "Colaborador (genérico)", grupo: "SIS", modulos: ["asistente", "chat", "directorio", "llamadas"] },
  { codigo: "Invitado", nombre: "Invitado", grupo: "SIS", modulos: ["chat", "directorio"] },

  // 🟦 Dirección
  { codigo: "DGE", nombre: "Dirección General (Administradora Única)", grupo: "DGE", modulos: "todos" },

  // 🟩 Comercial
  { codigo: "DGC", nombre: "Dirección Comercial", grupo: "DGC", modulos: [...COMERCIAL, "kpis", "catalogo", "devoluciones"] },
  { codigo: "GRS_Nacional", nombre: "Gerencia Ventas de Proyectos", grupo: "DGC", modulos: GERENTE_COM },
  // 👇 GRC ya NO ve Control de Devoluciones (decisión de Paola, 25/ago/2026).
  //    Conserva sus permisos de RDC (solicitar_terminos_rdc, llenar_datos_sucursal_rdc,
  //    solicitar_devolucion_formal), que se usan desde la ficha del cliente.
  { codigo: "GRC", nombre: "Gerente Remates y Contingencias", grupo: "DGC", modulos: GERENTE_COM },
  { codigo: "GL_GDL", nombre: "Gerente Local Guadalajara", grupo: "DGC", modulos: GERENTE_COM },
  { codigo: "GL_CUL", nombre: "Gerente Local Culiacán", grupo: "DGC", modulos: GERENTE_COM },
  { codigo: "GL_LAP", nombre: "Gerente Local La Paz", grupo: "DGC", modulos: GERENTE_COM },
  { codigo: "GL_MAZ", nombre: "Gerente Local Mazatlán", grupo: "DGC", modulos: GERENTE_COM },
  { codigo: "SUBGERENTE", nombre: "Subgerente Comercial", grupo: "DGC", modulos: COMERCIAL },
  { codigo: "ASE", nombre: "Asesor comercial (comisionista CFDI/RESICO)", grupo: "DGC", modulos: COMERCIAL },
  { codigo: "SDC", nombre: "Secretaria General (Gerente de Secretarías)", grupo: "DGC", modulos: SECRETARIA },
  { codigo: "SS", nombre: "Secretaria de Sucursal (Mesa de Control)", grupo: "DGC", modulos: SECRETARIA },

  // 🟨 Marketing
  { codigo: "MKT", nombre: "Marketing", grupo: "MKT", modulos: MARKETING },

  // 🟪 Jurídico
  { codigo: "DIL", nombre: "Dirección Jurídica (cubre URRJ)", grupo: "DIL", modulos: [...LEGAL, "conmutador", "videollamadas", "kpis", "catalogo"] },
  { codigo: "URRJ", nombre: "Unidad Revisión y Riesgo Jurídico (pre-dictamen)", grupo: "DIL", modulos: LEGAL },
  { codigo: "UCP", nombre: "Unidad UCP", grupo: "DIL", modulos: LEGAL },
  { codigo: "UCM", nombre: "Unidad UCM", grupo: "DIL", modulos: LEGAL },
  { codigo: "UDP", nombre: "Unidad UDP", grupo: "DIL", modulos: LEGAL },
  { codigo: "UFC", nombre: "Unidad UFC", grupo: "DIL", modulos: LEGAL },

  // 🟧 Administración
  { codigo: "GAD", nombre: "Gerencia Administrativa", grupo: "GAD", modulos: [...ADMIN, "kpis", "conmutador", "configuracion", "catalogo"] },
  { codigo: "UFF_Fact", nombre: "Facturación", grupo: "GAD", modulos: ADMIN },
  { codigo: "UFF_Cobros", nombre: "Cobros", grupo: "GAD", modulos: ADMIN },
  { codigo: "UFF_Pagos", nombre: "Pagos", grupo: "GAD", modulos: ADMIN },
  { codigo: "ASIS_CONT", nombre: "Asistente Contable", grupo: "GAD", modulos: ADMIN_SIN_DEV },
  { codigo: "SEC_GAD", nombre: "Secretaria de Gerencia Administrativa (registro)", grupo: "GAD", modulos: SECRETARIA },

  // 🟥 Atención al Cliente
  { codigo: "RAC", nombre: "Atención al Cliente", grupo: "RAC", modulos: [...ATENCION, "kpis", "catalogo"] },
  { codigo: "SRAC", nombre: "Sub-RAC / Secretaría de atención", grupo: "RAC", modulos: SECRETARIA_ATENCION },
  { codigo: "ATC", nombre: "Telefonista primer contacto", grupo: "RAC", modulos: SECRETARIA_ATENCION },

  // 🩷 Tecnología
  { codigo: "DTR", nombre: "Dirección de Tecnología", grupo: "DTR", modulos: "todos" },
];

export function modulosDeRol(codigo: string | null | undefined): ModuloClave[] {
  const r = ROLES.find((x) => x.codigo === codigo);
  if (!r) return ["asistente", "chat", "directorio", "llamadas"]; // por defecto, lo básico
  return r.modulos === "todos" ? TODOS_MODULOS : r.modulos;
}

export function puedeVer(rol: string | null | undefined, modulo: ModuloClave): boolean {
  return modulosDeRol(rol).includes(modulo);
}

// ¿Este rol tiene acceso "todos"? (Super_Admin, DGE, DTR). Si es así, SIEMPRE ve todos
// los módulos, incluso los nuevos, sin importar lo que tenga guardado el caché de permisos.
export function rolVeTodo(codigo: string | null | undefined): boolean {
  return ROLES.find((x) => x.codigo === codigo)?.modulos === "todos";
}

// ───────────────────────────────────────────────────────────
// PERMISOS POR ACCIÓN (granular)
// ───────────────────────────────────────────────────────────
export type AccionClave =
  // Modulo Comercial · ficha de garantia (una por pestana, 10-sep-2026)
  | "cartera_editar"
  | "gar_editar_general"
  | "gar_editar_caracteristicas"
  | "gar_editar_ubicacion"
  | "gar_editar_origen"
  | "gar_editar_precios"
  | "gar_capturar_avaluo"
  | "gar_editar_legal"
  | "gar_fotos_subir"
  | "gar_fotos_organizar"
  | "gar_descargar_ficha"
  | "gar_ver_descuentos"
  | "gar_pedir_apertura_promociones"
  | "gar_mandar_predictamen"
  | "precio_calcular"
  | "precio_recalcular"
  | "precio_definir_venta"
  | "precio_validar"
  | "promo_validar_apertura"
  | "exportar_bitacora"
  | "clientes_gestionar"
  | "config_colaboradores"
  | "aprobar_accesos"
  | "generar_exp_colaborador"
  | "generar_exp_cliente"
  | "catalogo_editar"
  | "asignar_asesor"   | "convertir_cliente"
  | "editar_permisos" | "ver_papelera" | "borrar_definitivo" | "borrar_colaborador"
  | "enviar_papelera" | "restaurar" | "archivar"
  | "cambiar_codigo" | "compartir_cliente" | "actualizar_vencido"
  | "registrar_llamada" | "gestionar_llamada" | "crear_videollamada" | "crear_grupo_chat" | "administrar_grupo"
  | "gestionar_actuaciones" | "gestionar_convenio_contingencia" | "gestionar_juicio"
  | "prospectos_crear" | "prospectos_asignar" | "prospectos_gestionar" | "prospectos_borrar"
  | "registrar_abono" | "editar_abono" | "borrar_abono"
  | "solicitar_compensacion" | "habilitar_compensacion" | "solicitar_terminos_rdc"
  | "solicitar_devolucion_formal" | "llenar_datos_sucursal_rdc"
  | "terminar_caso"
  | "editar_ficha" | "subir_devolucion" | "subir_documentos" | "docs_criticos" | "agregar_nota" | "gestionar_tareas" | "redactar_correo"
  | "ver_exp_ficha" | "ver_exp_expediente" | "ver_exp_llamadas" | "ver_exp_correos" | "ver_exp_notas"
  | "ver_exp_tareas" | "ver_exp_actuaciones" | "ver_exp_legal" | "ver_exp_cronologia";

// Directores de cada área (+ sistema)
const DIRECTORES = ["Super_Admin", "DGE", "DGC", "DIL", "GAD", "RAC", "DTR"];
// Gerentes comerciales (manejan equipo)
const GERENTES = ["GRS_Nacional", "GRC", "GL_GDL", "GL_CUL", "GL_LAP", "GL_MAZ"];
// Roles de Comercial + Admin + Atención (para gestionar clientes; Jurídico NO)
const GESTORES_CLIENTE = [
  "Super_Admin", "DGE", "DTR",
  "DGC", "GRS_Nacional", "GRC", "GL_GDL", "GL_CUL", "GL_LAP", "GL_MAZ", "SUBGERENTE", "SDC", "SS",
  "GAD", "UFF_Fact", "UFF_Cobros", "UFF_Pagos", "ASIS_CONT", "SEC_GAD",
  "RAC", "SRAC", "ATC",
];

// Todos los roles operativos (todos menos Invitado). Default permisivo para
// acciones del día a día (Nivel 2-A): que nada deje de funcionar para quien hoy lo hace.
const OPERATIVOS = ROLES.map((r) => r.codigo).filter((c) => c !== "Invitado");
// 👇 DOCUMENTOS CRÍTICOS del expediente del cliente: contrato, carta propuesta,
//    dictamen jurídico, dictamen registral y cuentas para pagos (más sus gemelos
//    "de cambio"). Quien NO tenga este permiso ve esas tarjetas en gris: no puede
//    subir archivos, ni cambiar el estado (p. ej. poner un dictamen en Positivo),
//    ni editar valores, plazo o términos, ni quitar archivos.
//    Regla de Paola (25/ago/2026): lo pueden tocar TODOS los puestos MENOS el
//    asesor comercial y Marketing. La telefonista (ATC) SÍ sube y valida.
//    Se afina después desde Configuración → Roles y Permisos, sin tocar código.
const SIN_DOCS_CRITICOS = ["ASE", "MKT", "Colaborador", "Invitado"];
const DOCS_CRITICOS = ROLES.map((r) => r.codigo).filter((c) => !SIN_DOCS_CRITICOS.includes(c));

// CRM Prospectos: quién opera leads (incluye al nuevo Asesor), quién reparte/asigna.
// Comercial de plaza: gerentes locales, subgerente y gerente de secretarias.
const COMERCIAL_PLAZA = ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC", "SUBGERENTE", "GL_GDL", "GL_CUL", "GL_MAZ", "GL_LAP"];

const PROSPECTOS_GESTIONA = ["Super_Admin", "DGE", "DGC", ...GERENTES, "SUBGERENTE", "ASE"];
const PROSPECTOS_REPARTE = ["Super_Admin", "DGE", "DGC", "SDC", ...GERENTES];
const PROSPECTOS_CREA = ["Super_Admin", "DGE", "DGC", ...GERENTES, "SUBGERENTE", "ASE", "SDC"];

const PERMISOS_ACCION: Record<AccionClave, string[]> = {
  // ── Modulo Comercial · ficha de garantia ──
  // Estos son solo la semilla del codigo. Lo que manda es la tabla
  // nivel_modulo, que se edita en Configuracion > Roles y Permisos.
  cartera_editar: ["Super_Admin", "DGE", "DTR", "GAD", "RAC"],
  gar_editar_general: COMERCIAL_PLAZA,
  gar_editar_caracteristicas: COMERCIAL_PLAZA,
  gar_editar_ubicacion: [...COMERCIAL_PLAZA, "SS"],
  gar_editar_origen: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  gar_editar_precios: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  gar_capturar_avaluo: COMERCIAL_PLAZA,
  gar_editar_legal: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  gar_fotos_subir: [...COMERCIAL_PLAZA, "SS"],
  gar_fotos_organizar: COMERCIAL_PLAZA,
  gar_descargar_ficha: [...COMERCIAL_PLAZA, "ASE"],
  gar_ver_descuentos: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  gar_pedir_apertura_promociones: ["Super_Admin", "DGE", "DTR", "GL_GDL", "GL_CUL", "GL_MAZ", "GL_LAP", "SUBGERENTE", "SDC"],
  gar_mandar_predictamen: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  precio_calcular: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  precio_recalcular: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "GRC", "RAC", "SDC"],
  precio_definir_venta: ["Super_Admin", "DGE", "DTR", "RAC", "SDC"],
  precio_validar: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "RAC"],
  promo_validar_apertura: ["Super_Admin", "DGE", "DTR", "DGC", "GAD", "RAC"],
  exportar_bitacora: DIRECTORES,
  clientes_gestionar: GESTORES_CLIENTE,
  config_colaboradores: ["Super_Admin", "DGE", "DTR"],
  aprobar_accesos: DIRECTORES,
  generar_exp_colaborador: ["Super_Admin", "DGE", "GAD"],
  generar_exp_cliente: ["Super_Admin", "DGE", "RAC", "SRAC"],
  catalogo_editar: ["Super_Admin", "DGE", "RAC"],
  asignar_asesor: [...DIRECTORES, ...GERENTES],
  convertir_cliente: DIRECTORES, // 👈 Fase E.2: SOLO directores convierten a Cliente
  // 👇 NIVEL 1 (críticas). Defaults seguros; Paola las afina en Roles y Permisos.
  editar_permisos: ["Super_Admin", "DGE", "DTR"],
  ver_papelera: ["Super_Admin", "DGE", "DTR", "GAD"],
  borrar_definitivo: ["Super_Admin", "DGE"],
  borrar_colaborador: ["Super_Admin", "DGE", "DTR"],
  // 👇 NIVEL 2-A (operativas). Default permisivo (todos menos Invitado); Paola las afina.
  enviar_papelera: OPERATIVOS,
  restaurar: OPERATIVOS,
  archivar: OPERATIVOS,
  // 👇 NIVEL 2-B (negocio del cliente). Defaults = lo que hoy es verdad; Paola los afina.
  cambiar_codigo: GESTORES_CLIENTE,      // igual que "gestionar clientes" hoy
  compartir_cliente: ["Super_Admin", "DGE"], // hoy solo Dirección comparte
  actualizar_vencido: ["Super_Admin", "DGE", "GAD"], // contrato vencido → R1: solo ADM
  // 👇 NIVEL 2-C (comunicaciones). Default permisivo (todos menos Invitado); Paola los afina.
  registrar_llamada: OPERATIVOS,
  gestionar_llamada: OPERATIVOS,
  crear_videollamada: OPERATIVOS,
  crear_grupo_chat: OPERATIVOS,
  administrar_grupo: OPERATIVOS,
  // 👇 NIVEL 3-D (jurídico). Default permisivo; Paola lo afina (típicamente a Jurídico + Dirección).
  gestionar_actuaciones: OPERATIVOS,
  gestionar_convenio_contingencia: OPERATIVOS,
  gestionar_juicio: OPERATIVOS,
  // 👇 CRM PROSPECTOS COMERCIAL. SDC reparte · GL asigna · Asesor dueño · directores ven todo.
  prospectos_crear: PROSPECTOS_CREA,
  prospectos_asignar: PROSPECTOS_REPARTE,
  prospectos_gestionar: PROSPECTOS_GESTIONA,
  prospectos_borrar: ["Super_Admin", "DGE", "DGC"],
  // 👇 FASE E (dinero). Default cerrado; Paola abre a quien quiera.
  // 👇 ABONOS DE DEVOLUCIÓN — quién puede qué (definido por la DGE, 01-sep-2026).
  // REGISTRAR: la telefonista de primer contacto (ATC) y la Sub-RAC (SRAC) son
  // quienes capturan el abono cuando llega el comprobante. Se incluyen también
  // RAC, DGE, Super_Admin y las áreas de dinero, que ya lo hacían.
  registrar_abono: ["Super_Admin", "DGE", "RAC", "SRAC", "ATC", "GAD", "UFF_Cobros", "UFF_Pagos", "ASIS_CONT"],
  // EDITAR y BORRAR: SOLO RAC y Dirección. Corregir o quitar un abono mueve el
  // saldo del cliente, así que se cierra a esos dos.
  editar_abono: ["Super_Admin", "DGE", "RAC"],
  borrar_abono: ["Super_Admin", "DGE", "RAC"],
  // 👇 Compensación por la espera: RAC la solicita; SOLO GAD/DGE la habilitan.
  solicitar_compensacion: ["Super_Admin", "DGE", "RAC", "SRAC", "GRS_Nacional", "GL_GDL", "GL_CUL", "GL_LAP", "GL_MAZ", "SUBGERENTE", "DGC"],
  habilitar_compensacion: ["Super_Admin", "DGE", "RAC", "SRAC"], // 👈 GAD ya NO habilita — se queda solo con vista y notificación
  solicitar_terminos_rdc: ["Super_Admin", "DGE", "DGC", "GRC"], // 👈 solo Director Comercial (Luis Carlos) y GRC (Elizabeth)
  llenar_datos_sucursal_rdc: ["Super_Admin", "DGE", "GAD", "GL_GDL", "GL_CUL", "GL_LAP", "GL_MAZ", "GRS_Nacional", "SUBGERENTE", "DGC", "GRC", "RAC"], // 👈 solo ellos llenan Y validan valores/fechas — el asesor ya NO
  solicitar_devolucion_formal: ["Super_Admin", "DGE", "Colaborador", "ASE", "GRC"], // 👈 asesor/colaborador SOLO disparan la solicitud, no llenan nada
  // 👇 Cerrar/terminar caso en Seguimiento: SOLO RAC, GAD y DGE.
  terminar_caso: ["Super_Admin", "DGE", "GAD", "RAC"],
  // 👇 FASE F (acciones del expediente). Default permisivo; Paola afina.
  editar_ficha: OPERATIVOS,
  subir_devolucion: OPERATIVOS, // 👇 Subir "Solicitud de Devolución": separado de editar_ficha (Fase: SRAC/ATC)
  subir_documentos: OPERATIVOS,
  docs_criticos: DOCS_CRITICOS, // 👈 contrato, carta propuesta, dictámenes y cuentas de pago
  agregar_nota: OPERATIVOS,
  gestionar_tareas: OPERATIVOS,
  redactar_correo: OPERATIVOS,
  // 👇 FASE G (visibilidad de pestañas del expediente). Default: todos las ven.
  ver_exp_ficha: OPERATIVOS,
  ver_exp_expediente: OPERATIVOS,
  ver_exp_llamadas: OPERATIVOS,
  ver_exp_correos: OPERATIVOS,
  ver_exp_notas: OPERATIVOS,
  ver_exp_tareas: OPERATIVOS,
  ver_exp_actuaciones: OPERATIVOS,
  ver_exp_legal: OPERATIVOS,
  ver_exp_cronologia: OPERATIVOS,
};

// 👇 PISO DE SEGURIDAD: estos roles SIEMPRE pueden estas acciones, pase lo que pase
//    en Roles y Permisos. Evita que alguien se quede candado fuera (sobre todo de
//    "editar_permisos", que si se apaga para todos ya nadie podría volver a entrar).
const PISO_SEGURIDAD: Partial<Record<AccionClave, string[]>> = {
  editar_permisos: ["Super_Admin", "DGE", "DTR"],
  ver_papelera: ["Super_Admin", "DGE", "DTR"],
  // Documentos críticos: Dirección y Tecnología nunca se quedan fuera.
  docs_criticos: ["Super_Admin", "DGE", "DTR"],
  // Cerrar/terminar caso: SIEMPRE disponible para estos roles (aunque la config sea vieja).
  terminar_caso: ["Super_Admin", "DGE", "GAD", "RAC"],
  // CRM Prospectos: la cabeza comercial siempre puede (aunque haya config vieja guardada).
  prospectos_crear: ["Super_Admin", "DGE", "DGC"],
  prospectos_asignar: ["Super_Admin", "DGE", "DGC"],
  prospectos_gestionar: ["Super_Admin", "DGE", "DGC"],
  prospectos_borrar: ["Super_Admin", "DGE", "DGC"],
  // 👇 Abonos: RAC y Dirección nunca se quedan fuera de corregir o quitar un
  // abono, aunque alguien guarde una configuración de permisos vieja.
  editar_abono: ["Super_Admin", "DGE", "RAC"],
  borrar_abono: ["Super_Admin", "DGE", "RAC"],
};

export function puedeAccion(rol: string | null | undefined, accion: AccionClave): boolean {
  if (!rol) return false;
  // Piso de seguridad: nunca se les quita a estos roles.
  if ((PISO_SEGURIDAD[accion] || []).includes(rol)) return true;
  // 👇 Fase 2: si ya hay permisos guardados para este rol, MANDAN ellos.
  const c = getPermisosCache();
  if (c && c.acciones[rol]) return c.acciones[rol].includes(accion);
  // Si todavía no se cargan (o el rol no está), usamos lo del código.
  return (PERMISOS_ACCION[accion] || []).includes(rol);
}
