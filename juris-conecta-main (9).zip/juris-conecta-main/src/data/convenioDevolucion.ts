// Convenio de devolución (RDC y cualquier código) + abonos por partes.
import { supabase } from "../lib/supabase";

export type Convenio = {
  tieneConvenio: boolean;
  montoTotal: number;
  meses: number;
  fechaInicio: string;
  nota: string;
};

export const CONVENIO_VACIO: Convenio = {
  tieneConvenio: false, montoTotal: 0, meses: 0, fechaInicio: "", nota: "",
};

export type EvidenciaArchivo = { nombre: string; link: string };

export type TipoAbono = "capital" | "compensacion";

export type Abono = {
  id: string;
  clienteId: string;
  fecha: string;
  monto: number;
  tipo: TipoAbono;
  nota: string | null;
  registradoPor: string | null;
  archivos: EvidenciaArchivo[];   // 👈 H2: evidencia obligatoria (foto/archivo, puede ser varias)
  createdAt: string;
};

export async function fetchConvenio(clienteId: string): Promise<Convenio | null> {
  const { data, error } = await supabase
    .from("convenio_devolucion")
    .select("*")
    .eq("cliente_id", clienteId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    tieneConvenio: !!data.tiene_convenio,
    montoTotal: Number(data.monto_total) || 0,
    meses: Number(data.meses) || 0,
    fechaInicio: data.fecha_inicio || "",
    nota: data.nota || "",
  };
}

export async function guardarConvenio(clienteId: string, c: Convenio): Promise<boolean> {
  const { error } = await supabase.from("convenio_devolucion").upsert(
    {
      cliente_id: clienteId,
      tiene_convenio: c.tieneConvenio,
      monto_total: c.tieneConvenio ? (c.montoTotal || 0) : 0,
      meses: c.tieneConvenio ? (c.meses || 0) : 0,
      fecha_inicio: c.tieneConvenio ? (c.fechaInicio || null) : null,
      nota: c.tieneConvenio ? (c.nota || null) : null,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "cliente_id" },
  );
  return !error;
}

export async function fetchAbonos(clienteId: string): Promise<Abono[]> {
  const { data, error } = await supabase
    .from("abonos_devolucion")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("fecha", { ascending: false })
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data.map((r: any) => ({
    id: r.id,
    clienteId: r.cliente_id,
    fecha: r.fecha,
    monto: Number(r.monto) || 0,
    tipo: (r.tipo as TipoAbono) || "capital",
    nota: r.nota,
    registradoPor: r.registrado_por,
    archivos: Array.isArray(r.archivos) ? (r.archivos as EvidenciaArchivo[]) : [],
    createdAt: r.created_at,
  }));
}

export async function agregarAbono(a: {
  clienteId: string; fecha: string; monto: number; tipo?: TipoAbono; nota?: string; registradoPor?: string | null;
  archivos?: EvidenciaArchivo[];
}): Promise<Abono | null> {
  const { data, error } = await supabase
    .from("abonos_devolucion")
    .insert({
      cliente_id: a.clienteId,
      fecha: a.fecha,
      monto: a.monto,
      tipo: a.tipo || "capital",
      nota: a.nota || null,
      registrado_por: a.registradoPor || null,
      archivos: a.archivos || [],
    })
    .select("*")
    .single();
  if (error || !data) return null;

  // 👇 Fase 2 RDC: cada abono registrado recorre 1 mes la fecha del "próximo
  // abono estimado", para que el recordatorio automático (campanita) sepa
  // cuándo volver a avisar. No afecta si el cliente no tiene RDC/compensación.
  try {
    const proxima = sumarMeses(a.fecha, 1);
    if (proxima) await supabase.from("compensacion_devolucion").update({ fecha_proximo_abono: proxima }).eq("cliente_id", a.clienteId);
  } catch (e) { console.warn("No se pudo recorrer fecha_proximo_abono:", e); }

  return {
    id: data.id, clienteId: data.cliente_id, fecha: data.fecha,
    monto: Number(data.monto) || 0, tipo: (data.tipo as TipoAbono) || "capital", nota: data.nota, registradoPor: data.registrado_por,
    archivos: Array.isArray(data.archivos) ? (data.archivos as EvidenciaArchivo[]) : [],
    createdAt: data.created_at,
  };
}

/**
 * Edita un abono ya registrado. Solo con permiso "editar_abono" (RAC y
 * Dirección) — la pantalla lo valida antes de llamar aquí. Deja constancia
 * de quién corrigió y cuándo, agregándolo al final de la nota.
 */
export async function editarAbono(
  id: string,
  cambios: { fecha?: string; monto?: number; tipo?: TipoAbono; nota?: string },
  editadoPor: string,
): Promise<boolean> {
  const fila: Record<string, unknown> = {};
  if (cambios.fecha !== undefined) fila.fecha = cambios.fecha;
  if (cambios.monto !== undefined) fila.monto = cambios.monto;
  if (cambios.tipo !== undefined) fila.tipo = cambios.tipo;
  const sello = ` · Corregido por ${editadoPor} el ${new Date().toLocaleDateString("es-MX")}`;
  fila.nota = (cambios.nota ?? "") + sello;
  const { error } = await supabase.from("abonos_devolucion").update(fila).eq("id", id);
  return !error;
}

export async function borrarAbono(id: string): Promise<boolean> {
  const { error } = await supabase.from("abonos_devolucion").delete().eq("id", id);
  return !error;
}

// 👁️ Actualiza las evidencias (documentos) de un abono que YA existe.
// Sirve para adjuntar documentos a abonos viejos (p.ej. los de carga masiva).
export async function actualizarEvidenciasAbono(id: string, archivos: EvidenciaArchivo[]): Promise<boolean> {
  const { error } = await supabase
    .from("abonos_devolucion")
    .update({ archivos })
    .eq("id", id);
  return !error;
}

// ── H3 · Bitácora semanal del convenio/devolución ──────────────
export type BitacoraConvenio = {
  id: string;
  clienteId: string;
  fecha: string;
  texto: string;
  archivos: EvidenciaArchivo[];
  registradoPor: string | null;
  createdAt: string;
};

export async function fetchBitacoras(clienteId: string): Promise<BitacoraConvenio[]> {
  const { data, error } = await supabase
    .from("bitacora_convenio")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("fecha", { ascending: false })
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data.map((r: any) => ({
    id: r.id, clienteId: r.cliente_id, fecha: r.fecha, texto: r.texto,
    archivos: Array.isArray(r.archivos) ? (r.archivos as EvidenciaArchivo[]) : [],
    registradoPor: r.registrado_por, createdAt: r.created_at,
  }));
}

export async function agregarBitacora(b: {
  clienteId: string; fecha: string; texto: string; archivos?: EvidenciaArchivo[]; registradoPor?: string | null;
}): Promise<BitacoraConvenio | null> {
  const { data, error } = await supabase
    .from("bitacora_convenio")
    .insert({
      cliente_id: b.clienteId, fecha: b.fecha, texto: b.texto,
      archivos: b.archivos || [], registrado_por: b.registradoPor || null,
    })
    .select("*")
    .single();
  if (error || !data) return null;
  return {
    id: data.id, clienteId: data.cliente_id, fecha: data.fecha, texto: data.texto,
    archivos: Array.isArray(data.archivos) ? (data.archivos as EvidenciaArchivo[]) : [],
    registradoPor: data.registrado_por, createdAt: data.created_at,
  };
}

export async function borrarBitacora(id: string): Promise<boolean> {
  const { error } = await supabase.from("bitacora_convenio").delete().eq("id", id);
  return !error;
}

// ---- Resumen global de devoluciones (para KPIs) ----
// Junta todos los convenios con su monto total y la suma de sus abonos,
// para sacar: cuánto se comprometió, cuánto se ha devuelto y cuánto falta.
export type ResumenDevolucion = {
  clienteId: string;
  montoTotal: number;
  abonado: number;
  saldo: number;        // montoTotal - abonado (nunca negativo)
  meses: number;        // número de abonos pactados
  nAbonos: number;      // abonos ya registrados
  ultimaFecha: string | null;
  concretada: boolean;  // saldo <= 0  → ya se devolvió todo
};

export async function fetchResumenDevoluciones(): Promise<ResumenDevolucion[]> {
  const { data: convenios, error: e1 } = await supabase
    .from("convenio_devolucion")
    .select("cliente_id, monto_total, meses, tiene_convenio")
    .eq("tiene_convenio", true);
  if (e1 || !convenios) return [];

  const { data: abonos } = await supabase
    .from("abonos_devolucion")
    .select("cliente_id, monto, fecha");

  // Agrupa abonos por cliente: suma y última fecha.
  const porCliente = new Map<string, { suma: number; n: number; ultima: string | null }>();
  for (const a of abonos || []) {
    const k = String(a.cliente_id);
    const o = porCliente.get(k) || { suma: 0, n: 0, ultima: null };
    o.suma += Number(a.monto) || 0;
    o.n += 1;
    if (a.fecha && (!o.ultima || a.fecha > o.ultima)) o.ultima = a.fecha;
    porCliente.set(k, o);
  }

  return convenios.map((c: any) => {
    const k = String(c.cliente_id);
    const ab = porCliente.get(k) || { suma: 0, n: 0, ultima: null };
    const montoTotal = Number(c.monto_total) || 0;
    const saldo = Math.max(0, montoTotal - ab.suma);
    return {
      clienteId: k,
      montoTotal,
      abonado: ab.suma,
      saldo,
      meses: Number(c.meses) || 0,
      nAbonos: ab.n,
      ultimaFecha: ab.ultima,
      concretada: saldo <= 0 && montoTotal > 0,
    };
  });
}

// ── Compensación por la espera (devolución compensada) ───────────────────────
export type EstadoCompensacion = "ninguna" | "solicitada" | "habilitada";

export type Compensacion = {
  capital: number;
  plazoMeses: number;
  fechaVencimiento: string;     // "" → la app la calcula: firma + plazo
  solicitoDevolucion: boolean;
  fechaSolicitudDev: string;
  tasa: number;                 // 5
  estado: EstadoCompensacion;
  documento: EvidenciaArchivo[];
  solicitadaPor: string | null;
  fechaSolicitada: string | null;
  habilitadaPor: string | null;
  fechaHabilitada: string | null;
  nota: string;
};

export const COMPENSACION_VACIA: Compensacion = {
  capital: 0, plazoMeses: 14, fechaVencimiento: "", solicitoDevolucion: false,
  fechaSolicitudDev: "", tasa: 5, estado: "ninguna", documento: [],
  solicitadaPor: null, fechaSolicitada: null, habilitadaPor: null, fechaHabilitada: null, nota: "",
};

export async function fetchCompensacion(clienteId: string): Promise<Compensacion | null> {
  const { data, error } = await supabase
    .from("compensacion_devolucion")
    .select("*")
    .eq("cliente_id", clienteId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    capital: Number(data.capital) || 0,
    plazoMeses: Number(data.plazo_meses) || 14,
    fechaVencimiento: data.fecha_vencimiento || "",
    solicitoDevolucion: !!data.solicito_devolucion,
    fechaSolicitudDev: data.fecha_solicitud_dev || "",
    tasa: Number(data.tasa) || 5,
    estado: (data.estado as EstadoCompensacion) || "ninguna",
    documento: Array.isArray(data.documento) ? (data.documento as EvidenciaArchivo[]) : [],
    solicitadaPor: data.solicitada_por,
    fechaSolicitada: data.fecha_solicitada,
    habilitadaPor: data.habilitada_por,
    fechaHabilitada: data.fecha_habilitada,
    nota: data.nota || "",
  };
}

// Guarda (crea o actualiza) la compensación del cliente. Solo manda lo que reciba.
export async function guardarCompensacion(clienteId: string, c: Partial<Compensacion>): Promise<boolean> {
  const fila: Record<string, unknown> = { cliente_id: clienteId, updated_at: new Date().toISOString() };
  if (c.capital !== undefined) fila.capital = c.capital || 0;
  if (c.plazoMeses !== undefined) fila.plazo_meses = c.plazoMeses || 14;
  if (c.fechaVencimiento !== undefined) fila.fecha_vencimiento = c.fechaVencimiento || null;
  if (c.solicitoDevolucion !== undefined) fila.solicito_devolucion = c.solicitoDevolucion;
  if (c.fechaSolicitudDev !== undefined) fila.fecha_solicitud_dev = c.fechaSolicitudDev || null;
  if (c.tasa !== undefined) fila.tasa = c.tasa || 5;
  if (c.estado !== undefined) fila.estado = c.estado;
  if (c.documento !== undefined) fila.documento = c.documento;
  if (c.solicitadaPor !== undefined) fila.solicitada_por = c.solicitadaPor;
  if (c.fechaSolicitada !== undefined) fila.fecha_solicitada = c.fechaSolicitada;
  if (c.habilitadaPor !== undefined) fila.habilitada_por = c.habilitadaPor;
  if (c.fechaHabilitada !== undefined) fila.fecha_habilitada = c.fechaHabilitada;
  if (c.nota !== undefined) fila.nota = c.nota || null;

  // 👇 Fase 2 RDC: al habilitarse la compensación, si no hay ya una fecha de
  // próximo abono, se siembra a 6 meses (el plazo que se le confirma al
  // cliente para que inicien los abonos). El robot diario avisa desde ahí.
  if (c.estado === "habilitada") {
    const { data: actual } = await supabase.from("compensacion_devolucion").select("fecha_proximo_abono").eq("cliente_id", clienteId).maybeSingle();
    if (!actual?.fecha_proximo_abono) {
      const base = sumarMeses(new Date().toISOString().slice(0, 10), 6);
      if (base) fila.fecha_proximo_abono = base;
    }
  }

  const { error } = await supabase.from("compensacion_devolucion").upsert(fila, { onConflict: "cliente_id" });
  return !error;
}

// Suma meses a una fecha ISO (yyyy-mm-dd). Devuelve "" si no hay fecha.
export function sumarMeses(fechaISO: string, meses: number): string {
  if (!fechaISO) return "";
  const d = new Date(fechaISO + "T00:00:00");
  d.setMonth(d.getMonth() + (meses || 0));
  return d.toISOString().slice(0, 10);
}

// Todos los abonos (de todos los clientes) con su fecha, monto y tipo, para filtrar por periodo o tipo.
export async function fetchTodosAbonos(): Promise<{ clienteId: string; fecha: string; monto: number; tipo: TipoAbono }[]> {
  const { data, error } = await supabase
    .from("abonos_devolucion")
    .select("cliente_id, fecha, monto, tipo")
    .order("fecha", { ascending: false })
    .limit(5000);
  if (error || !data) return [];
  return data.map((r: any) => ({ clienteId: r.cliente_id, fecha: r.fecha, monto: Number(r.monto) || 0, tipo: (r.tipo as TipoAbono) || "capital" }));
}
