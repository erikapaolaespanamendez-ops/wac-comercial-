// Parámetros de Devoluciones — ÚNICA fuente de verdad.
//
// Todos los porcentajes y plazos del módulo de Devoluciones viven en la tabla
// `parametros_devolucion` de la base, en una sola fila. Antes estaban escritos
// dentro del código, en `rdc.ts`, y para cambiar un número había que compilar
// y publicar. Ahora los edita la DGE en la base y el sistema los toma solos.
//
// POR QUÉ ESTE ARCHIVO SE VE RARO
// Leer de la base es asíncrono (tarda), pero las funciones que calculan montos
// son síncronas (devuelven el número de inmediato). Para no volver asíncrono
// todo el motor —que son más de cien lugares— los parámetros se cargan UNA VEZ
// al abrir el sistema y se guardan aquí en memoria. De ahí los leen los
// cálculos, sin esperar.
//
// LA REGLA IMPORTANTE
// Si los parámetros NO cargaron, el sistema NO calcula. No hay valores de
// respaldo a propósito: un convenio impreso con un porcentaje viejo es un
// documento firmado con el número equivocado, y eso ya no se corrige. Es
// preferible que la pantalla diga "no se pudieron cargar" a que imprima 4%
// cuando la DGE ya lo cambió a otra cosa.
import { supabase } from "../lib/supabase";

export interface ParametrosDevolucion {
  /** Cuántos clientes se alcanzan a pagar al mes. Hoy: 2. */
  clientesPorMes: number;
  /** Rango normal de dinero disponible al mes, para sugerirlo al registrar. */
  montoMinMes: number;
  montoMaxMes: number;
  /** Porcentaje de las ventas del mes que se estima para la bolsa. Hoy: 15%. */
  pctBolsaVentas: number;
  /** Cuánto de la bolsa va a Modalidad 1. El resto va a Modalidad 2. Hoy: mitad. */
  pctRepartoM1: number;
  /** Tope de la bolsa que puede irse en prioridades. Hoy: 25%. */
  pctTopePrioridad: number;
  /** Separación entre un abono y el siguiente, en meses. Hoy: de 2 a 3. */
  mesesEntrePagosMin: number;
  mesesEntrePagosMax: number;
  /** Días naturales de gracia antes de que un pago cuente como atrasado. Hoy: 30. */
  diasGracia: number;
  /**
   * Moratorio mensual a favor del cliente, cuando DIIPA se atrasa. Hoy: 0.5%.
   * OJO — cambio del 02-sep-2026: antes era 1% sobre la CUOTA atrasada; ahora
   * es 0.5% sobre el CAPITAL pendiente. Sobre que se calcula lo dice
   * `moratorioBase`, y a quien le corre lo dice `moratorioSoloFilaA`.
   */
  pctMoratorioMensual: number;
  /** Compensación por espera: 4% el año 1, 5% el año 2. */
  tasaCompensacionA1: number;
  tasaCompensacionA2: number;
  /** Compensación por Terminación, si el contrato ya venció. Hoy: 5%. */
  pctTerminacion: number;
  /** Penalización si el contrato sigue vigente. Hoy: 10%. */
  pctPenalizVigente: number;
  /** Honorarios devengados según la etapa. Hoy: 10% sin dictamen, 35% con dictamen positivo. */
  pctHonorSinDictamen: number;
  pctHonorDictamenPositivo: number;

  // ── Topes de abono ──────────────────────────────────────────────────────
  topeAbono: number;                    // tope general de un abono
  topeAbonoSinAprobacion: number;       // arriba de esto pide aprobación de GAD/DGE
  topeAbonoConvenioSimple: number;      // tope de abono en Modalidad 2

  // ── Plazos del proceso ──────────────────────────────────────────────────
  plazoDefinicionDias: number;          // 2a validación (DIL/DGE/GAD) y habilitación del convenio
  plazoRevisionMinDias: number;         // objetivo para habilitar la Solicitud
  plazoRevisionMaxDias: number;         // límite duro; pasado esto se marca vencida
  plazoFirmaHoras: number;              // horas que tiene el cliente para firmar
  limiteDescargasPorPersona: number;    // cuántas veces puede bajar el mismo folio
  plazoMesesRevisionExpediente: number; // meses para confirmar monto y calendario
  plazoMesesPrimerAbono: number;        // el primer abono, contado desde la firma del convenio

  // ── Calendario de pagos ─────────────────────────────────────────────────
  plazoInicioAbonosMeses: number;
  plazoMesesParaCompensacion: number;   // aniversario con que se recalcula la compensación
  plazoPagoCompensacionDias: number;    // margen para pagar la primera compensación
  topeMesesEntreAbonos: number;
  m1MesesInicioCapital: number;
  m1NumPagosCapital: number;
  /** OBSOLETO desde el 02-sep-2026. La compensacion ya no tiene calendario
   *  propio por cliente: va a la cola final global (ver `compensacionEnColaFinal`).
   *  Se conserva el campo porque `rdc.ts` todavia lo lee; se quita cuando el
   *  motor deje de usarlo. */
  m1MesesInicioCompensacion: number;
  /** OBSOLETO desde el 02-sep-2026 — ver `m1MesesInicioCompensacion`. */
  m1NumPagosCompensacion: number;
  m2MesesInicio: number;
  m2NumPagosMax: number;
  plazoMesesConvenioSimple: number;

  // ── Bolsa mensual y reparto entre las dos filas (02-sep-2026) ───────────
  /** El dinero que se compromete al mes para devoluciones. Hoy: $300,000.
   *  Es el piso de planeacion; si entra mas, se suma a la bolsa del mes. */
  bolsaMensual: number;
  /** Parte de la bolsa reservada INTOCABLE para la Fila B, la fila normal que
   *  no tiene convenio con fecha. Hoy: un tercio (0.3333). Sirve para que los
   *  turnos mas viejos avancen aunque el mes venga cargado de convenios. */
  pctReservaFilaB: number;

  // ── Fila A: convenios con fecha cierta (02-sep-2026) ────────────────────
  /** Cuantos convenios se pueden firmar en un mismo mes. Hoy: 3. El cuarto pasa
   *  a lista de espera y se firma el mes siguiente, por orden de solicitud. */
  topeConveniosMes: number;
  /** Cuantas solicitudes de devolucion se pueden meter al proceso en un mismo
   *  mes. Hoy: 3. Es un cupo APARTE del de los convenios: son 3 solicitudes y
   *  3 convenios cada mes, no 3 en total. */
  topeSolicitudesMes: number;
  /** Cuantos pagos (personas) se alcanzan a atender en un mes, ademas del
   *  limite de dinero. Hoy: 40. Vivia escrito en `rdc.ts`; se movio a la base
   *  el 02-sep-2026 conservando su valor. */
  topePagosMes: number;
  /** Dias desde la firma del convenio hasta su PRIMER pago. Hoy: 60. A esto se
   *  le suman despues los `diasGracia`. */
  diasPrimerPagoConvenio: number;
  /** Rango permitido para el plazo de un convenio, en meses. Hoy: de 24 a 36. */
  plazoConvenioMinMeses: number;
  plazoConvenioMaxMeses: number;
  /** Cortes de saldo que deciden el plazo dentro de ese rango: hasta
   *  `corteSaldoPlazo24` va al plazo minimo; hasta `corteSaldoPlazo30` va al
   *  intermedio; arriba de eso, al maximo. Hoy: $200,000 y $400,000. */
  corteSaldoPlazo24: number;
  corteSaldoPlazo30: number;

  // ── Orden de pago (02-sep-2026) ─────────────────────────────────────────
  /** Como se ordena el gasto del mes. Hoy: "capital_primero". INVIERTE la regla
   *  anterior, que pagaba la compensacion antes que el capital. */
  ordenPago: string;
  /** Si es true, la compensacion NO se paga junto con el capital de cada
   *  cliente: se va hasta el final, en una tercera cola global. Quien ya solo
   *  debe compensacion se forma hasta atras. Hoy: true. */
  compensacionEnColaFinal: boolean;
  /** Como se ordena esa tercera cola. Hoy: "anio_solicitud_asc,monto_asc", o sea
   *  se agrupa por año de solicitud y dentro de cada año se paga de menor a mayor. */
  colaCompensacionCriterio: string;

  // ── Moratorio a favor del cliente (02-sep-2026) ─────────────────────────
  /** Sobre que se calcula el moratorio. Hoy: "capital" (el capital pendiente).
   *  Antes se calculaba sobre la cuota no pagada. */
  moratorioBase: string;
  /** Si es true, el moratorio SOLO corre para la Fila A, donde hay convenio
   *  firmado con fecha comprometida. La Fila B tiene fecha aproximada, no
   *  firmada, y por eso NO genera mora. Hoy: true.
   *  Es la pieza que sostiene el esquema de dos filas: si la Fila B generara
   *  mora, la empresa se cobraria intereses a si misma por cumplir su plan. */
  moratorioSoloFilaA: boolean;

  /** Tope de la escalera de compensacion: 4% del año 1 + 5% del año 2 + 5% de
   *  terminacion = 14%. El 5% del año 2 se SUMA al 4%, no lo reemplaza. */
  pctCompensacionTope: number;
}

let cache: ParametrosDevolucion | null = null;
let ultimoError: string | null = null;

function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

// 👇 Los campos nuevos del 02-sep-2026 no son todos numeros: hay tres de texto
// (ordenPago, colaCompensacionCriterio, moratorioBase) y dos de si/no
// (compensacionEnColaFinal, moratorioSoloFilaA). `num()` los volveria 0 y false
// en silencio, asi que cada tipo necesita su propio lector.

function txt(v: unknown, porDefecto: string): string {
  return typeof v === "string" && v.trim() !== "" ? v : porDefecto;
}

function bool(v: unknown, porDefecto: boolean): boolean {
  if (typeof v === "boolean") return v;
  if (v === "true") return true;
  if (v === "false") return false;
  return porDefecto;
}

/**
 * Carga los parámetros de la base y los deja en memoria. Se llama una vez al
 * arrancar el sistema (`main.tsx`). Devuelve true si quedaron cargados.
 */
export async function cargarParametrosDevolucion(): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from("parametros_devolucion")
      .select("*")
      .eq("id", 1)
      .maybeSingle();

    if (error) { ultimoError = error.message; return false; }
    if (!data) { ultimoError = "No existe la fila de parámetros (id = 1)."; return false; }

    cache = {
      clientesPorMes: num(data.clientes_por_mes),
      montoMinMes: num(data.monto_min_mes),
      montoMaxMes: num(data.monto_max_mes),
      pctBolsaVentas: num(data.pct_bolsa_ventas),
      pctRepartoM1: num(data.pct_reparto_m1),
      pctTopePrioridad: num(data.pct_tope_prioridad),
      mesesEntrePagosMin: num(data.meses_entre_pagos_min),
      mesesEntrePagosMax: num(data.meses_entre_pagos_max),
      diasGracia: num(data.dias_gracia),
      pctMoratorioMensual: num(data.pct_moratorio_mensual),
      tasaCompensacionA1: num(data.tasa_compensacion_a1),
      tasaCompensacionA2: num(data.tasa_compensacion_a2),
      pctTerminacion: num(data.pct_terminacion),
      pctPenalizVigente: num(data.pct_penaliz_vigente),
      pctHonorSinDictamen: num(data.pct_honor_sin_dict),
      pctHonorDictamenPositivo: num(data.pct_honor_dict_pos),

      topeAbono: num(data.tope_abono),
      topeAbonoSinAprobacion: num(data.tope_abono_sin_aprobacion),
      topeAbonoConvenioSimple: num(data.tope_abono_convenio_simple),

      plazoDefinicionDias: num(data.plazo_definicion_dias),
      plazoRevisionMinDias: num(data.plazo_revision_min_dias),
      plazoRevisionMaxDias: num(data.plazo_revision_max_dias),
      plazoFirmaHoras: num(data.plazo_firma_horas),
      limiteDescargasPorPersona: num(data.limite_descargas_por_persona),
      plazoMesesRevisionExpediente: num(data.plazo_meses_revision_expediente),
      plazoMesesPrimerAbono: num(data.plazo_meses_primer_abono),

      plazoInicioAbonosMeses: num(data.plazo_inicio_abonos_meses),
      plazoMesesParaCompensacion: num(data.plazo_meses_para_compensacion),
      plazoPagoCompensacionDias: num(data.plazo_pago_compensacion_dias),
      topeMesesEntreAbonos: num(data.tope_meses_entre_abonos),
      m1MesesInicioCapital: num(data.m1_meses_inicio_capital),
      m1NumPagosCapital: num(data.m1_num_pagos_capital),
      m1MesesInicioCompensacion: num(data.m1_meses_inicio_compensacion),
      m1NumPagosCompensacion: num(data.m1_num_pagos_compensacion),
      m2MesesInicio: num(data.m2_meses_inicio),
      m2NumPagosMax: num(data.m2_num_pagos_max),
      plazoMesesConvenioSimple: num(data.plazo_meses_convenio_simple),

      // ── Campos nuevos del 02-sep-2026 ─────────────────────────────────
      bolsaMensual: num(data.bolsa_mensual),
      pctReservaFilaB: num(data.pct_reserva_fila_b),

      topeConveniosMes: num(data.tope_convenios_mes),
      topeSolicitudesMes: num(data.tope_solicitudes_mes),
      topePagosMes: num(data.tope_pagos_mes),
      diasPrimerPagoConvenio: num(data.dias_primer_pago_convenio),
      plazoConvenioMinMeses: num(data.plazo_convenio_min_meses),
      plazoConvenioMaxMeses: num(data.plazo_convenio_max_meses),
      corteSaldoPlazo24: num(data.corte_saldo_plazo_24),
      corteSaldoPlazo30: num(data.corte_saldo_plazo_30),

      ordenPago: txt(data.orden_pago, "capital_primero"),
      compensacionEnColaFinal: bool(data.compensacion_en_cola_final, true),
      colaCompensacionCriterio: txt(data.cola_compensacion_criterio, "anio_solicitud_asc,monto_asc"),

      moratorioBase: txt(data.moratorio_base, "capital"),
      moratorioSoloFilaA: bool(data.moratorio_solo_fila_a, true),

      pctCompensacionTope: num(data.pct_compensacion_tope),
    };
    ultimoError = null;
    return true;
  } catch (e) {
    ultimoError = e instanceof Error ? e.message : String(e);
    return false;
  }
}

/** ¿Ya están los parámetros en memoria? Las pantallas de Devoluciones lo consultan antes de dibujar cualquier monto. */
export function hayParametros(): boolean {
  return cache !== null;
}

/** Por qué falló la última carga — para mostrarlo en el aviso. */
export function errorParametros(): string | null {
  return ultimoError;
}

/**
 * Los parámetros, para usarse dentro de un cálculo. Truena a propósito si no
 * cargaron: preferimos que se note, a que salga un número equivocado. Toda
 * pantalla que calcule debe revisar `hayParametros()` antes.
 */
export function P(): ParametrosDevolucion {
  if (!cache) {
    throw new Error(
      "Parámetros de Devoluciones no cargados. No se puede calcular ningún monto. " +
      (ultimoError ? `Motivo: ${ultimoError}` : "")
    );
  }
  return cache;
}

/**
 * Como se parte la bolsa del mes: cuanto queda RESERVADO para la Fila B (la
 * fila normal, sin convenio) y cuanto queda disponible para los convenios de
 * la Fila A. Lo que sobre de la Fila A tambien se le pasa a la Fila B, pero eso
 * lo decide el motor; aqui solo se parte la bolsa.
 */
export function repartoBolsaMensual(): { reservaFilaB: number; topeFilaA: number } {
  const p = P();
  const reservaFilaB = Math.round(p.bolsaMensual * p.pctReservaFilaB);
  return { reservaFilaB, topeFilaA: p.bolsaMensual - reservaFilaB };
}

/**
 * El plazo que le toca a un convenio segun su saldo, siempre dentro del rango
 * permitido. Sirve para que el plazo no se negocie caso por caso.
 */
export function plazoConvenioPorSaldo(saldo: number): number {
  const p = P();
  if (saldo <= p.corteSaldoPlazo24) return p.plazoConvenioMinMeses;
  if (saldo <= p.corteSaldoPlazo30) {
    return Math.round((p.plazoConvenioMinMeses + p.plazoConvenioMaxMeses) / 2);
  }
  return p.plazoConvenioMaxMeses;
}

/** Vuelve a leerlos de la base — para el botón de reintentar del aviso. */
export async function recargarParametrosDevolucion(): Promise<boolean> {
  cache = null;
  return cargarParametrosDevolucion();
}

/** Guarda cambios hechos por la DGE y refresca la copia en memoria. */
export async function guardarParametrosDevolucion(
  cambios: Partial<Record<string, number | string | boolean>>,
  quien: string,
): Promise<boolean> {
  const { error } = await supabase
    .from("parametros_devolucion")
    .update({ ...cambios, actualizado_por: quien, actualizado_en: new Date().toISOString() })
    .eq("id", 1);
  if (error) return false;
  await recargarParametrosDevolucion();
  return true;
}
