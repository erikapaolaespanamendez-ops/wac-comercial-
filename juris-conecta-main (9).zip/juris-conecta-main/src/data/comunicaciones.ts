import { supabase } from "../lib/supabase";

export type Comunicacion = {
  id: string;
  cliente_id: string;
  cliente_nombre: string | null;
  tipo: string;        // 'whatsapp' | 'correo' | 'llamada' | 'videollamada' | 'nota'
  detalle: string | null;
  autor: string | null;
  created_at: string;
};

// Trae el historial de contactos de un cliente (lo más nuevo primero)
export async function fetchComunicaciones(clienteId: string): Promise<Comunicacion[]> {
  if (!clienteId) return [];
  const { data, error } = await supabase
    .from("comunicaciones_cliente")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("created_at", { ascending: false });
  if (error) { console.error("No se pudieron traer las comunicaciones:", error.message); return []; }
  return (data || []) as Comunicacion[];
}

// Guarda un contacto (WhatsApp, correo, llamada, videollamada o nota)
export async function registrarComunicacion(p: {
  clienteId: string;
  clienteNombre?: string | null;
  tipo: string;
  detalle?: string;
  autor?: string | null;
}): Promise<Comunicacion | null> {
  const { data, error } = await supabase
    .from("comunicaciones_cliente")
    .insert({
      cliente_id: p.clienteId,
      cliente_nombre: p.clienteNombre ?? null,
      tipo: p.tipo,
      detalle: p.detalle ?? null,
      autor: p.autor ?? null,
    })
    .select().single();
  if (error) { console.error("No se pudo registrar la comunicación:", error.message); return null; }
  return data as Comunicacion;
}
