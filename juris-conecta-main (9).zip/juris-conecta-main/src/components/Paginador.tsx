// Paginador reutilizable: « Anterior · números · Siguiente »
export default function Paginador({ pagina, total, onCambio }: { pagina: number; total: number; onCambio: (p: number) => void }) {
  if (total <= 1) return null;

  const nums: (number | "…")[] = [];
  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= pagina - 1 && i <= pagina + 1)) {
      nums.push(i);
    } else if (nums[nums.length - 1] !== "…") {
      nums.push("…");
    }
  }

  const btn = "rounded-lg border px-3 py-1.5 text-[13px] font-semibold transition disabled:opacity-40";
  return (
    <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5">
      <button disabled={pagina <= 1} onClick={() => onCambio(pagina - 1)} className={`${btn} border-black/10 bg-white text-tinta hover:bg-nube`}>← Anterior</button>
      {nums.map((n, i) =>
        n === "…" ? (
          <span key={"e" + i} className="px-1 text-humo">…</span>
        ) : (
          <button
            key={n}
            onClick={() => onCambio(n)}
            className={`min-w-[36px] rounded-lg border px-2.5 py-1.5 text-[13px] font-semibold transition ${n === pagina ? "border-teal bg-teal text-white" : "border-black/10 bg-white text-tinta hover:bg-nube"}`}
          >
            {n}
          </button>
        )
      )}
      <button disabled={pagina >= total} onClick={() => onCambio(pagina + 1)} className={`${btn} border-black/10 bg-white text-tinta hover:bg-nube`}>Siguiente →</button>
    </div>
  );
}
