// Aviso que se muestra EN LUGAR de cualquier pantalla de Devoluciones cuando
// los parámetros no se pudieron leer de la base.
//
// No es un adorno: mientras esto se ve, el sistema NO está calculando montos.
// Es a propósito. Si dejáramos que calculara con valores de respaldo, podría
// imprimirse un convenio con un porcentaje viejo sin que nadie se diera cuenta.
import { useState } from "react";
import { errorParametros, recargarParametrosDevolucion } from "../data/parametrosDevolucion";

export default function AvisoParametros({ onListo }: { onListo?: () => void }) {
  const [reintentando, setReintentando] = useState(false);

  async function reintentar() {
    setReintentando(true);
    try {
      const ok = await recargarParametrosDevolucion();
      if (ok) onListo?.();
      else alert("Siguen sin cargar. Revisa la conexión o avisa a sistemas.");
    } finally {
      setReintentando(false);
    }
  }

  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-[13px]">
      <p className="mb-1 font-semibold text-rose-800">
        No se pudieron cargar los parámetros de Devoluciones
      </p>
      <p className="mb-3 text-rose-700">
        Mientras tanto no se muestran montos ni se puede generar ningún documento.
        Es a propósito: sin los parámetros, cualquier cantidad que apareciera aquí
        podría estar calculada con porcentajes viejos.
      </p>
      {errorParametros() && (
        <p className="mb-3 rounded-lg bg-white/70 px-2 py-1 font-mono text-[11.5px] text-rose-800">
          {errorParametros()}
        </p>
      )}
      <button
        onClick={reintentar}
        disabled={reintentando}
        className="rounded-lg bg-rose-700 px-3 py-1.5 text-[13px] font-semibold text-white hover:bg-rose-800 disabled:opacity-50"
      >
        {reintentando ? "Reintentando…" : "Reintentar"}
      </button>
    </div>
  );
}
